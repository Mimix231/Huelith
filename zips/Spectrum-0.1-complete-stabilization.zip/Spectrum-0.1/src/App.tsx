import { useEffect, useMemo, useState, type ReactNode, type MouseEvent as ReactMouseEvent } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton,
  Menu, MenuItem, Slider, Stack, TextField, Tooltip, Typography, Select, FormControl, Snackbar, Alert,
} from '@mui/material';
import {
  Add, ArrowDownward, ArrowUpward, AutoAwesome, Brush, Close, Code,
  Colorize, ContentCopy, Create, Delete, Download, Edit,
  FileOpen, FlipToFront, FolderOpen, GridOn, History, Image, Layers,
  Lock, LockOpen, Menu as MenuIcon, Mouse, Palette, PanTool, PhotoCamera,
  RadioButtonUnchecked, Rectangle, Redo, Save, Settings, ShapeLine,
  TextFields, Undo, Visibility, VisibilityOff, ZoomIn, ZoomOut, HorizontalRule, CropFree, Tune, ViewSidebar,
} from '@mui/icons-material';
import { activeLayer, activeTab, useEditor, type EditorStore } from './editor/store';
import { flattenLayers, validSize, type BlendMode, type Tool, type Workspace } from './editor/types';
import { scaleShape, shapeBounds, translateShape } from './editor/geometry';
import { exportImage, exportSvg, importImage, openProject, saveProject } from './editor/files';
import { getRecovery, storeRecovery } from './editor/recovery';
import Canvas from './components/Canvas';
import './styles/app.css';
import './styles/glass.css';
import './styles/material.css';
import './styles/classic.css';

interface ToolEntry {
  id: Tool;
  label: string;
  icon: ReactNode;
  shortcut: string;
}

const tools: ToolEntry[] = [
  { id: 'move', label: 'Move & transform', icon: <Mouse />, shortcut: 'V' },
  { id: 'node', label: 'Edit Bézier nodes', icon: <Tune />, shortcut: 'A' },
  { id: 'marquee', label: 'Rectangular selection', icon: <CropFree />, shortcut: 'M' },
  { id: 'hand', label: 'Pan', icon: <PanTool />, shortcut: 'H' },
  { id: 'brush', label: 'Brush', icon: <Brush />, shortcut: 'B' },
  { id: 'eraser', label: 'Eraser', icon: <Edit />, shortcut: 'E' },
  { id: 'eyedropper', label: 'Eyedropper', icon: <Colorize />, shortcut: 'I' },
  { id: 'rectangle', label: 'Rectangle', icon: <Rectangle />, shortcut: 'R' },
  { id: 'ellipse', label: 'Ellipse', icon: <RadioButtonUnchecked />, shortcut: 'O' },
  { id: 'line', label: 'Line', icon: <HorizontalRule />, shortcut: 'L' },
  { id: 'pen', label: 'Smooth Bézier path', icon: <Create />, shortcut: 'P' },
  { id: 'text', label: 'Text', icon: <TextFields />, shortcut: 'T' },
];

function makeTheme(workspace: Workspace) {
  const material = workspace === 'material';
  const classic = workspace === 'classic';
  const primary = material ? '#6750a4' : classic ? '#b4c7df' : '#a5a5ff';
  return createTheme({
    palette: {
      mode: material ? 'light' : 'dark',
      primary: { main: primary },
      secondary: { main: material ? '#006a60' : '#64dddf' },
      background: {
        default: material ? '#f5f2fb' : classic ? '#202328' : '#111627',
        paper: material ? '#fffaff' : classic ? '#30343b' : '#252940',
      },
    },
    shape: { borderRadius: material ? 24 : classic ? 3 : 14 },
    typography: {
      fontFamily: 'Inter, system-ui, -apple-system, Segoe UI, sans-serif',
      fontSize: 12,
      button: { textTransform: 'none', fontWeight: 600 },
    },
    components: {
      MuiButton: {
        styleOverrides: {
          root: { minWidth: 0, borderRadius: material ? 22 : classic ? 3 : 9, boxShadow: 'none' },
        },
      },
      MuiIconButton: {
        styleOverrides: { root: { borderRadius: material ? 15 : classic ? 3 : 9 } },
      },
      MuiSlider: { styleOverrides: { root: { paddingTop: 11, paddingBottom: 11 } } },
      MuiMenu: { defaultProps: { slotProps: { paper: { className: 'spectrum-popup' } } } },
    },
  });
}

interface ActionIconProps {
  title: string;
  children: ReactNode;
  onClick: (event: ReactMouseEvent<HTMLButtonElement>) => void;
  active?: boolean;
  disabled?: boolean;
}

function ActionIcon({ title, children, onClick, active = false, disabled = false }: ActionIconProps) {
  return (
    <Tooltip title={title} placement="right">
      <span>
        <IconButton
          aria-label={title}
          size="small"
          className={active ? 'selected' : ''}
          onClick={onClick}
          disabled={disabled}
        >
          {children}
        </IconButton>
      </span>
    </Tooltip>
  );
}

function ToolRail({ state, openNew }: { state: EditorStore; openNew: () => void }) {
  return (
    <aside className="toolrail" aria-label="Editing tools">
      <div className="rail-heading">TOOLS</div>
      {tools.map(tool => (
        <ActionIcon
          key={tool.id}
          title={`${tool.label} (${tool.shortcut})`}
          active={tool.id === state.tool}
          onClick={() => {
            state.setTool(tool.id);
            if (tool.id !== 'node' && tool.id !== 'move') state.selectShape(null);
          }}
        >
          {tool.icon}
        </ActionIcon>
      ))}
      <div className="rail-spacer" />
      <ActionIcon title="Toggle grid" active={state.grid} onClick={() => state.setGrid(!state.grid)}>
        <GridOn />
      </ActionIcon>
      <ActionIcon title="Reset canvas position" onClick={() => { state.setZoom(1); state.setPan({ x: 0, y: 0 }); }}>
        <FlipToFront />
      </ActionIcon>
      <ActionIcon title="New document" onClick={openNew}>
        <Add />
      </ActionIcon>
    </aside>
  );
}

function CompactSlider({
  label, value, min, max, display, onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  display: string;
  onChange: (value: number) => void;
}) {
  return (
    <div className="compact-slider">
      <span>{label}</span>
      <Slider
        aria-label={label}
        size="small"
        min={min}
        max={max}
        value={value}
        onChange={(_, next) => onChange(next as number)}
      />
      <output>{display}</output>
    </div>
  );
}

function ContextToolbar({ state }: { state: EditorStore }) {
  const entry = tools.find(item => item.id === state.tool);
  const drawing = state.tool === 'brush' || state.tool === 'eraser';
  const colorTool = ['brush', 'rectangle', 'ellipse', 'line', 'pen', 'text'].includes(state.tool);
  const shapeTool = ['rectangle', 'ellipse', 'line', 'pen'].includes(state.tool);
  const selectionTool = state.tool === 'marquee';
  const moveTool = state.tool === 'move' || state.tool === 'node';

  return (
    <div className="contextbar" aria-label="Contextual tool settings">
      <div className="tool-label">{entry?.icon}<strong>{entry?.label}</strong></div>
      <span className="context-divider" />
      {colorTool && (
        <label className="swatch-control">
          <span>{drawing ? 'Color' : 'Stroke'}</span>
          <input type="color" value={state.color} aria-label="Stroke color"
            onChange={event => state.setColor(event.target.value)} />
        </label>
      )}
      {shapeTool && (
        <label className="swatch-control">
          <span>Fill</span>
          <input type="color" value={state.fill} aria-label="Fill color"
            onChange={event => state.setFill(event.target.value)} />
        </label>
      )}
      {(drawing || shapeTool) && (
        <CompactSlider label="Size" value={state.strokeWidth} min={1} max={120}
          display={`${state.strokeWidth}px`} onChange={state.setStrokeWidth} />
      )}
      {drawing && (
        <>
          <CompactSlider label="Hardness" value={Math.round(state.hardness * 100)} min={2} max={100}
            display={`${Math.round(state.hardness * 100)}%`} onChange={value => state.setHardness(value / 100)} />
          <CompactSlider label="Smoothing" value={Math.round(state.smoothing * 100)} min={0} max={95}
            display={`${Math.round(state.smoothing * 100)}%`} onChange={value => state.setSmoothing(value / 100)} />
          <CompactSlider label="Opacity" value={Math.round(state.opacity * 100)} min={1} max={100}
            display={`${Math.round(state.opacity * 100)}%`} onChange={value => state.setOpacity(value / 100)} />
        </>
      )}
      {selectionTool && (
        <>
          <span className="context-instruction">Drag to select an area</span>
          <Button size="small" disabled={!state.selection} onClick={() => state.setSelection(null)}>Deselect</Button>
        </>
      )}
      {moveTool && (
        <span className="context-instruction">
          {state.tool === 'node' ? 'Drag anchor points and curve handles' : 'Drag objects or use resize / rotate handles'}
        </span>
      )}
      {state.tool === 'hand' && <span className="context-instruction">Drag to pan · Ctrl+scroll to zoom</span>}
      <span className="context-grow" />
      <ActionIcon title="Zoom out" onClick={() => state.setZoom(state.zoom / 1.25)}><ZoomOut /></ActionIcon>
      <span className="zoom-value">{Math.round(state.zoom * 100)}%</span>
      <ActionIcon title="Zoom in" onClick={() => state.setZoom(state.zoom * 1.25)}><ZoomIn /></ActionIcon>
    </div>
  );
}

function DocumentTabs({ state, openNew }: { state: EditorStore; openNew: () => void }) {
  return (
    <div className="document-strip">
      <div className="document-tabs" role="tablist" aria-label="Open documents">
        {state.tabs.map(tab => (
          <div className={`doc-tab ${tab.doc.id === state.activeId ? 'active' : ''}`} key={tab.doc.id}>
            <button
              type="button"
              className="doc-tab-select"
              role="tab"
              aria-selected={tab.doc.id === state.activeId}
              onClick={() => state.activate(tab.doc.id)}
            >
              <Image sx={{ fontSize: 16 }} />
              <span>{tab.doc.name}{tab.dirty ? ' ●' : ''}</span>
            </button>
            <button
              type="button"
              className="tab-close"
              aria-label={`Close ${tab.doc.name}`}
              title={`Close ${tab.doc.name}`}
              onClick={() => {
                if (tab.dirty && !window.confirm('Close this document with unsaved changes?')) return;
                state.closeDoc(tab.doc.id);
              }}
            >
              <Close sx={{ fontSize: 14 }} />
            </button>
          </div>
        ))}
        <ActionIcon title="New document (Ctrl+N)" onClick={openNew}><Add fontSize="small" /></ActionIcon>
      </div>
      <span className="workspace-indicator"><AutoAwesome sx={{ fontSize: 14 }} /> Creative workspace</span>
    </div>
  );
}

type InspectorPanel = 'layers' | 'properties' | 'history';

const blendOptions: { value: BlendMode; label: string }[] = [
  { value: 'source-over', label: 'Normal' },
  { value: 'multiply', label: 'Multiply' },
  { value: 'screen', label: 'Screen' },
  { value: 'overlay', label: 'Overlay' },
  { value: 'darken', label: 'Darken' },
  { value: 'lighten', label: 'Lighten' },
];

function InspectorNumber({
  label, value, onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="inspector-number" key={`${label}-${value}`}>
      <span>{label}</span>
      <input
        type="number"
        aria-label={label}
        defaultValue={Math.round(value * 100) / 100}
        onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}
        onBlur={event => {
          const next = Number(event.target.value);
          if (Number.isFinite(next) && next !== value) onChange(next);
        }}
      />
    </label>
  );
}

function Inspector({ state }: { state: EditorStore }) {
  const [panel, setPanel] = useState<InspectorPanel>('layers');
  const [renameId, setRenameId] = useState<string | null>(null);
  const [preview, setPreview] = useState(100);
  const tab = activeTab(state);
  const doc = tab.doc;
  const active = activeLayer(state);
  const activeShape = active?.type === 'vector' ? active.shapes.find(shape => shape.id === state.selectedShapeId) : undefined;
  const layers = [...doc.layers].reverse();

  useEffect(() => {
    setPreview(Math.round((active?.opacity ?? 1) * 100));
  }, [active?.id, active?.opacity]);

  const changeNumber = (key: 'x' | 'y' | 'rotation' | 'width' | 'height', value: number): void => {
    if (!active) return;
    if (activeShape) {
      state.updateShape(activeShape.id, shape => {
        if (shape.kind === 'path') {
          const bounds = shapeBounds(shape);
          if (key === 'x') translateShape(shape, value - bounds.x, 0);
          else if (key === 'y') translateShape(shape, 0, value - bounds.y);
          else if (key === 'width' || key === 'height') {
            scaleShape(shape, bounds, { ...bounds, [key]: Math.max(1, value) });
          } else shape.rotation = value;
        } else if (key === 'width' || key === 'height') shape[key] = Math.max(1, value);
        else shape[key] = value;
      });
    } else if (key === 'x' || key === 'y') {
      state.mutate(document => {
        const layer = document.layers.find(item => item.id === active.id);
        if (layer && !layer.locked) layer[key] = value;
      });
    } else if (key === 'rotation' && active.type === 'raster') {
      state.mutate(document => {
        const layer = document.layers.find(item => item.id === active.id);
        if (layer?.type === 'raster' && !layer.locked) layer.rotation = value;
      });
    }
  };

  return (
    <aside className="inspector" aria-label="Document inspector" style={{ width: state.inspectorWidth }}>
      <div className="inspector-resize" role="separator" aria-orientation="vertical"
        aria-label="Resize inspector" aria-valuenow={state.inspectorWidth} tabIndex={0}
        onKeyDown={event => {
          if (event.key === 'ArrowLeft') state.setInspectorWidth(state.inspectorWidth + 12);
          if (event.key === 'ArrowRight') state.setInspectorWidth(state.inspectorWidth - 12);
          if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') state.saveInspectorWidth();
        }}
        onPointerDown={event => {
          const element = event.currentTarget;
          element.setPointerCapture(event.pointerId);
          element.dataset.pointer = String(event.clientX);
          element.dataset.width = String(state.inspectorWidth);
        }}
        onPointerUp={() => state.saveInspectorWidth()}
        onPointerCancel={() => state.saveInspectorWidth()}
        onPointerMove={event => {
          if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
          const original = Number(event.currentTarget.dataset.width);
          const from = Number(event.currentTarget.dataset.pointer);
          state.setInspectorWidth(original + from - event.clientX);
        }}
      />
      <div className="inspector-tabs">
        {(['layers', 'properties', 'history'] as const).map(key => (
          <button type="button" className={panel === key ? 'active' : ''} key={key}
            aria-pressed={panel === key} onClick={() => setPanel(key)}>
            {key === 'layers' ? <Layers /> : key === 'properties' ? <Settings /> : <History />}
            {key}
          </button>
        ))}
      </div>

      {panel === 'layers' && (
        <>
          <div className="panel-title"><span>Layers</span><span>{doc.layers.length}</span></div>
          <div className="layer-list">
            {layers.map(layer => (
              <div className={`layer-row ${doc.activeLayerId === layer.id ? 'active' : ''}`} key={layer.id}>
                <button type="button" title={layer.visible ? 'Hide layer' : 'Show layer'}
                  aria-label={`${layer.visible ? 'Hide' : 'Show'} ${layer.name}`}
                  onClick={() => state.toggleLayer(layer.id, 'visible')}>
                  {layer.visible ? <Visibility fontSize="small" /> : <VisibilityOff fontSize="small" />}
                </button>
                <div className={`layer-thumb ${layer.type}`}>
                  {layer.type === 'vector' ? <ShapeLine /> : <Image />}
                </div>
                {renameId === layer.id ? (
                  <input
                    className="layer-rename-input"
                    autoFocus
                    aria-label={`Rename ${layer.name}`}
                    defaultValue={layer.name}
                    onKeyDown={event => {
                      if (event.key === 'Enter') event.currentTarget.blur();
                      if (event.key === 'Escape') setRenameId(null);
                    }}
                    onBlur={event => {
                      if (renameId === layer.id && event.target.value.trim()) {
                        state.renameLayer(layer.id, event.target.value);
                      }
                      setRenameId(null);
                    }}
                  />
                ) : (
                  <button type="button" className="layer-info" title="Click to select · double-click to rename"
                    aria-current={doc.activeLayerId === layer.id}
                    onClick={() => state.selectLayer(layer.id)}
                    onDoubleClick={() => { state.selectLayer(layer.id); setRenameId(layer.id); }}>
                    <span>{layer.name}{layer.mask ? ' ◧' : ''}</span>
                    <small>{layer.type} · {Math.round(layer.opacity * 100)}%</small>
                  </button>
                )}
                <button type="button" title="Lock / unlock" aria-label={`Toggle lock for ${layer.name}`}
                  onClick={() => state.toggleLayer(layer.id, 'locked')}>
                  {layer.locked ? <Lock fontSize="small" /> : <LockOpen fontSize="small" />}
                </button>
              </div>
            ))}
          </div>
          <div className="layer-buttons">
            <ActionIcon title="Add raster layer" onClick={() => state.addLayer('raster')}><Add /></ActionIcon>
            <ActionIcon title="Add vector layer" onClick={() => state.addLayer('vector')}><ShapeLine /></ActionIcon>
            <ActionIcon title="Duplicate layer" onClick={state.duplicateLayer}><ContentCopy /></ActionIcon>
            <ActionIcon title="Move layer up" onClick={() => {
              if (doc.activeLayerId) state.moveLayer(doc.activeLayerId, 1);
            }}><ArrowUpward /></ActionIcon>
            <ActionIcon title="Move layer down" onClick={() => {
              if (doc.activeLayerId) state.moveLayer(doc.activeLayerId, -1);
            }}><ArrowDownward /></ActionIcon>
            <ActionIcon title="Remove layer" disabled={doc.layers.length <= 1} onClick={state.removeLayer}><Delete /></ActionIcon>
          </div>
          <section className="properties-box">
            <div className="property-heading">Compositing</div>
            <div className="compact-property-row">
              <span>Blend mode</span>
              <FormControl size="small" sx={{ minWidth: 135 }}>
                <Select value={active?.blend ?? 'source-over'} disabled={!active || active.locked}
                  aria-label="Layer blend mode" onChange={event => active && state.setLayerBlend(active.id, event.target.value as BlendMode)}>
                  {blendOptions.map(option => <MenuItem key={option.value} value={option.value}>{option.label}</MenuItem>)}
                </Select>
              </FormControl>
            </div>
            <CompactSlider label="Opacity" value={preview} min={0} max={100} display={`${preview}%`}
              onChange={value => setPreview(value)} />
            <Button size="small" disabled={!active || active.locked || preview === Math.round(active.opacity * 100)}
              onClick={() => active && state.setLayerOpacity(active.id, preview / 100)}>Apply opacity</Button>
            <div className="mask-actions">
              <Button size="small" disabled={!state.selection || !active || active.locked}
                onClick={() => active && state.applySelectionMask(active.id)}>Mask from selection</Button>
              <Button size="small" disabled={!active?.mask || active.locked}
                onClick={() => active && state.clearLayerMask(active.id)}>Remove mask</Button>
            </div>
          </section>
        </>
      )}

      {panel === 'properties' && (
        <div className="properties-box">
          <div className="property-heading">Document</div>
          <div className="property-line">Name <strong>{doc.name}</strong></div>
          <div className="property-line">Size <strong>{doc.width} × {doc.height} px</strong></div>
          <div className="property-line">Layers <strong>{flattenLayers(doc.layers).length}</strong></div>
          <div className="property-heading">{activeShape ? 'Vector object' : 'Selected layer'}</div>
          {active && !active.locked ? (
            <div className="number-grid">
              <InspectorNumber label="X" value={activeShape?.x ?? active.x} onChange={value => changeNumber('x', value)} />
              <InspectorNumber label="Y" value={activeShape?.y ?? active.y} onChange={value => changeNumber('y', value)} />
              {activeShape && (
                <>
                  <InspectorNumber label="Width" value={activeShape.width} onChange={value => changeNumber('width', value)} />
                  <InspectorNumber label="Height" value={activeShape.height} onChange={value => changeNumber('height', value)} />
                </>
              )}
              {(activeShape || active.type === 'raster') && (
                <InspectorNumber label="Rotation °" value={activeShape?.rotation ?? (active.type === 'raster' ? active.rotation ?? 0 : 0)}
                  onChange={value => changeNumber('rotation', value)} />
              )}
            </div>
          ) : <p className="small-note">Select an unlocked layer or vector object to edit its properties.</p>}
          {activeShape && (
            <Button size="small" startIcon={<Delete />} onClick={() => {
              state.removeShape(activeShape.id);
              state.selectShape(null);
            }}>Delete selected object</Button>
          )}
          {activeShape?.kind === 'path' && <p className="small-note">Press A to edit cubic Bézier anchors and handles.</p>}
        </div>
      )}

      {panel === 'history' && (
        <div className="properties-box">
          <div className="property-heading">Editing history</div>
          <div className="property-line">Undo steps <strong>{tab.past.length}</strong></div>
          <div className="property-line">Redo steps <strong>{tab.future.length}</strong></div>
          <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
            <Button variant="outlined" size="small" startIcon={<Undo />}
              onClick={state.undo} disabled={!tab.past.length}>Undo</Button>
            <Button variant="outlined" size="small" startIcon={<Redo />}
              onClick={state.redo} disabled={!tab.future.length}>Redo</Button>
          </Stack>
          <p className="small-note">History is capped at 40 steps and approximately 48 MiB of stored snapshots.</p>
        </div>
      )}
    </aside>
  );
}

export default function App() {
  const state = useEditor();
  const theme = useMemo(() => makeTheme(state.workspace), [state.workspace]);
  const tab = activeTab(state);
  const doc = tab.doc;
  const [newOpen, setNewOpen] = useState(false);
  const [name, setName] = useState('Untitled artwork');
  const [width, setWidth] = useState(1280);
  const [height, setHeight] = useState(800);
  const [background, setBackground] = useState('#ffffff');
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const [exportAnchor, setExportAnchor] = useState<HTMLElement | null>(null);
  const [themeAnchor, setThemeAnchor] = useState<HTMLElement | null>(null);
  const [notice, setNotice] = useState('Ready to create');
  const [errorText, setErrorText] = useState<string | null>(null);

  function handleError(error: unknown): void {
    const message = error instanceof Error ? error.message : String(error);
    setNotice(`Error: ${message}`);
    setErrorText(message);
  }

  function guarded(operation: Promise<boolean>, message: string): void {
    void operation.then(completed => {
      if (completed) setNotice(message);
    }).catch(handleError);
  }

  useEffect(() => {
    function handleKey(event: KeyboardEvent): void {
      const target = event.target as HTMLElement | null;
      if (target && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName))) return;
      if (document.querySelector('[role="dialog"], [role="menu"]')) return;
      const modifier = event.ctrlKey || event.metaKey;
      const key = event.key.toLowerCase();
      const current = useEditor.getState();

      if (modifier) {
        switch (key) {
          case 'n':
            event.preventDefault();
            setNewOpen(true);
            return;
          case 'o':
            event.preventDefault();
            guarded(openProject(), 'Project opened');
            return;
          case 's':
            event.preventDefault();
            guarded(saveProject(event.shiftKey), 'Project saved');
            return;
          case 'z':
            event.preventDefault();
            if (event.shiftKey) current.redo(); else current.undo();
            return;
          case 'y':
            event.preventDefault();
            current.redo();
            return;
          case 'd':
            event.preventDefault();
            current.duplicateLayer();
            return;
          case 'a':
            event.preventDefault();
            current.setSelection(event.shiftKey ? null : {
              x: 0, y: 0, width: activeTab(current).doc.width, height: activeTab(current).doc.height,
            });
            return;
        }
        return;
      }

      if (key === 'tab' && target?.tagName === 'CANVAS') {
        event.preventDefault();
        current.setFocusMode(!current.focusMode);
      } else if (key === 'delete' && current.selectedShapeId) {
        current.removeShape(current.selectedShapeId);
        current.selectShape(null);
      } else if (key === 'escape') {
        current.selectShape(null);
        current.setSelection(null);
      } else {
        const found = tools.find(tool => tool.shortcut.toLowerCase() === key);
        if (found) current.setTool(found.id);
      }
    }

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    let mounted = true;
    void getRecovery().then(documents => {
      if (!mounted || documents.length === 0) return;
      if (window.confirm(`Spectrum found ${documents.length} recoverable document(s). Restore them?`)) {
        for (const recovered of documents) useEditor.getState().openDoc(recovered);
        setNotice(`${documents.length} document(s) recovered`);
      }
    }).catch(() => {
      // Private browsing can block IndexedDB. Editing remains available.
    });
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (state.showWelcome) return;
    const timer = window.setTimeout(() => {
      void storeRecovery(state.tabs.filter(item => item.dirty).map(item => item.doc)).catch(() => {
        setNotice('Recovery storage unavailable; save your project regularly.');
      });
    }, 4500);
    return () => window.clearTimeout(timer);
  }, [state.tabs, state.showWelcome]);

  function create(): void {
    if (!validSize(width, height)) {
      handleError(new Error('Canvas must be 1–16384 pixels per side and at most 64 million pixels.'));
      return;
    }
    state.newDoc(name, width, height, background);
    setNewOpen(false);
    setNotice('New canvas created');
  }

  const fileCommands = [
    { name: 'New document', icon: <Add />, action: () => setNewOpen(true) },
    { name: 'Open project', icon: <FileOpen />, action: () => guarded(openProject(), 'Project opened') },
    { name: 'Import image', icon: <Image />, action: () => guarded(importImage(), 'Image imported') },
    { name: 'Save project', icon: <Save />, action: () => guarded(saveProject(), 'Project saved') },
    { name: 'Save project as…', icon: <Save />, action: () => guarded(saveProject(true), 'Project saved') },
    { name: 'Export PNG', icon: <Download />, action: () => guarded(exportImage('png'), 'PNG exported') },
    { name: 'Export SVG', icon: <ShapeLine />, action: () => guarded(exportSvg(), 'SVG exported') },
  ];

  return (
    <ThemeProvider theme={theme}>
      <div className={`app theme-${state.workspace} ${state.focusMode ? 'focus-mode' : ''}`}>

        <header className="titlebar">
          <div className="brand">
            <div className="brand-mark">✦</div>
            <span>Spectrum</span>
            <span className="badge">0.1</span>
          </div>
          <div className="title-actions">
            <Button size="small" startIcon={<MenuIcon />} onClick={event => setMenuAnchor(event.currentTarget)}>File</Button>
            <Button size="small" onClick={state.undo} startIcon={<Undo />} disabled={!tab.past.length}>Undo</Button>
            <Button size="small" onClick={state.redo} startIcon={<Redo />} disabled={!tab.future.length}>Redo</Button>
            <span className="title-sep" />
            <Button size="small" startIcon={<FileOpen />} onClick={() => guarded(openProject(), 'Project opened')}>Open</Button>
            <Button variant="contained" size="small" startIcon={<Save />}
              onClick={() => guarded(saveProject(), 'Project saved')}>Save</Button>
            <Button size="small" startIcon={<Download />}
              onClick={event => setExportAnchor(event.currentTarget)}>Export</Button>
          </div>
          <div className="title-right">
            <span className="live-dot" />
            <span>Free & open source</span>
            <ActionIcon title="Toggle left tools" onClick={() => state.setToolsOpen(!state.toolsOpen)}><MenuIcon fontSize="small" /></ActionIcon>
            <ActionIcon title="Toggle inspector" onClick={() => state.setInspectorOpen(!state.inspectorOpen)}><ViewSidebar fontSize="small" /></ActionIcon>
            <ActionIcon title="Focus mode (Tab on canvas)" active={state.focusMode}
              onClick={() => state.setFocusMode(!state.focusMode)}><FlipToFront fontSize="small" /></ActionIcon>
            <ActionIcon title="Choose appearance" onClick={event => {
              setThemeAnchor(event.currentTarget);
            }}><Palette fontSize="small" /></ActionIcon>
          </div>
        </header>

        <DocumentTabs state={state} openNew={() => setNewOpen(true)} />
        <div className="editor-grid">
          {state.toolsOpen && !state.focusMode && <ToolRail state={state} openNew={() => setNewOpen(true)} />}
          <main className="main-editor">
            <ContextToolbar state={state} />
            <Canvas onError={handleError} />
            <footer className="statusbar">
              <div><span className="status-led" />{notice}</div>
              <div>
                {doc.width} × {doc.height} px
                <span className="status-sep">|</span>{doc.layers.length} layers
                <span className="status-sep">|</span>{state.workspace} theme
                <span className="status-sep">|</span>Spectrum 0.1
              </div>
            </footer>
          </main>
          {state.inspectorOpen && !state.focusMode && <Inspector state={state} />}
        </div>

        {state.showWelcome && (
          <div className="welcome-scrim">
            <div className="welcome-card">
              <div className="welcome-logo">✦</div>
              <p className="eyebrow">A NEW SPACE FOR IDEAS</p>
              <h1>Create without<br /><em>limits.</em></h1>
              <p className="welcome-desc">
                Meet Spectrum. An open-source canvas for pixels, vectors, and everything in between.
                Entirely yours. Entirely free.
              </p>
              <Stack direction="row" spacing={1.5} justifyContent="center">
                <Button size="large" variant="contained" startIcon={<Add />}
                  onClick={() => setNewOpen(true)}>New document</Button>
                <Button size="large" variant="outlined" startIcon={<FolderOpen />}
                  onClick={() => guarded(openProject(), 'Project opened')}>Open project</Button>
              </Stack>
              <Button sx={{ mt: 1 }} size="small" startIcon={<PhotoCamera />}
                onClick={() => guarded(importImage(), 'Image imported')}>Import an image</Button>
              <div className="welcome-foot"><Code fontSize="small" /> Free & open source <span>·</span> Version 0.1</div>
            </div>
          </div>
        )}

        <Dialog open={newOpen} onClose={() => setNewOpen(false)} fullWidth maxWidth="xs">
          <DialogTitle>New document</DialogTitle>
          <DialogContent>
            <Stack spacing={2} sx={{ pt: 1 }}>
              <TextField label="Document name" value={name} onChange={event => setName(event.target.value)} />
              <Stack direction="row" spacing={2}>
                <TextField label="Width (px)" type="number" value={width}
                  onChange={event => setWidth(Number(event.target.value))} />
                <TextField label="Height (px)" type="number" value={height}
                  onChange={event => setHeight(Number(event.target.value))} />
              </Stack>
              <Typography variant="body2">Background</Typography>
              <Stack direction="row" spacing={1} alignItems="center">
                <Button variant={background === '#ffffff' ? 'contained' : 'outlined'} size="small"
                  onClick={() => setBackground('#ffffff')}>White</Button>
                <Button variant={background === 'transparent' ? 'contained' : 'outlined'} size="small"
                  onClick={() => setBackground('transparent')}>Transparent</Button>
                <input aria-label="Custom background" title="Custom background" type="color"
                  value={background === 'transparent' ? '#ffffff' : background}
                  onChange={event => setBackground(event.target.value)} />
              </Stack>
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setNewOpen(false)}>Cancel</Button>
            <Button variant="contained" onClick={create}>Create document</Button>
          </DialogActions>
        </Dialog>

        <Menu anchorEl={menuAnchor} open={Boolean(menuAnchor)} onClose={() => setMenuAnchor(null)}>
          {fileCommands.map(command => (
            <MenuItem key={command.name} onClick={() => { setMenuAnchor(null); command.action(); }}>
              <span className="menu-icon">{command.icon}</span>{command.name}
            </MenuItem>
          ))}
        </Menu>

        <Snackbar open={Boolean(errorText)} autoHideDuration={7000} onClose={() => setErrorText(null)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
          <Alert severity="error" variant="filled" onClose={() => setErrorText(null)}>{errorText}</Alert>
        </Snackbar>

        <Menu anchorEl={themeAnchor} open={Boolean(themeAnchor)} onClose={() => setThemeAnchor(null)}>
          {([
            { id: 'glass', name: 'Spectrum Glass', subtitle: 'Translucent · immersive · luminous' },
            { id: 'material', name: 'Material You', subtitle: 'Bright · tonal · expressive' },
            { id: 'classic', name: 'Classic Desktop', subtitle: 'Dense · flat · traditional' },
          ] as const).map(choice => (
            <MenuItem key={choice.id} selected={state.workspace === choice.id} onClick={() => {
              state.setWorkspace(choice.id);
              setThemeAnchor(null);
            }}>
              <span className={`theme-preview theme-preview-${choice.id}`} />
              <span className="theme-option"><strong>{choice.name}</strong><small>{choice.subtitle}</small></span>
              {state.workspace === choice.id && <span className="theme-tick">✓</span>}
            </MenuItem>
          ))}
        </Menu>

        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)} onClose={() => setExportAnchor(null)}>
          {(['png', 'jpeg', 'webp', 'svg'] as const).map(format => (
            <MenuItem key={format} onClick={() => {
              setExportAnchor(null);
              guarded(format === 'svg' ? exportSvg() : exportImage(format), `${format.toUpperCase()} exported`);
            }}>
              <Download sx={{ mr: 1, fontSize: 18 }} />{format.toUpperCase()}
            </MenuItem>
          ))}
        </Menu>
      </div>
    </ThemeProvider>
  );
}
