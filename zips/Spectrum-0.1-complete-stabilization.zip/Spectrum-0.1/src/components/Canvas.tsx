import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
  type MouseEvent as ReactMouseEvent,
} from 'react';
import { activeLayer, activeTab, useEditor } from '../editor/store';
import { decodeImage, drawChecker, drawShape, renderLayer } from '../editor/render';
import { contains, normalizeRect, rotate, shapeBounds, smoothPath } from '../editor/geometry';
import { previewDrag, type DragOperation } from '../editor/operations';
import { uid, type Layer, type Point, type SelectionRect, type VectorShape } from '../editor/types';
import { drawBrushDab } from '../editor/brush';
import './Canvas.css';

type DrawGesture = {
  kind: 'draw';
  start: Point;
  last: Point;
  layerId: string;
  documentId: string;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  erase: boolean;
  lastPressure: number;
};

type Gesture =
  | { kind: 'pan'; start: Point; original: Point }
  | { kind: 'marquee'; start: Point; last: Point }
  | { kind: 'move'; start: Point; last: Point; layerId: string; shapeId: string | null }
  | { kind: 'transform'; mode: 'rotate' | 'scale'; handle: string; start: Point; last: Point;
      layerId: string; shapeId: string | null; bounds: SelectionRect; rotation: number }
  | { kind: 'node'; layerId: string; shapeId: string; index: number; handle: 'anchor' | 'in' | 'out'; start: Point; last: Point }
  | { kind: 'shape'; start: Point; last: Point; shape: VectorShape }
  | { kind: 'loading'; start: Point; last: Point; layerId: string; documentId: string;
      erase: boolean; pressure: number; finish: boolean }
  | DrawGesture;

interface CanvasProps {
  onError?: (error: unknown) => void;
}

function layerBounds(layer: Layer, docWidth: number, docHeight: number): SelectionRect {
  if (layer.type === 'raster') {
    return {
      x: layer.x,
      y: layer.y,
      width: (layer.imageWidth ?? docWidth) * (layer.scaleX ?? 1),
      height: (layer.imageHeight ?? docHeight) * (layer.scaleY ?? 1),
    };
  }
  return { x: layer.x, y: layer.y, width: docWidth, height: docHeight };
}

function shapeHit(point: Point, shape: VectorShape, layer: Layer, zoom: number): boolean {
  const bounds = shapeBounds(shape, layer);
  const center = { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 };
  const unrotated = shape.rotation ? rotate(point, center, -shape.rotation) : point;
  const tolerance = Math.max(4 / zoom, shape.strokeWidth / 2);
  return contains({
    x: bounds.x - tolerance,
    y: bounds.y - tolerance,
    width: bounds.width + tolerance * 2,
    height: bounds.height + tolerance * 2,
  }, unrotated);
}

function corners(bounds: SelectionRect): Record<string, Point> {
  return {
    nw: { x: bounds.x, y: bounds.y },
    ne: { x: bounds.x + bounds.width, y: bounds.y },
    sw: { x: bounds.x, y: bounds.y + bounds.height },
    se: { x: bounds.x + bounds.width, y: bounds.y + bounds.height },
    rotate: { x: bounds.x + bounds.width / 2, y: bounds.y - 28 },
  };
}

export default function Canvas({ onError }: CanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const gesture = useRef<Gesture | null>(null);
  const raf = useRef<number>(0);
  const [size, setSize] = useState({ width: 800, height: 600 });
  const [cursor, setCursor] = useState<Point | null>(null);
  const [draft, setDraft] = useState<VectorShape | null>(null);
  const [drawing, setDrawing] = useState<HTMLCanvasElement | null>(null);
  const [revision, setRevision] = useState(0);
  const [textEdit, setTextEdit] = useState<{
    id: string | null;
    documentId: string;
    x: number;
    y: number;
    value: string;
    fontSize: number;
    color: string;
  } | null>(null);
  const textCancelled = useRef(false);
  const textCommitted = useRef(false);

  const doc = useEditor(state => activeTab(state).doc);
  const tool = useEditor(state => state.tool);
  const zoom = useEditor(state => state.zoom);
  const pan = useEditor(state => state.pan);
  const grid = useEditor(state => state.grid);
  const color = useEditor(state => state.color);
  const fill = useEditor(state => state.fill);
  const strokeWidth = useEditor(state => state.strokeWidth);
  const selectedShapeId = useEditor(state => state.selectedShapeId);
  const selectedNodeIndex = useEditor(state => state.selectedNodeIndex);
  const selection = useEditor(state => state.selection);
  const smoothing = useEditor(state => state.smoothing);
  const focusMode = useEditor(state => state.focusMode);

  const invalidate = useCallback((): void => {
    if (raf.current) return;
    raf.current = requestAnimationFrame(() => {
      raf.current = 0;
      setRevision(previous => previous + 1);
    });
  }, []);

  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  useEffect(() => {
    if (!hostRef.current) return;
    const observer = new ResizeObserver(entries => {
      const bounds = entries[0]?.contentRect;
      if (bounds) {
        setSize({ width: Math.max(1, Math.floor(bounds.width)), height: Math.max(1, Math.floor(bounds.height)) });
      }
    });
    observer.observe(hostRef.current);
    return () => observer.disconnect();
  }, []);

  const position = useCallback((event: { clientX: number; clientY: number }): Point => {
    const bounds = canvasRef.current!.getBoundingClientRect();
    return {
      x: (event.clientX - bounds.left - bounds.width / 2 - pan.x) / zoom + doc.width / 2,
      y: (event.clientY - bounds.top - bounds.height / 2 - pan.y) / zoom + doc.height / 2,
    };
  }, [doc.height, doc.width, pan.x, pan.y, zoom]);

  function operationFromGesture(current: Gesture | null): { layerId: string; action: DragOperation } | null {
    if (!current) return null;
    if (current.kind === 'move' || current.kind === 'node') {
      const { x: dx, y: dy } = {
        x: current.last.x - current.start.x,
        y: current.last.y - current.start.y,
      };
      if (current.kind === 'move') {
        return { layerId: current.layerId, action: { kind: 'move', shapeId: current.shapeId, dx, dy } };
      }
      return {
        layerId: current.layerId,
        action: {
          kind: 'node', shapeId: current.shapeId, index: current.index,
          handle: current.handle, dx, dy,
        },
      };
    }
    if (current.kind === 'transform') {
      return {
        layerId: current.layerId,
        action: {
          kind: 'transform', shapeId: current.shapeId, mode: current.mode,
          handle: current.handle, bounds: current.bounds,
          start: current.start, last: current.last,
        },
      };
    }
    return null;
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const targetWidth = Math.round(size.width * dpr);
    const targetHeight = Math.round(size.height * dpr);
    if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
      canvas.width = targetWidth;
      canvas.height = targetHeight;
    }
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size.width, size.height);
    ctx.translate(size.width / 2 + pan.x - doc.width * zoom / 2, size.height / 2 + pan.y - doc.height * zoom / 2);
    ctx.scale(zoom, zoom);
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,.45)';
    ctx.shadowBlur = 24 / zoom;
    ctx.fillStyle = 'rgba(0,0,0,.18)';
    ctx.fillRect(0, 0, doc.width, doc.height);
    ctx.restore();

    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, doc.width, doc.height);
    ctx.clip();
    if (doc.background === 'transparent') drawChecker(ctx, doc.width, doc.height);
    else {
      ctx.fillStyle = doc.background;
      ctx.fillRect(0, 0, doc.width, doc.height);
    }

    const working = gesture.current?.kind === 'draw' ? gesture.current : null;
    const operation = operationFromGesture(gesture.current);
    const layers = doc.layers.map(layer => operation && layer.id === operation.layerId
      ? previewDrag(layer, operation.action, doc.width, doc.height) : layer);
    for (const layer of layers) {
      if (drawing && working && layer.id === working.layerId && layer.type === 'raster' && layer.visible) {
        ctx.save();
        ctx.globalAlpha = layer.opacity;
        ctx.globalCompositeOperation = layer.blend;
        if (layer.mask) {
          ctx.beginPath();
          ctx.rect(layer.mask.x, layer.mask.y, layer.mask.width, layer.mask.height);
          ctx.clip();
        }
        ctx.drawImage(drawing, layer.x, layer.y);
        ctx.restore();
      } else renderLayer(ctx, layer, invalidate);
    }

    if (draft) drawShape(ctx, draft);
    if (grid && zoom >= 0.6) {
      ctx.strokeStyle = 'rgba(150,160,185,.22)';
      ctx.lineWidth = 1 / zoom;
      ctx.beginPath();
      for (let x = 0; x <= doc.width; x += 50) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, doc.height);
      }
      for (let y = 0; y <= doc.height; y += 50) {
        ctx.moveTo(0, y);
        ctx.lineTo(doc.width, y);
      }
      ctx.stroke();
    }
    ctx.restore();

    const active = layers.find(layer => layer.id === doc.activeLayerId);
    const selected = active?.type === 'vector' ? active.shapes.find(shape => shape.id === selectedShapeId) : undefined;
    const bounds = selected && active ? shapeBounds(selected, active) : tool === 'move' && active && !selectedShapeId
      ? layerBounds(active, doc.width, doc.height) : null;
    const drag = gesture.current;

    if (bounds && !active?.locked && (tool === 'move' || tool === 'node')) {
      const outline = bounds;
      const rotation = selected?.rotation ?? (active?.type === 'raster' ? active.rotation ?? 0 : 0);
      const center = { x: outline.x + outline.width / 2, y: outline.y + outline.height / 2 };
      ctx.save();
      ctx.translate(center.x, center.y);
      ctx.rotate(rotation * Math.PI / 180);
      ctx.translate(-center.x, -center.y);
      ctx.strokeStyle = '#8adfff';
      ctx.fillStyle = '#f7fcff';
      ctx.lineWidth = 1.4 / zoom;
      ctx.setLineDash([5 / zoom, 3 / zoom]);
      ctx.strokeRect(outline.x, outline.y, outline.width, outline.height);
      ctx.setLineDash([]);
      if (tool === 'move') {
        for (const [key, point] of Object.entries(corners(outline))) {
          const radius = key === 'rotate' ? 5 : 4;
          ctx.beginPath();
          ctx.arc(point.x, point.y, radius / zoom, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
        const upper = corners(outline);
        ctx.beginPath();
        ctx.moveTo(outline.x + outline.width / 2, outline.y);
        ctx.lineTo(upper.rotate.x, upper.rotate.y);
        ctx.stroke();
      }
      ctx.restore();
    }

    if (tool === 'node' && selected?.nodes?.length && active) {
      ctx.save();
      ctx.lineWidth = 1.2 / zoom;
      selected.nodes.forEach((node, index) => {
        for (const key of ['in', 'out'] as const) {
          const handle = node[key];
          if (!handle) continue;
          ctx.strokeStyle = '#ffc68b';
          ctx.beginPath();
          ctx.moveTo(node.x + active.x, node.y + active.y);
          ctx.lineTo(handle.x + active.x, handle.y + active.y);
          ctx.stroke();
          ctx.fillStyle = '#f4bf74';
          ctx.fillRect(handle.x + active.x - 3 / zoom, handle.y + active.y - 3 / zoom, 6 / zoom, 6 / zoom);
        }
        ctx.fillStyle = selectedNodeIndex === index ? '#f5b461' : '#f1faff';
        ctx.strokeStyle = '#2a92d6';
        ctx.fillRect(node.x + active.x - 4 / zoom, node.y + active.y - 4 / zoom, 8 / zoom, 8 / zoom);
        ctx.strokeRect(node.x + active.x - 4 / zoom, node.y + active.y - 4 / zoom, 8 / zoom, 8 / zoom);
      });
      ctx.restore();
    }

    const rectangle = drag?.kind === 'marquee' ? normalizeRect(drag.start, drag.last) : selection;
    if (rectangle) {
      ctx.save();
      ctx.strokeStyle = '#70d9ff';
      ctx.lineWidth = 1.4 / zoom;
      ctx.setLineDash([6 / zoom, 4 / zoom]);
      ctx.strokeRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
      ctx.restore();
    }
  }, [doc, size, zoom, pan, grid, draft, drawing, selectedShapeId, selectedNodeIndex, selection, tool, revision, invalidate]);

  function dab(current: DrawGesture, point: Point, pressure: number): void {
    const editor = useEditor.getState();
    const document = activeTab(editor).doc;
    const layer = document.layers.find(item => item.id === current.layerId);
    if (document.id !== current.documentId || !layer || layer.type !== 'raster') return;
    const last = current.last;
    const filtered = {
      x: last.x * editor.smoothing + point.x * (1 - editor.smoothing),
      y: last.y * editor.smoothing + point.y * (1 - editor.smoothing),
    };
    const distance = Math.hypot(filtered.x - last.x, filtered.y - last.y);
    const radius = editor.strokeWidth / 2;
    const steps = Math.max(1, Math.ceil(distance / Math.max(0.7, radius * 0.32)));
    const ctx = current.ctx;
    ctx.save();
    const mask = editor.selection;
    if (mask) {
      ctx.beginPath();
      ctx.rect(mask.x - layer.x, mask.y - layer.y, mask.width, mask.height);
      ctx.clip();
    }
    if (layer.mask) {
      ctx.beginPath();
      ctx.rect(layer.mask.x - layer.x, layer.mask.y - layer.y, layer.mask.width, layer.mask.height);
      ctx.clip();
    }
    for (let index = 1; index <= steps; index++) {
      const fraction = index / steps;
      const position = {
        x: last.x + (filtered.x - last.x) * fraction - layer.x,
        y: last.y + (filtered.y - last.y) * fraction - layer.y,
      };
      const opacityAtPoint = editor.opacity * Math.max(0.1, pressure || 1);
      drawBrushDab(ctx, position, {
        radius: radius * Math.max(0.2, pressure || 1),
        hardness: editor.hardness,
        opacity: opacityAtPoint,
        color: editor.color,
        erase: current.erase,
      });
    }
    ctx.restore();
    current.last = filtered;
    current.lastPressure = pressure;
    invalidate();
  }

  function commitDrawing(current: DrawGesture): void {
    const image = current.canvas.toDataURL('image/png');
    const state = useEditor.getState();
    if (activeTab(state).doc.id === current.documentId) {
      state.mutate(document => {
        const layer = document.layers.find(item => item.id === current.layerId);
        if (layer?.type === 'raster' && !layer.locked) {
          layer.image = image;
          layer.imageWidth = current.canvas.width;
          layer.imageHeight = current.canvas.height;
        }
      });
    }
    if (gesture.current === current) gesture.current = null;
    setDrawing(null);
  }

  function startDrawing(start: Point, layerId: string, source: string, erase: boolean, pressure: number): void {
    const documentId = activeTab(useEditor.getState()).doc.id;
    const pending: Extract<Gesture, { kind: 'loading' }> = {
      kind: 'loading', start, last: start, layerId, documentId, erase, pressure, finish: false,
    };
    gesture.current = pending;
    void decodeImage(source).then(image => {
      if (gesture.current !== pending) return;
      const document = activeTab(useEditor.getState()).doc;
      const layer = document.layers.find(item => item.id === layerId);
      if (document.id !== documentId || layer?.type !== 'raster' || layer.locked) {
        gesture.current = null;
        return;
      }
      const working = window.document.createElement('canvas');
      working.width = document.width;
      working.height = document.height;
      const ctx = working.getContext('2d');
      if (!ctx) throw new Error('Canvas 2D is unavailable.');
      if (image) ctx.drawImage(image, 0, 0);
      const current: DrawGesture = {
        kind: 'draw', start, last: start, layerId, documentId, canvas: working, ctx, erase, lastPressure: pressure,
      };
      gesture.current = current;
      dab(current, start, pressure);
      if (pending.last.x !== start.x || pending.last.y !== start.y) dab(current, pending.last, pressure);
      setDrawing(working);
      if (pending.finish) commitDrawing(current);
    }).catch(error => {
      gesture.current = null;
      setDrawing(null);
      onError?.(error);
    });
  }

  function pointerDown(event: ReactPointerEvent<HTMLCanvasElement>): void {
    if (event.button !== 0 && event.button !== 1) return;
    const point = position(event);
    setCursor(point);
    event.currentTarget.setPointerCapture(event.pointerId);
    event.currentTarget.focus({ preventScroll: true });
    const state = useEditor.getState();
    const layer = activeLayer(state);

    if (event.button === 1 || tool === 'hand' || event.altKey) {
      gesture.current = { kind: 'pan', start: { x: event.clientX, y: event.clientY }, original: { ...pan } };
      return;
    }
    if (tool === 'marquee') {
      gesture.current = { kind: 'marquee', start: point, last: point };
      state.setSelection(null);
      return;
    }
    if (tool === 'eyedropper') {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      const bounds = canvas?.getBoundingClientRect();
      if (!canvas || !ctx || !bounds) return;
      const x = Math.floor((event.clientX - bounds.left) * canvas.width / bounds.width);
      const y = Math.floor((event.clientY - bounds.top) * canvas.height / bounds.height);
      if (x < 0 || y < 0 || x >= canvas.width || y >= canvas.height) return;
      const sample = ctx.getImageData(x, y, 1, 1).data;
      state.setColor(`#${[...sample.slice(0, 3)].map(value => value.toString(16).padStart(2, '0')).join('')}`);
      return;
    }
    if (tool === 'node') {
      const vectorLayer = layer?.type === 'vector' ? layer : null;
      const selected = vectorLayer?.shapes.find(shape => shape.id === selectedShapeId);
      if (selected?.nodes && vectorLayer) {
        for (let index = selected.nodes.length - 1; index >= 0; index--) {
          const node = selected.nodes[index];
          for (const handle of ['in', 'out', 'anchor'] as const) {
            const target = handle === 'anchor' ? node : node[handle];
            if (!target || Math.hypot(point.x - target.x - vectorLayer.x, point.y - target.y - vectorLayer.y) > 9 / zoom) continue;
            gesture.current = { kind: 'node', layerId: vectorLayer.id, shapeId: selected.id, index, handle, start: point, last: point };
            state.selectNode(index);
            return;
          }
        }
      }
      const hit = [...doc.layers].reverse().flatMap(item => item.type === 'vector' && !item.locked && item.visible
        ? [...item.shapes].reverse().map(shape => ({ layer: item, shape })) : [])
        .find(entry => shapeHit(point, entry.shape, entry.layer, zoom));
      if (hit) state.selectLayer(hit.layer.id);
      state.selectShape(hit?.shape.id ?? null);
      return;
    }
    if (tool === 'move') {
      if (layer && !layer.locked) {
        const shape = layer.type === 'vector' ? layer.shapes.find(item => item.id === selectedShapeId) : undefined;
        const bounds = shape ? shapeBounds(shape, layer) : layerBounds(layer, doc.width, doc.height);
        const rotation = shape?.rotation ?? (layer.type === 'raster' ? layer.rotation ?? 0 : 0);
        const center = { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 };
        const local = rotation ? rotate(point, center, -rotation) : point;
        const handle = Object.entries(corners(bounds)).find(([, handlePoint]) =>
          Math.hypot(local.x - handlePoint.x, local.y - handlePoint.y) <= 9 / zoom);
        if (handle) {
          gesture.current = {
            kind: 'transform', mode: handle[0] === 'rotate' ? 'rotate' : 'scale', handle: handle[0],
            start: point, last: point, layerId: layer.id, shapeId: shape?.id ?? null, bounds, rotation,
          };
          return;
        }
      }
      const hit = [...doc.layers].reverse().flatMap(item => item.type === 'vector' && !item.locked && item.visible
        ? [...item.shapes].reverse().map(shape => ({ layer: item, shape })) : [])
        .find(entry => shapeHit(point, entry.shape, entry.layer, zoom));
      if (hit) {
        state.selectLayer(hit.layer.id);
        state.selectShape(hit.shape.id);
        gesture.current = { kind: 'move', start: point, last: point, layerId: hit.layer.id, shapeId: hit.shape.id };
      } else if (layer && !layer.locked && layer.visible) {
        state.selectShape(null);
        gesture.current = { kind: 'move', start: point, last: point, layerId: layer.id, shapeId: null };
      }
      return;
    }
    if (tool === 'brush' || tool === 'eraser') {
      if (layer?.locked || (layer && !layer.visible)) return;
      if (layer?.type === 'raster' && ((layer.scaleX ?? 1) !== 1 || (layer.scaleY ?? 1) !== 1 || layer.rotation)) {
        onError?.(new Error('Rasterize transformed layers or paint on a new layer.'));
        return;
      }
      if (layer?.type !== 'raster') state.addLayer('raster');
      const target = activeLayer(useEditor.getState());
      if (target?.type === 'raster') startDrawing(point, target.id, target.image, tool === 'eraser', event.pointerType === 'pen' ? event.pressure || 1 : 1);
      return;
    }
    if (tool === 'text') {
      textCancelled.current = false;
      textCommitted.current = false;
      setTextEdit({
        id: null, documentId: doc.id, x: point.x, y: point.y,
        value: '', fontSize: Math.max(16, strokeWidth * 3), color,
      });
      return;
    }
    if (tool === 'rectangle' || tool === 'ellipse' || tool === 'line' || tool === 'pen') {
      const kind = tool === 'rectangle' ? 'rect' : tool === 'ellipse' ? 'ellipse' : tool === 'line' ? 'line' : 'path';
      const shape: VectorShape = {
        id: uid(), kind, x: point.x, y: point.y, width: 0, height: 0,
        fill: kind === 'rect' || kind === 'ellipse' ? fill : 'none',
        stroke: color, strokeWidth: Math.max(1, strokeWidth / 3),
        points: kind === 'path' ? [point] : undefined,
      };
      gesture.current = { kind: 'shape', start: point, last: point, shape };
      setDraft(shape);
    }
  }

  function pointerMove(event: ReactPointerEvent<HTMLCanvasElement>): void {
    const point = position(event);
    setCursor(point);
    const current = gesture.current;
    if (!current) return;
    if (current.kind === 'pan') {
      useEditor.getState().setPan({
        x: current.original.x + event.clientX - current.start.x,
        y: current.original.y + event.clientY - current.start.y,
      });
    } else if (current.kind === 'loading') {
      current.last = point;
    } else if (current.kind === 'draw') {
      dab(current, point, event.pointerType === 'pen' ? event.pressure || 1 : 1);
    } else if (current.kind === 'node' || current.kind === 'move' || current.kind === 'transform' || current.kind === 'marquee') {
      current.last = point;
      invalidate();
    } else if (current.kind === 'shape') {
      const shape = current.shape;
      if (shape.kind === 'path') {
        shape.points?.push(point);
        const bounds = shapeBounds(shape);
        Object.assign(shape, bounds);
      } else if (shape.kind === 'line') {
        shape.width = point.x - current.start.x;
        shape.height = point.y - current.start.y;
      } else {
        Object.assign(shape, normalizeRect(current.start, point));
      }
      current.last = point;
      setDraft({ ...shape, points: shape.points ? [...shape.points] : undefined });
    }
  }

  function editText(event: ReactMouseEvent<HTMLCanvasElement>): void {
    if (tool !== 'move') return;
    const point = position(event);
    for (const layer of [...doc.layers].reverse()) {
      if (layer.type !== 'vector' || !layer.visible || layer.locked) continue;
      const shape = [...layer.shapes].reverse().find(item => item.kind === 'text' && shapeHit(point, item, layer, zoom));
      if (!shape) continue;
      textCancelled.current = false;
      textCommitted.current = false;
      useEditor.getState().selectLayer(layer.id);
      useEditor.getState().selectShape(shape.id);
      setTextEdit({
        id: shape.id, documentId: doc.id,
        x: shape.x + layer.x, y: shape.y + layer.y,
        value: shape.text ?? '', fontSize: shape.fontSize ?? 48, color: shape.fill,
      });
      return;
    }
  }

  function finishText(): void {
    if (textCommitted.current) return;
    textCommitted.current = true;
    const draft = textEdit;
    setTextEdit(null);
    if (!draft || textCancelled.current || !draft.value.trim()) return;
    const editor = useEditor.getState();
    if (activeTab(editor).doc.id !== draft.documentId) return;
    const size = Math.max(16, draft.fontSize);
    const lines = draft.value.split('\n');
    const width = Math.max(20, ...lines.map(line => line.length * size * 0.62));
    const height = lines.length * size * 1.25;
    if (draft.id) {
      editor.updateShape(draft.id, shape => {
        shape.text = draft.value;
        shape.width = width;
        shape.height = height;
      });
    } else {
      const shape: VectorShape = {
        id: uid(), kind: 'text', x: draft.x, y: draft.y,
        width, height, fill: draft.color, stroke: 'none', strokeWidth: 0,
        fontSize: size, text: draft.value,
      };
      editor.addShape(shape);
      editor.selectShape(shape.id);
    }
  }

  function pointerUp(): void {
    const current = gesture.current;
    if (!current) return;
    if (current.kind === 'loading') {
      current.finish = true;
      return;
    }
    gesture.current = null;
    const state = useEditor.getState();
    if (current.kind === 'draw') commitDrawing(current);
    if (current.kind === 'marquee') {
      const bounds = normalizeRect(current.start, current.last);
      state.setSelection(bounds.width > 2 && bounds.height > 2 ? bounds : null);
    }
    if (current.kind === 'shape') {
      const shape = current.shape;
      if (shape.kind === 'path' && shape.points && shape.points.length >= 2) {
        shape.nodes = smoothPath(shape.points, 1 - smoothing * 0.5);
        delete shape.points;
        Object.assign(shape, shapeBounds(shape));
      }
      const valid = shape.kind === 'path' ? (shape.nodes?.length ?? 0) >= 2
        : Math.abs(shape.width) > 2 || Math.abs(shape.height) > 2;
      if (valid) {
        state.addShape(shape);
        state.selectShape(shape.id);
      }
      setDraft(null);
    }
    const operation = operationFromGesture(current);
    if (operation) {
      const action = operation.action;
      const moved = action.kind === 'transform'
        ? Math.hypot(action.last.x - action.start.x, action.last.y - action.start.y) > 0.1
        : Math.hypot(action.dx, action.dy) > 0.1;
      if (!moved) return;
      state.mutate(document => {
        const index = document.layers.findIndex(layer => layer.id === operation.layerId);
        if (index < 0) return;
        document.layers[index] = previewDrag(document.layers[index], action, document.width, document.height);
      });
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handleWheel = (event: WheelEvent): void => {
      event.preventDefault();
      const editor = useEditor.getState();
      if (event.ctrlKey || event.metaKey) editor.setZoom(editor.zoom * Math.exp(-event.deltaY * 0.0015));
      else if (event.shiftKey) editor.setPan({ x: editor.pan.x - event.deltaY, y: editor.pan.y });
      else editor.setPan({ x: editor.pan.x - event.deltaX, y: editor.pan.y - event.deltaY });
    };
    canvas.addEventListener('wheel', handleWheel, { passive: false });
    return () => canvas.removeEventListener('wheel', handleWheel);
  }, []);

  return (
    <div ref={hostRef} className="canvas-host">
      <canvas
        ref={canvasRef}
        className="artboard-canvas"
        aria-label="Spectrum artwork canvas"
        tabIndex={0}
        style={{ cursor: tool === 'hand' ? 'grab' : tool === 'move' ? 'move' : 'crosshair' }}
        onPointerDown={pointerDown}
        onPointerMove={pointerMove}
        onPointerUp={pointerUp}
        onPointerCancel={pointerUp}
        onDoubleClick={editText}
        onContextMenu={event => event.preventDefault()}
      />
      {focusMode && (
        <button className="focus-exit" type="button"
          onClick={() => useEditor.getState().setFocusMode(false)}
          title="Exit Focus Mode (or press Tab while canvas is focused)">Exit focus</button>
      )}
      {textEdit && (
        <textarea
          className="inline-text-editor"
          aria-label="Edit text on canvas"
          autoFocus
          value={textEdit.value}
          style={{
            left: size.width / 2 + pan.x + (textEdit.x - doc.width / 2) * zoom,
            top: size.height / 2 + pan.y + (textEdit.y - doc.height / 2) * zoom,
            fontSize: Math.max(12, textEdit.fontSize * zoom),
            color: textEdit.color,
          }}
          onChange={event => setTextEdit(current => current ? { ...current, value: event.target.value } : null)}
          onKeyDown={event => {
            if (event.key === 'Escape') {
              textCancelled.current = true;
              setTextEdit(null);
            } else if (event.key === 'Enter' && !event.shiftKey) {
              event.preventDefault();
              finishText();
            }
          }}
          onBlur={finishText}
        />
      )}
      <div className="canvas-hint">
        {cursor ? `${Math.round(cursor.x)}, ${Math.round(cursor.y)}` : 'Canvas'}
        {' · '}{Math.round(zoom * 100)}%{' · '}{doc.width} × {doc.height}
      </div>
    </div>
  );
}

