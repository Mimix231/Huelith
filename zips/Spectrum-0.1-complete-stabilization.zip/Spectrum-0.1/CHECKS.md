# Spectrum 0.1 — Verified Results and Build Limitations

Date: **2026-10-08**. Version remains **0.1.0**.

## Tests run in this environment

| Check | Result |
| --- | --- |
| Node regression and source integrity tests | **38 passed, 0 failed** (`npm test` with globally available TypeScript) |
| Real headless Chromium pixel assertions | **20 passed** (`npm run test:browser` via Python Playwright + `/usr/bin/chromium`) |
| Standalone editor TypeScript modules with strict compiler | **Passed** (`types`, `geometry`, `operations`, `brush`, `render`, `svg`) |
| Full application TypeScript with temporary dependency declaration stand-ins | **Passed**, **not** equivalent to real React/MUI/Zustand/Tauri typechecking |
| CSS parsing via PostCSS | **5 stylesheets parsed** (shared, three themes, canvas CSS) |
| JSON configuration validity | **Passed** (package, Tauri config, capability permissions) |
| Local `.ts`/`.tsx` import resolution and syntax parsing | **Passed** |
| Real React + MUI + Vite production build | **Not run**: npm package downloads unavailable |
| Rust/Tauri compilation and native-window smoke test | **Not run**: `rustc`/`cargo` not installed |
| Complete interactive editor UI in WebView | **Not run**: frontend dependencies unavailable |

## What the Chromium tests actually verify

Canvas2D browser assertions sample **real pixels** for rectangle geometry, transparency, non-destructive clipping masks, cubic Bézier strokes, rotation, embedded PNG loading, raster scaling, soft brush opacity/falloff, hard erasure, and flattened export. Chromium also loads the actual theme stylesheets and checks glass blur, Material rounding, Classic corners and distinct canvas backgrounds. These are not a simulation of clicking the React application.

A defect was found and fixed during this verification pass: using equal radii for a 100% hard radial brush produced a no-op eraser in Chromium. Hard brush dabs now use a solid fill instead; this is covered by a pixel regression assertion.

## What is blocked and why

The environment cannot resolve `registry.npmjs.org`, so `npm install` cannot fetch React, MUI, Zustand, Vite or Tauri JavaScript dependencies. The npm cache has no usable copies of these packages. `rustc` and `cargo` are not installed. Therefore **a real `npm run check`, `npm run build`, `npm run desktop:dev`, or `npm run desktop:build` cannot be certified here**.

Temporary declaration stand-ins were created **outside the delivered project** to find source-level typing mistakes with strict TypeScript enabled. They are intentionally **not included** as project dependencies or fake type declarations, because they could hide real errors in your development environment.

The included `.github/workflows/checks.yml` defines separate frontend, Chromium/Playwright, and Windows Rust CI jobs for ongoing verification when the project is published to GitHub. These CI jobs were **not** run in this environment.

## Continue verification on a Windows development machine

```bash
npm install
npm run verify
npm run dev
npm run desktop:dev
```

Before distributing an installer, run `npm run desktop:build`. If `npm run verify` reveals TypeScript errors with the **real** dependency types, fix them and rerun the suite. See [`ACCEPTANCE.md`](ACCEPTANCE.md) for the end-to-end checklist.

**No claim is made that all 10 development phases have achieved production-grade feature completeness or that Spectrum 0.1 is release-stable.** Their planned foundations are present, and unsupported advanced capabilities are listed clearly in `README.md`.
