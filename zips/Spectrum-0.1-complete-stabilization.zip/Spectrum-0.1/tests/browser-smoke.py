"""Real Chromium Canvas2D smoke test. Requires `pip install playwright` + a Chromium executable."""
import json
import os
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

bundle = sys.stdin.read()
with sync_playwright() as playwright:
    # Prefer a system Chromium locally; CI may use the bundled Playwright browser.
    chromium_path = os.environ.get('CHROMIUM_PATH')
    if not chromium_path and os.path.exists('/usr/bin/chromium'):
        chromium_path = '/usr/bin/chromium'
    launch = {'headless': True, 'args': ['--no-sandbox']}
    if chromium_path:
        launch['executable_path'] = chromium_path
    browser = playwright.chromium.launch(**launch)
    try:
        page = browser.new_page()
        page.goto('about:blank')
        page.add_script_tag(content=bundle)
        checks = page.evaluate(r'''async () => {
          const engine = window.SpectrumTest;
          const results = [];
          function assert(name, condition) {
            if (!condition) throw new Error(`Canvas pixel assertion failed: ${name}`);
            results.push(name);
          }
          function canvas(width = 80, height = 80) {
            const element = document.createElement('canvas');
            element.width = width;
            element.height = height;
            return element;
          }
          function pixel(element, x, y) {
            return [...element.getContext('2d').getImageData(x, y, 1, 1).data];
          }
          function vectorLayer(shape) {
            return {
              id: 'layer', name: 'Vector', visible: true, locked: false,
              opacity: 1, blend: 'source-over', x: 0, y: 0, type: 'vector', shapes: [shape],
            };
          }
          const basic = canvas();
          const rect = {
            kind: 'rect', id: 'rect', x: 10, y: 10, width: 30, height: 30,
            fill: '#ff0000', stroke: 'none', strokeWidth: 0,
          };
          engine.renderLayer(basic.getContext('2d'), vectorLayer(rect));
          assert('rectangle interior red', pixel(basic, 20, 20)[0] > 245);
          assert('transparent rectangle exterior', pixel(basic, 60, 60)[3] === 0);

          const masks = canvas();
          const masked = vectorLayer({ ...rect, x: 0, y: 0, width: 60, height: 60 });
          masked.mask = { x: 10, y: 10, width: 20, height: 20 };
          engine.renderLayer(masks.getContext('2d'), masked);
          assert('mask retains content inside', pixel(masks, 15, 15)[3] === 255);
          assert('mask removes content outside', pixel(masks, 40, 40)[3] === 0);

          const curves = canvas();
          const path = {
            kind: 'path', id: 'curve', x: 0, y: 0, width: 60, height: 0,
            fill: 'none', stroke: '#0000ff', strokeWidth: 8,
            nodes: [{ x: 10, y: 40, out: { x: 20, y: 40 } }, { x: 60, y: 40, in: { x: 50, y: 40 } }],
          };
          engine.renderLayer(curves.getContext('2d'), vectorLayer(path));
          assert('cubic Bézier stroke visible', pixel(curves, 35, 40)[2] > 200);
          assert('cubic Bézier stroke bounded', pixel(curves, 35, 15)[3] === 0);

          const rotated = canvas();
          const rotatedRect = { ...rect, x: 20, y: 30, width: 40, height: 8, rotation: 90 };
          engine.renderLayer(rotated.getContext('2d'), vectorLayer(rotatedRect));
          assert('rotation covers vertical axis', pixel(rotated, 40, 18)[0] > 200);
          assert('rotation does not cover original horizontal corner', pixel(rotated, 25, 34)[3] === 0);

          const base = canvas();
          const imgctx = base.getContext('2d');
          imgctx.fillStyle = '#0000ff';
          imgctx.fillRect(0, 0, 16, 16);
          const raster = {
            id: 'r', name: 'Raster', visible: true, locked: false,
            opacity: 1, blend: 'source-over', x: 20, y: 10,
            image: base.toDataURL('image/png'), imageWidth: 80, imageHeight: 80,
            type: 'raster', scaleX: 0.5, scaleY: 2,
          };
          await engine.prepareImages({ layers: [raster] });
          const composed = canvas();
          engine.renderLayer(composed.getContext('2d'), raster);
          assert('raster data URL is decoded', pixel(composed, 21, 12)[2] > 200);
          assert('raster scale is applied', pixel(composed, 35, 40)[3] === 0);
          const brushed = canvas();
          const brushCtx = brushed.getContext('2d');
          engine.drawBrushDab(brushCtx, { x: 30, y: 30 }, {
            radius: 14, hardness: 0.2, opacity: 1, color: '#00ff00', erase: false,
          });
          assert('soft brush center is opaque', pixel(brushed, 30, 30)[1] > 200);
          assert('soft brush falloff fades at edge', pixel(brushed, 41, 30)[3] < 200);
          assert('brush does not paint outside radius', pixel(brushed, 60, 30)[3] === 0);
          engine.drawBrushDab(brushCtx, { x: 30, y: 30 }, {
            radius: 6, hardness: 1, opacity: 1, color: '#000000', erase: true,
          });
          assert('eraser removes existing alpha', pixel(brushed, 30, 30)[3] === 0);
          const doc = engine.createDocument('Smoke', 80, 80, '#ffffff');
          doc.layers = [vectorLayer(rect)];
          const exported = engine.exportCanvas(doc);
          assert('export uses white document background', pixel(exported, 70, 70)[0] === 255);
          assert('export includes vector layers', pixel(exported, 20, 20)[1] === 0);
          return results;
        }''')
        # Load the *actual* Spectrum stylesheets into Chromium and compare computed
        # visual properties, rather than trusting that theme names merely exist.
        project = Path(__file__).resolve().parents[1]
        styles = '\n'.join((project / 'src' / 'styles' / name).read_text()
                           for name in ('app.css', 'glass.css', 'material.css', 'classic.css'))
        page.set_content(f'<style>{styles}</style><div class="app theme-glass">'
                         '<div class="toolrail"></div><div class="canvas-host"></div></div>')
        appearances = {}
        for name in ('glass', 'material', 'classic'):
            page.locator('.app').evaluate('(element, name) => {element.className = `app theme-${name}`}', name)
            appearances[name] = page.evaluate('''() => {
                const rail = getComputedStyle(document.querySelector('.toolrail'));
                const canvas = getComputedStyle(document.querySelector('.canvas-host'));
                return {
                    railRadius: rail.borderTopRightRadius,
                    railBlur: rail.backdropFilter,
                    canvasBackground: canvas.backgroundImage,
                    background: getComputedStyle(document.querySelector('.app')).backgroundColor,
                };
            }''')
        theme_checks = [
            ('glass panes have real backdrop blur', appearances['glass']['railBlur'] != 'none'),
            ('material has expressive curved rail', appearances['material']['railRadius'] == '19px'),
            ('classic does not inherit material rounding', appearances['classic']['railRadius'] != '19px'),
            ('theme canvas backgrounds differ', len({v['canvasBackground'] for v in appearances.values()}) == 3),
        ]
        for name, success in theme_checks:
            if not success:
                raise AssertionError(f'Computed theme regression: {name}: {appearances}')
            checks.append(name)
        for index, name in enumerate(checks, start=1):
            print(f'PASS {index:02d}: {name}')
        print(f'Chromium canvas/theme integration assertions: {len(checks)} passed')
    finally:
        browser.close()
