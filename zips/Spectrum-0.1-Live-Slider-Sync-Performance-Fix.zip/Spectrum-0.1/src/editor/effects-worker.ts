import { processEffects } from './fx';
import { createSurface } from './canvas-surface';
import type { Effect } from './types';

interface WorkerRequest {
  id: number;
  sourceId: number;
  bitmap?: ImageBitmap;
  effects: Effect[];
}

/** Cache original pixels independently of effect output. The source canvas is
 * never mutated by the filter graph. A slider request without a bitmap can
 * reuse the decoded source, avoiding repeated main-thread bitmap transfers.
 */
const sources = new Map<number, HTMLCanvasElement>();
const MAX_SOURCES = 3;
const MAX_SOURCE_BYTES = 96 * 1024 * 1024;
const scope = self as unknown as {
  onmessage: ((event: MessageEvent<WorkerRequest>) => void) | null;
  postMessage: (message: unknown, transfer?: Transferable[]) => void;
};

scope.onmessage = event => {
  const { id, sourceId, bitmap, effects } = event.data;
  try {
    let source = sources.get(sourceId);
    const evicted: number[] = [];
    if (bitmap) {
      const canvas = createSurface();
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('Worker Canvas2D context could not be created.');
      context.drawImage(bitmap, 0, 0);
      bitmap.close();
      source = canvas;
      sources.delete(sourceId);
      sources.set(sourceId, canvas);
      let bytes = 0;
      for (const entry of sources.values()) bytes += entry.width * entry.height * 4;
      while (sources.size > MAX_SOURCES || bytes > MAX_SOURCE_BYTES) {
        if (sources.size === 1) break;
        const oldest = sources.keys().next().value as number;
        const removed = sources.get(oldest)!;
        sources.delete(oldest);
        evicted.push(oldest);
        bytes -= removed.width * removed.height * 4;
      }
    } else if (source) {
      // LRU: active layer source stays hot while its slider is being dragged.
      sources.delete(sourceId);
      sources.set(sourceId, source);
    } else {
      throw new Error(`Uncached effect source ${sourceId}`);
    }
    const output = processEffects(source, effects);
    // Neutral/no-op processors may return the original source canvas. Never
    // transfer its drawing buffer: later slider changes must reuse its pixels.
    let resultSurface = output;
    if (output === source) {
      resultSurface = createSurface();
      resultSurface.width = source.width;
      resultSurface.height = source.height;
      resultSurface.getContext('2d')?.drawImage(source, 0, 0);
    }
    const result = (resultSurface as unknown as OffscreenCanvas).transferToImageBitmap();
    scope.postMessage({ id, result, evicted }, [result]);
  } catch (error) {
    bitmap?.close();
    scope.postMessage({ id, error: error instanceof Error ? error.message : String(error) });
  }
};
