import { createSurface } from './canvas-surface';
import type { Effect } from './types';

/** Curated non-destructive additions: each key owns one specific math/geometry
 * path. They share low-level sampling utilities, not other named filter recipes. */
const sections = [
  ['Color Science', ['Chromatic Adaptation','Shadow Chromaticity','Highlight Chromaticity','Three-Way Grade','Cross Process','Bleach Bypass','Teal & Amber','Channel Compression','Luma-Chroma Separation','Filmic Shoulder','Filmic Toe','Logarithmic Grade','Selective Chromaticity','Gamut Soft Clip','Palette Quantizer','Split Tone Spectrum']],
  ['Lighting & Atmosphere', ['Directional Light Shafts','Specular Glints','Light Scattering','Silhouette Rimlight','Sunburst Rays','Atmospheric Fog','Cinematic Haze','Underwater Caustics','Lightning Flash','Ambient Wrap Lighting','Sparkling Highlights','Sunrise Illumination','Moonlight Casting','Shadowed Mist']],
  ['Artistic Painting', ['Charcoal Drawing','Sidewalk Chalk','Soft Pastel','Opaque Gouache','Woodcut Engraving','Copper Etching','Charcoal Hatching','Ink Stippling','Colored Pencils','Oil Impasto','Watercolor Bleeding','Lithographic Press','Felt-Tip Drawing','Wax Crayon','Airbrush Spray','Stained Glass','Graphite Shading','Dry Brush Painting']],
  ['Distortion & Geometry', ['Polar Warp','Pinch Lens','Barrel Distortion','Pincushion Distortion','Oblique Shear','Noise Displacement','Sine Fold','Quadrant Kaleidoscope','Warped Waves','Spiral Vortex','Crystal Shatter','Mirror Slices','Pixel Sorting','Curved Glass']],
  ['Anime & Comics', ['Manga Screentones','Diagonal Screentone','Crosshatch Ink','Impact Speedlines','Black Ink Shadows','Cel Highlight Bands','Color Registration','Energy Eyes','Manga Shadow Bands','Sharp Contour Ink','Two-Tone Comic Ink','Panel Perspective','Anime Energy Lines','Flat Anime Colors','Scratch Ink','Retro Comic Misprint']],
  ['Materials & Surfaces', ['Brushed Aluminum','Gold Foil','Reflective Chrome','Ceramic Glaze','Frosted Acrylic','Woven Linen','Aged Parchment','Sandstone Grain','Leather Texture','Carbon Fiber','Iridescent Film','Concrete Pores','Gemstone Facets','Polished Wood']],
  ['Digital & Experimental', ['Databent Stripes','Bitplane Crush','Chromatic Ghost','Damaged Data Blocks','Tracking Roll','Codec Mosaic','Pixel Rearrangement','Broken LCD','Signal Static','Green Phosphor','RGB Subpixel Mask','Color Data Tears','Corrupted Sectors','Dot Matrix Display']],
  ['Cinematic & Optical', ['Film Halation','Anamorphic Streak','Lens Ghost','Edge Focus Vignette','Prismatic Lens','Star Filter','Cinematic Contrast Curve','Film Negative','Silver Retention','Lens Curvature','Rolling Shutter','Split Diopter','Optical Color Fringe','Golden Lens Flare']],
] as const;
export type ExpandedEffect = { kind:`atelier_${number}_${number}`;label:string;group:string;initial:number;min:number;max:number;unit:'%';step:1;section:number;variant:number };
export const EXPANSION_120: readonly ExpandedEffect[] = sections.flatMap(([group,names],section) =>
  names.map((label,variant)=>({kind:`atelier_${section}_${variant}` as `atelier_${number}_${number}`,label,group,initial:70,min:0,max:100,unit:'%' as const,step:1 as const,section,variant}))) ;
export const EXPANSION_LOOKUP: ReadonlyMap<string,ExpandedEffect> = new Map(EXPANSION_120.map(item=>[item.kind,item]));
if(EXPANSION_120.length!==120||new Set(EXPANSION_120.map(i=>i.kind)).size!==120) throw Error('Expected 120 independent operations');

const clip=(v:number)=>Math.max(0,Math.min(255,Number.isFinite(v)?v:0));
const sat=(v:number)=>Math.min(1,Math.max(0,v));
const blend=(a:number,b:number,t:number)=>a+(b-a)*sat(t);
const hash=(x:number,y:number,s:number)=>{let v=Math.imul(x+97,374761393)^Math.imul(y+71,668265263)^Math.imul(s+1,1274126177);v=Math.imul(v^(v>>>13),1274126177);return ((v^(v>>>16))>>>0)/4294967295;};
const lum=(r:number,g:number,b:number)=>.2126*r+.7152*g+.0722*b;
const smooth=(a:number,b:number,x:number)=>{const t=sat((x-a)/(b-a||1));return t*t*(3-2*t);};
const wave=(a:number)=>Math.sin(a*Math.PI*2);
export function renderExpansion120(source:HTMLCanvasElement,effect:Effect):HTMLCanvasElement {
  const descriptor=EXPANSION_LOOKUP.get(effect.kind);
  if(!descriptor)return source;
  const {width:w,height:h}=source;
  const src=source.getContext('2d',{willReadFrequently:true});if(!src)throw Error('Canvas unavailable');
  const original=src.getImageData(0,0,w,h);
  const input=original.data;
  const output=createSurface();output.width=w;output.height=h;
  const canvas=output.getContext('2d',{willReadFrequently:true});if(!canvas)throw Error('Canvas unavailable');
  const result=canvas.createImageData(w,h),data=result.data;
  const strength=sat(effect.amount/100),params=effect.parameters;
  const cx=w*(params?.centerX??50)/100,cy=h*(params?.centerY??50)/100;
  const scale=Math.max(1,Math.min(w,h));
  const wavelength=Math.max(.1,(params?.frequency??50)/50);
  const orientation=(params?.angle??0)*Math.PI/180;
  const cos=Math.cos(orientation),sin=Math.sin(orientation);
  const chroma=(params?.colorMix??50)/50;
  const {section,variant:v}=descriptor;
  const sample=(x:number,y:number,ch:number)=>input[(Math.min(h-1,Math.max(0,Math.round(y)))*w+Math.min(w-1,Math.max(0,Math.round(x))))*4+ch];
  const Y=(x:number,y:number)=>lum(sample(x,y,0),sample(x,y,1),sample(x,y,2));
  const gradient=(x:number,y:number)=>Math.abs(Y(x+1,y)-Y(x-1,y))+Math.abs(Y(x,y+1)-Y(x,y-1));
  const seed=v*43+section*103+Math.round(params?.seed??0);
  const usesNoise=section===2||section===3||section===5||section===6;
  const usesGeometry=section===1||section===3||section===4||section===5||section===7;
  const usesEdge=section===1||section===2||section===4||section===5;
  for(let y=0;y<h;y)for(let x=0;x<w;x++){
    const i=(y*w+x)*4,r=input[i],g=input[i+1],b=input[i+2],alpha=input[i+3];
    // Retain transparent pixels exactly. Every operation is masked by the
    // original layer alpha; only geometric filters can move a silhouette.
    if(!alpha){data[i]=r;data[i+1]=g;data[i+2]=b;data[i+3]=0;continue;}
    // Center / direction / spatial frequency controls influence the actual
    // underlying procedural geometry rather than only a visual overlay.
    const xx=x-cx,yy=y-cy;
    const tx=cx+(xx*cos-yy*sin)*wavelength,ty=cy+(xx*sin+yy*cos)*wavelength;
    const L=lum(r,g,b),n=usesNoise?hash(Math.floor(tx),Math.floor(ty),seed):0,edge=usesEdge?gradient(x,y)/255:0;
    const X=usesGeometry?(tx-cx)/scale:0,Z=usesGeometry?(ty-cy)/scale:0;
    const R=usesGeometry?Math.hypot(X,Z):0,theta=usesGeometry?Math.atan2(Z,X):0;
    let rr=r,gg=g,bb=b,aa=alpha;
    if(section===0){ // Color Science — 16 color-transfer operations.
      switch(v){
        case 0: rr=r*1.07;gg=g*.995;bb=b*.91;break; // Bradford-inspired warm/chromatic balance
        case 1: {const t=(1-L/255)**2;rr=r+47*t;gg=g+10*t;bb=b+61*t;break;}
        case 2: {const t=(L/255)**2;rr=r+35*t;gg=g+16*t;bb=b-37*t;break;}
        case 3: {const t=L/255;rr=r+28*(1-t)-8*t;gg=g+17*t-9*(1-t);bb=b+24*t-34*(1-t);break;}
        case 4: rr=255*Math.pow(r/255,.81);gg=255*Math.pow(g/255,1.08);bb=255*Math.pow(b/255,1.22);break;
        case 5: rr=blend(L,r,0.38)*1.09;gg=blend(L,g,.38)*1.09;bb=blend(L,b,.38)*1.09;break;
        case 6: {const t=L/255;rr=r+38*t;gg=g+15*(1-t);bb=b+35*(1-t)-22*t;break;}
        case 7: rr=L+(r-L)*.6;gg=L+(g-L)*1.16;bb=L+(b-L)*1.35;break;
        case 8: {const sat0=(Math.max(r,g,b)-Math.min(r,g,b))/255;rr=L+(r-L)*(1.6-.6*sat0);gg=L+(g-L)*(1.1-.3*sat0);bb=L+(b-L)*.75;break;}
        case 9: {const f=L/255;const shoulder=(f/(f+.24))*.82;rr=r*shoulder/(f+.001);gg=g*shoulder/(f+.001);bb=b*shoulder/(f+.001);break;}
        case 10:{const t=(L/255)**.6;const gain=t/(L/255+.001);rr=r*gain;gg=g*gain;bb=b*gain;break;}
        case 11:rr=Math.log1p(r/31)*72;gg=Math.log1p(g/31)*72;bb=Math.log1p(b/31)*72;break;
        case 12:{const chroma=(r-g)/255;const m=smooth(.05,.25,Math.abs(chroma));rr=blend(L,r,m);gg=blend(L,g,m);bb=blend(L,b,m);break;}
        case 13:{const compress=(c:number)=>128+127*Math.tanh((c-128)/112);rr=compress(r);gg=compress(g);bb=compress(b);break;}
        case 14:{const colors=[30,85,160,226];rr=colors[Math.min(3,Math.floor(r/64))];gg=colors[Math.min(3,Math.floor(g/64))];bb=colors[Math.min(3,Math.floor(b/64))];break;}
        case 15:{const t=L/255;rr=r+Math.sin(t*Math.PI)*35;gg=g-14*(1-t);bb=b+40*(1-t)-25*t;break;}
      }
    } else if(section===1){ // Lighting & Atmosphere — sourced from physical direction or highlight masks.
      let mask=0,color:[number,number,number]=[250,215,156];
      switch(v){
        case 0:mask=Math.pow(Math.abs(wave(theta*7+R*.8)),14)*(1-R);break;
        case 1:mask=Math.pow(sat(edge),1.6)*Math.pow(Math.max(0,wave((X+Z)*7)),12);break;
        case 2:mask=Math.pow(L/255,3)*.85;break;
        case 3:mask=sat(edge*.8)*Math.pow(sat(1-L/255),.7);color=[73,196,255];break;
        case 4:mask=Math.pow(Math.abs(wave(theta*11)),19)*Math.exp(-R*2);break;
        case 5:mask=smooth(0,1,y/h)*.65;color=[180,201,215];break;
        case 6:mask=(1-smooth(.16,.93,L/255))*.28+Math.exp(-R*2)*.20;color=[222,191,182];break;
        case 7:mask=Math.pow(Math.max(0,wave(X*18+wave(Z*4)*.3)*wave(Z*14-X*7)),2)*.65;color=[75,203,238];break;
        case 8:mask=Math.pow(Math.max(0,wave(X*7-Z*9)),18)*Math.pow(sat(1-R),2);color=[196,231,255];break;
        case 9:mask=Math.pow(sat((x+y)/(w+h)),2)*.55;color=[243,167,124];break;
        case 10:mask=Math.pow(sat((L-160)/95),2)*(n>.92?1:.08);color=[255,247,190];break;
        case 11:mask=(1-y/h)*.7;color=[255,163,86];break;
        case 12:mask=(1-y/h)*.35+.2*(1-L/255);color=[97,136,255];break;
        case 13:mask=Math.pow(sat(1-L/255),2)*(.3+.2*wave(Z*5+X));color=[85,91,129];break;
      }
      const t=sat(strength*mask);
      rr=blend(r,color[0],t);gg=blend(g,color[1],t);bb=blend(b,color[2],t);
    } else if(section===2){ // 18 named physical media mark models, each with its own marks.
      let ink=0;let paper:[number,number,number]=[240,229,205];
      switch(v){
        case 0:ink=(1-L/255)*(.68+.32*n);paper=[225,218,208];break;
        case 1:ink=(1-L/255)*(n>.12?1:0);paper=[72,86,116];break;
        case 2:ink=(1-L/255)*(.45+.55*Math.sin((tx+ty)*.31)**2);paper=[248,213,204];break;
        case 3:ink=Math.floor((1-L/255)*5)/5;paper=[235,198,156];break;
        case 4:ink=(L<140?1:0)*(Math.sin(ty*.83+tx*.12)>.08?1:.25);paper=[239,211,161];break;
        case 5:ink=(1-L/255)*((tx*3+ty)%7<3?1:.22);paper=[240,219,174];break;
        case 6:ink=(1-L/255)*(Math.sin((tx+ty)*1.0)>.65?1:.16);break;
        case 7:ink=(1-L/255)*(hash(Math.floor(tx/3),Math.floor(ty/3),seed)>.65?1:0);break;
        case 8:ink=(1-L/255)*(.25+.75*Math.abs(wave((tx+ty)*.16)));paper=[245,232,211];break;
        case 9:ink=(1-L/255)*(.78+.22*wave(tx*.4+ty*.06));paper=[235,184,120];break;
        case 10:ink=(1-L/255)*(.3+.7*hash(Math.floor(tx/5),Math.floor(ty/5),seed));paper=[230,226,211];break;
        case 11:ink=(1-L/255)*(Math.sin(tx*.48)*Math.sin(ty*.48)>.3?1:.08);break;
        case 12:ink=(1-L/255)*(Math.abs(Math.sin((tx-ty)*.37))>.5?1:.05);break;
        case 13:ink=(1-L/255)*(Math.sin(tx*.27+ty*.27)*n>.09?1:.15);paper=[232,199,148];break;
        case 14:ink=(1-L/255)*(.6+.4*hash(Math.floor(tx/8),Math.floor(ty/8),seed));paper=[217,220,226];break;
        case 15:ink=(1-L/255)*(gradient(tx,ty)>50?1:.3);paper=[148,215,225];break;
        case 16:ink=(1-L/255)*(.35+.65*n)*(Math.cos((tx+ty)*.1)**2);break;
        case 17:ink=(1-L/255)*(Math.sin(ty*.57+Math.sin(tx*.2))>.1?1:.15);paper=[235,208,186];break;
      }
      const medium=255*sat(1-ink);rr=blend(r,blend(medium,paper[0],.26),strength*.94);
      gg=blend(g,blend(medium,paper[1],.26),strength*.94);bb=blend(b,blend(medium,paper[2],.26),strength*.94);
    } else if(section===3){ // Distortion & Geometry: inverse sample coordinates.
      let u=tx,z=ty;const power=strength*scale*.15;
      switch(v){
        case 0:{const a=theta+strength*Math.exp(-R*2)*2;u=cx+Math.cos(a)*R*scale;z=cy+Math.sin(a)*R*scale;break;}
        case 1:{const f=1+strength*Math.exp(-R*4)*.9;u=cx+(tx-cx)/f;z=cy+(ty-cy)/f;break;}
        case 2:{const f=1+strength*R*R*.9;u=cx+(tx-cx)/f;z=cy+(ty-cy)/f;break;}
        case 3:{const f=1-strength*R*R*.7;u=cx+(tx-cx)/f;z=cy+(ty-cy)/f;break;}
        case 4:u=tx+Math.sin(ty/scale*Math.PI)*power;break;
        case 5:u=tx+(n-.5)*power;z=ty+(hash(tx,ty,seed+1)-.5)*power;break;
        case 6:u=tx+power*wave(ty/scale*7);break;
        case 7:{const k=Math.round((theta+Math.PI)/(Math.PI/2));const a=(k%2? -theta:theta);u=cx+Math.cos(a)*R*scale;z=cy+Math.sin(a)*R*scale;break;}
        case 8:z=ty+power*wave(tx/scale*4+Z);break;
        case 9:{const a=theta+strength*R*5;u=cx+Math.cos(a)*R*scale;z=cy+Math.sin(a)*R*scale;break;}
        case 10:u=tx+Math.floor(ty/22)%2*power;z=ty+Math.floor(tx/31)%2*power*.35;break;
        case 11:u=Math.floor(tx/22)%2?cx-(tx-cx):tx;break;
        case 12:u=tx+Math.floor((L/255)*strength*power)*((ty%5)<3?1:-1);break;
        case 13:u=tx+power*(1-Z*Z)*Math.sin(ty/scale*5);break;
      }
      rr=sample(u,z,0);gg=sample(u,z,1);bb=sample(u,z,2);aa=sample(u,z,3);
    } else if(section===4){ // Anime & Comics: edge/ink/screentone/graphic separation.
      let mark=0;
      switch(v){
        case 0:mark=(n>.5+L/510?1:0);break;
        case 1:mark=(wave((tx+ty)*.22)>L/255*2-1?1:0);break;
        case 2:mark=(wave((tx+ty)*.35)*wave((tx-ty)*.35)>(L/255)*.8?1:0);break;
        case 3:mark=Math.pow(Math.abs(wave(theta*15)),15)*Math.exp(-R*.8);break;
        case 4:mark=(L<110?1:0);break;
        case 5:mark= (L>165?1:0)*.65;break;
        case 6:mark=((tx%17)<2||(ty%17)<2)? .8:0;break;
        case 7:mark=(L>170&&edge>0.1)?1:0;break;
        case 8:mark=L<70?1:L<138?.55:.06;break;
        case 9:mark=sat(edge/2)*1.6;break;
        case 10:mark= Math.floor(L/128)*.85;break;
        case 11:mark=(tx/w>ty/h)? .45:0;break;
        case 12:mark=Math.abs(wave(theta*32))>.95&&R>.13?1:0;break;
        case 13:mark=(Math.floor(L/63)%2)*.68;break;
        case 14:mark=(n>.88&&L<170)?1:0;break;
        case 15:mark=(Math.sin(tx*.39)>0&&Math.cos(ty*.29)>0)? .6:0;break;
      }
      let target:[number,number,number]=[18,19,47];if(v===5||v===7||v===12)target=[247,191,91];
      rr=blend(r,target[0],sat(strength*mark));gg=blend(g,target[1],sat(strength*mark));bb=blend(b,target[2],sat(strength*mark));
    } else if(section===5){ // Material & Surfaces: specular / roughness fields.
      let texture=0;let tint:[number,number,number]=[180,185,192];
      switch(v){
        case 0:texture=wave(ty*.15)*.36+n*.17;break;
        case 1:texture=hash(Math.floor(tx/6),Math.floor(ty/9),seed)*.8;tint=[237,187,67];break;
        case 2:texture=smooth(.1,.9,L/255)*.8;tint=[169,216,243];break;
        case 3:texture=Math.pow(sat(edge*.4),.7)+.15;tint=[226,224,210];break;
        case 4:texture=.25+.32*n;tint=[181,209,215];break;
        case 5:texture=(Math.cos(tx*.42)*Math.sin(ty*.42)+1)/3;tint=[211,198,171];break;
        case 6:texture=(n*.5+Math.sin(tx*.01+ty*.05)*.2);tint=[224,193,133];break;
        case 7:texture=hash(Math.floor(tx/3),Math.floor(ty/3),seed);tint=[184,160,133];break;
        case 8:texture=(Math.cos(tx*.28+ty*.21)+1)*.22;tint=[159,103,68];break;
        case 9:texture=(Math.sin(tx*.47)*Math.cos(ty*.47)+1)*.45;tint=[67,96,111];break;
        case 10:texture=(Math.sin(tx*.08+ty*.14+L*.01)+1)*.46;tint=[113,181,239];break;
        case 11:texture=n*.64;tint=[166,174,182];break;
        case 12:texture=Math.abs(Math.sin(Math.atan2(Z,X)*8))*Math.exp(-R);tint=[112,209,237];break;
        case 13:texture=Math.sin(ty*.17+Math.sin(tx*.06))* .5+.4;tint=[176,102,59];break;
      }
      const t=strength*.52;rr=blend(r,tint[0]*.4+r*.60+texture*36,t);
      gg=blend(g,tint[1]*.4+g*.60+texture*36,t);bb=blend(b,tint[2]*.4+b*.60+texture*36,t);
    } else if(section===6){ // Digital Experimental: quantization, transmission errors, display structures.
      let u=tx,z=ty;let factor=1;
      switch(v){
        case 0:u=tx+Math.floor(ty/8)%5*strength*8;break;
        case 1:factor=1+Math.round(strength*8);break;
        case 2:u=tx+strength*8;break;
        case 3:u=tx+Math.floor(ty/16)%4*strength*22;break;
        case 4:z=ty+strength*18*Math.sin(ty*.1);break;
        case 5:u=Math.floor(tx/(2+strength*12))*(2+strength*12);z=Math.floor(ty/(2+strength*12))*(2+strength*12);break;
        case 6:u=(tx+Math.floor(ty/9)*Math.round(strength*8))%w;break;
        case 7:u=tx+((tx%20)<3?strength*6:0);break;
        case 8:factor=2;break;
        case 9:factor=3;break;
        case 10:factor=4;break;
        case 11:u=tx+strength*Math.sin(ty*.5)*11;break;
        case 12:u=tx+(hash(Math.floor(tx/24),Math.floor(ty/24),seed)>.79?strength*23:0);break;
        case 13:factor=5;break;
      }
      rr=sample(u,z,0);gg=sample(u,z,1);bb=sample(u,z,2);
      if(v===1){const steps=4+Math.round((1-strength)*5);rr=Math.round(rr/255*steps)/steps*255;gg=Math.round(gg/255*steps)/steps*255;bb=Math.round(bb/255*steps)/steps*255;}
      if(v===2||v===11){rr=sample(u-strength*3,z,0);bb=sample(u+strength*3,z,2);}
      if(v===7&&tx%20<2){rr=gg=bb=18;}
      if(v===8){const d=(n-.5)*strength*130;rr+=d;gg+=d;bb+=d;}
      if(v===9){rr=blend(rr,21,strength*.9);gg=blend(gg,L*1.45,strength*.9);bb=blend(bb,33,strength*.9);}
      if(v===10){const lane=tx%3;rr*=lane===0?1:.7;gg*=lane===1?1:.7;bb*=lane===2?1:.7;}
      if(v===13){const dark=(tx%9<2||ty%9<2);if(dark){rr*=.3;gg*=.3;bb*=.3;}}
      if(factor!==1&&v!==1&&v!==9&&v!==10&&v!==13){rr/=factor*.3+.7;gg/=factor*.3+.7;bb/=factor*.3+.7;}
    } else if(section===7){ // Cinematic/Optical: highlight-based optical transport and film transfer.
      const highlight=Math.pow(L/255,3);let light=0;
      switch(v){
        case 0:light=highlight*.65;rr+=light*120;gg+=light*33;break;
        case 1:light=highlight*Math.exp(-Math.abs(ty-cy)/scale*3);rr+=light*140;gg+=light*100;bb+=light*84;break;
        case 2:light=Math.pow(sat(1-R),5)*highlight;rr+=light*78;gg+=light*110;bb+=light*150;break;
        case 3:light=smooth(.2,.8,R);rr*=1-light*.45;gg*=1-light*.45;bb*=1-light*.45;break;
        case 4:light=Math.abs(wave(theta*5))*highlight;rr+=light*55;bb+=light*80;break;
        case 5:light=Math.pow(Math.abs(wave(theta*4)),17)*highlight;rr+=light*130;gg+=light*90;bb+=light*110;break;
        case 6:{const f=1.16;rr=(r-128)*f+128;gg=(g-128)*f+128;bb=(b-128)*f+128;break;}
        case 7:rr=255-r*.9;gg=255-g*.95;bb=244-b;break;
        case 8:{const gray=L;rr=blend(gray,r,.25)*1.07;gg=blend(gray,g,.25)*1.07;bb=blend(gray,b,.25)*1.07;break;}
        case 9:{const f=1-R*R*.2;rr=sample(cx+(tx-cx)*f,cy+(ty-cy)*f,0);gg=sample(cx+(tx-cx)*f,cy+(ty-cy)*f,1);bb=sample(cx+(tx-cx)*f,cy+(ty-cy)*f,2);break;}
        case 10:rr=sample(tx+Math.sin(ty*.21)*strength*4,ty,0);gg=sample(tx,ty,1);bb=sample(tx-Math.sin(ty*.21)*strength*4,ty,2);break;
        case 11:{const split=tx/w>.52?strength*7:-strength*7;rr=sample(tx+split,ty,0);gg=sample(tx+split,ty,1);bb=sample(tx+split,ty,2);break;}
        case 12:rr=sample(tx+strength*5*Math.exp(-R),ty,0);bb=sample(tx-strength*5*Math.exp(-R),ty,2);break;
        case 13:light=highlight*Math.max(0,1-R*1.4)*(.5+.5*Math.cos(theta));rr+=light*170;gg+=light*110;bb+=light*15;break;
      }
    }
    // Family-specific chroma/tone controls influence the rendered result.
    // Neutral defaults (50/0/50) preserve the identity of each original look.
    if(section===0){
      const curve=(wavelength-1)*.24,temperature=orientation*.13;
      rr=255*Math.pow(sat(rr/255),1+curve)+temperature*70;
      gg=255*Math.pow(sat(gg/255),1+curve);
      bb=255*Math.pow(sat(bb/255),1+curve)-temperature*70;
    }
    if(chroma!==1){
      const brightness=lum(rr,gg,bb);
      const richness=Math.max(.1,Math.min(2,chroma));
      rr=brightness+(rr-brightness)*richness;
      gg=brightness+(gg-brightness)*richness;
      bb=brightness+(bb-brightness)*richness;
    }
    data[i]=clip(blend(r,rr,strength));data[i+1]=clip(blend(g,gg,strength));data[i+2]=clip(blend(b,bb,strength));
    // Distortions propagate sampled alpha, tonal and style filters leave it intact.
    data[i+3]=section===3?clip(blend(alpha,aa,strength)):alpha;
  }
  canvas.putImageData(result,0,0);
  return output;
}
