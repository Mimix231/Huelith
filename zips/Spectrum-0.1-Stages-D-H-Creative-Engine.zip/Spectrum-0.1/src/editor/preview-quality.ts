/** Adaptive quality is scoped to the actively edited layer.
 * Other layers retain their cached full-quality images during a slider drag.
 */
let interactive = false;
let interactiveLayerId: string | null = null;

export function setInteractiveEffectPreview(active: boolean, layerId: string | null = null): void {
  interactive = active;
  interactiveLayerId = active ? layerId : null;
}

export function effectPreviewScale(width: number, height: number, layerId?: string): number {
  const shouldReduce = interactive && (interactiveLayerId === null || interactiveLayerId === layerId);
  const maxPixels = shouldReduce ? 160_000 : 16_000_000;
  return Math.min(1, Math.sqrt(maxPixels / Math.max(1, width * height)));
}
