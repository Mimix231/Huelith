import { uid, type Effect, type EffectKind, type Layer } from './types';
import { FILTER_CATALOG, FILTER_CONTROL_MAP } from './effect-catalog';
import { applyEffect } from './effect-ops';
import { EFFECT_PARAMETER_SCHEMA, defaultParameters } from './effect-schema';
import { effectPreviewScale } from './preview-quality';

export const EFFECT_CONTROLS = FILTER_CONTROL_MAP;
export const FILTERS: { kind: EffectKind; label: string; initial: number; group: string }[] = FILTER_CATALOG.map(
  ({ kind, label, initial, group }) => ({ kind, label, initial, group }),
);

/** Additional controls are interpreted by the effect processor, never just decoration. */
export const EFFECT_PARAMETERS = EFFECT_PARAMETER_SCHEMA;

export function clampEffectAmount(kind: EffectKind, amount: number): number {
  const descriptor = EFFECT_CONTROLS[kind];
  return Math.max(descriptor.min, Math.min(descriptor.max, Number.isFinite(amount) ? amount : descriptor.min));
}

/** The 15 signature FX are *standalone processors*. Historical .spectrum files
 * containing multiple legacy steps still render unchanged; newly applied FX
 * create only one dedicated sig_N effect, without composing named filters. */
export const SIGNATURE_FX_NAMES = [
  'Hyper Outline',
  'Neon Pulse',
  'Shadow Forge',
  'Dream Bloom',
  'Glitch Matrix',
  'Comic Pop',
  'Frostbite',
  'Ember Glow',
  'Prism Split',
  'Golden Hour',
  'Aurora Flow',
  'Electric Edge',
  'Holographic',
  'Retro Vision',
  'Spectrum Burst',
] as const;

export const SIGNATURE_FX_COLORS = ["#ffffff", "#2feaff", "#17112c", "#ffd6f4", "#52a8ff", "#ffcb45", "#b0ebff", "#ff7837", "#ff59d8", "#ffbb65", "#68ffcb", "#39eaff", "#bb84ff", "#d57bfa", "#a79cff"] as const;

export const FX_PRESETS: Record<string, { kind: EffectKind; amount: number; color?: string; parameters?: Effect['parameters'] }[]> = Object.fromEntries(
  SIGNATURE_FX_NAMES.map((name, index) => [name, [{ kind: `sig_${index}` as EffectKind, amount: 70, color: SIGNATURE_FX_COLORS[index], parameters: defaultParameters(`sig_${index}` as EffectKind) }]]),
);


export function newEffect(kind: EffectKind, amount?: number, color?: string, parameters?: Effect['parameters']): Effect {
  const definition = FILTERS.find(item => item.kind === kind);
  return {
    id: uid(), kind, enabled: true,
    amount: clampEffectAmount(kind, amount ?? definition?.initial ?? 100),
    color,
    parameters: { ...defaultParameters(kind), ...structuredClone(parameters ?? {}) },
  };
}

/** CSS filter representation kept for SVG compatibility and quick previews. */
export function effectFilter(effect: Effect): string {
  const amount = clampEffectAmount(effect.kind, effect.amount);
  if (effect.kind === 'hue') return `hue-rotate(${amount}deg)`;
  if (effect.kind === 'blur') return `blur(${amount}px)`;
  if (['brightness', 'contrast', 'saturate', 'grayscale', 'sepia', 'invert'].includes(effect.kind)) {
    const name = effect.kind === 'saturate' ? 'saturate' : effect.kind;
    return `${name}(${amount}%)`;
  }
  return 'none';
}

/** Non-destructive effect graph shared by editor, frame export, and image export. */
export function processEffects(source: HTMLCanvasElement, effects: readonly Effect[]): HTMLCanvasElement {
  let current = source;
  for (const effect of effects) {
    if (!effect.enabled) continue;
    const controls = EFFECT_CONTROLS[effect.kind];
    // A zero setting is a meaningful state for several effects; never use a universal "amount > 0" guard.
    if (effect.kind === 'outline' && effect.amount === 0) continue;
    if (effect.kind === 'cutout' && effect.amount === 0) continue;
    if (controls && !Number.isFinite(effect.amount)) continue;
    current = applyEffect(current, effect);
  }
  return current;
}

const effectCache = new WeakMap<Layer, { width: number; height: number; scale: number; image: HTMLCanvasElement }>();

export function renderWithEffects(
  ctx: CanvasRenderingContext2D,
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
): void {
  const effects = layer.effects ?? [];
  if (!effects.some(effect => effect.enabled)) {
    paint(ctx, layer);
    return;
  }
  const scale = effectPreviewScale(width, height, layer.id);
  const cached = layer.type === 'vector' ? effectCache.get(layer) : undefined;
  if (cached && cached.width === width && cached.height === height && cached.scale === scale) {
    ctx.drawImage(cached.image, 0, 0, width, height);
    return;
  }
  const source = document.createElement('canvas');
  source.width = Math.max(1, Math.floor(width * scale));
  source.height = Math.max(1, Math.floor(height * scale));
  const temporary = source.getContext('2d');
  if (!temporary) return;
  temporary.scale(scale, scale);
  paint(temporary, layer);
  const processed = processEffects(source, effects);
  if (layer.type === 'vector') effectCache.set(layer, { width, height, scale, image: processed });
  ctx.drawImage(processed, 0, 0, width, height);
}
