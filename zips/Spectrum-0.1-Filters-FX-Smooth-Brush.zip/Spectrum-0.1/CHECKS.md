# Spectrum 0.1 — Filter & brush stabilization verification (2026-10-20)

**These results supersede earlier check tables below.** Version remains `0.1.0`.

| Check | Observed result | Limitations |
|---|---|---|
| Node tests | **89/89 passed** | Editor model, serialization, history, source and effect catalog assertions; uses global TypeScript compiler here because npm registry is unavailable |
| Chromium canvas + theme pixel assertions | **183/183 passed** | Real Canvas2D pixel checks, **70 filter algorithms**, **15 signature FX presets**, background cutout, real outline thickness, adjustable glow/backdrop/main sliders, smooth brush endpoint, stylesheet appearance |
| Chromium timeline / FX animation assertions | **9/9 passed** | Timeline marker and popup styles, reduced motion; not an interactive React desktop launch |
| Strict TypeScript on dependency-free editor modules | **PASS** | `tsc --strict --noEmit` with real compiler and no React/MUI stand-ins |
| CSS + JSON + Cargo TOML parsing | **PASS** | 19 CSS files parsed by `tinycss2`; JSON/TOML decoded |
| Obsolete cleanup dry run | **PASS** | No deletions; 0 discovered files in current package |
| Actual `npm install`, frontend dependency-aware build | **NOT AVAILABLE** | Registry DNS error `EAI_AGAIN` and no local React/MUI packages; cannot guarantee `npm run check`/`npm run build` success |
| Windows/Tauri compilation, React E2E/interactive smoke | **NOT VERIFIED** | Rust/Cargo unavailable and Vite cannot start without npm packages |

**Release gate:** Do not tag 1.0 until `npm install`, `npm run verify`, `npm run test:browser`, `npm run test:timeline`, `npm run test:ui`, and `npm run desktop:build` succeed in a real Windows environment; manually test a real imported photo, text, masks, save/reopen, animation and exports. Pixel tests alone cannot establish professional quality or release readiness.

---

# Spectrum 0.1 — Professional Editing Overhaul verification (2026-10-20)

**Version remains `0.1.0`. These current results supersede the older reports retained below for history.**

| Verification | Current result | What it proves |
| --- | --- | --- |
| Node unit/regression/source tests | **84/84 PASS** | Document operations, undo/redo, parametric shapes, input hit-testing and cursors, effect live-preview transaction behavior, menus and animation serialization |
| Chromium rendering/theme assertions | **80/80 PASS** | Real browser Canvas2D pixels for new shapes and multiple effect values, plus computed theme/layout styles |
| Chromium animation-timeline/motion assertions | **9/9 PASS** | Computed styles for timeline playhead, frame cards, entry/exit motions and reduced-motion accessibility |
| Strict actual TypeScript compiler on dependency-free editor core | **PASS** | `tsc --strict --noEmit` checks document, rendering, geometry, effect, animation and interaction modules with no stand-ins |
| Application TypeScript compiler with temporary external dependency stand-ins | **PASS** | Application source, unused-import checks and internal type compatibility; **does not** prove real MUI/React/Tauri typings work |
| CSS | **PASS** | All shipped stylesheets parse in tinycss2 (syntax only, not a full visual audit) |
| Python E2E script syntax | **PASS** | Test source compiles; interactive E2E itself is **not run** |
| Obsolete cleanup dry run | **PASS** | Cleanup previews only known legacy/backup files; deletion requires explicit apply mode |
| Native desktop and full React E2E | **NOT VERIFIED** | Cannot run the packaged application with real npm dependencies here |
| Real `npm run check`, `npm run build`, `npm run desktop:build` | **BLOCKED** | Dependency installation fails due to `EAI_AGAIN registry.npmjs.org`; Rust toolchain missing |

The shipped code includes a Playwright React interface test suite (`tests/ui-e2e.py`), but **passing headless Canvas2D integration tests is not the same as passing a working desktop application**. A completed Windows build and user-interaction tests are mandatory before declaring Spectrum 0.1 stable. SVG preserves geometry but cannot export custom raster-only FX; save effect-heavy work as PNG/WebP. Advanced selection masks, text shaping/OpenType, GPU tiled rendering and delta-based history remain outside this overhaul.

### Windows verification

```powershell
npm install
npm run check
npm test
npm run test:browser
npm run test:timeline
npm run test:ui
npm run build
npm run desktop:dev
npm run desktop:build
```

See `ACCEPTANCE.md` for exact manual scenarios. Source code is delivered, **not** a compiled Windows binary.

---

# Spectrum 0.1 — Compact Creative Studio verification report

**Date:** 2026-10-17 · **Version:** `0.1.0` (intentionally unchanged).

## Results from the source-package environment

| Check | Result | Interpretation |
| --- | --- | --- |
| `npm test` | **49 / 49 pass** | Document validation, edits/history, curve control points, saved FX, brushes, tab reorder, appearance, source parsing |
| `npm run test:browser` | **56 / 56 pass** | Actual Chromium Canvas2D pixel/clipboard checks and computed styles for themes in both appearance modes |
| Stand-in-based source TypeScript check | **Pass** | Temporary library declarations, `noImplicitAny: false`; **not** the real dependency-aware check |
| Python E2E test script syntax | **Pass** | `python -m py_compile tests/ui-e2e.py`; the E2E test itself was **not** run |
| CSS parsing | **Pass** | Parsed all 16 stylesheets with tinycss2; no CSS parser errors |
| JSON/TOML configuration | **Pass** | Package and Tauri configuration are parseable |
| Real `npm run check` and `npm run build` | **Blocked** | Registry DNS failed; dependencies could not be installed, so true MUI/React typings and Vite bundles were not checked |
| React/MUI interactive E2E | **Not run** | Requires working `npm install`, Vite and browser session |
| Windows desktop launch and Tauri build | **Not run** | No Rust cargo toolchain or Windows desktop in this environment |

The temporary TypeScript dependency declarations are **not included in the ZIP**; they exist only in the local build-check workspace to catch source-level errors. Passing them does not establish a fully compiling project.

### Automated coverage added or expanded in this pass

- Document tabs: reorder and document identity, dirty changes and save-revision integrity.
- Themes: **Strawberry, Melon, Peach, Lemon, Mango, Sakura, Blossom and Shadow**, with actual browser checks for their separate light and dark styles; earlier themes remain available.
- Pixel FX: invert, pixelate, posterize and vignette in actual Canvas2D, as well as existing blur/glow/outline/brightness and SVG/clipboard checks.
- Serialized effects: effect enum validation, non-destructive stacks and undo handling.
- Canvas brush: exact endpoint at zero smoothing, stabilized endpoint after stroke completion, and pointer coalescing.
- Transient before/after compare state does not enter document history or serialize to projects.
- New `tests/ui-e2e.py` scenarios for theme picker, tabs, FX launcher and editor behavior are **included for manual or CI execution**, not claimed as passing here.

### Commands to run after extracting on a Windows machine

```powershell
npm install
npm run check
npm test
npm run test:browser
npm run test:ui
npm run build
npm run desktop:dev
npm run desktop:build
```

`npm run test:browser` and `npm run test:ui` require Python Playwright with Chromium; the Tauri commands require the Rust toolchain and Tauri's Windows OS prerequisites. Fix any errors in the real build **before distributing an installer**. Run the interactive acceptance scenarios in `ACCEPTANCE.md` on Windows; source tests alone cannot demonstrate that the complete GUI works.

## Remaining engineering limitations

1. **Not an installed application**: This ZIP contains source code, not a working Windows executable.
2. **The UI has not been visually inspected in a fully bundled React/MUI/Tauri runtime**, because the required dependencies could not be installed here. Pixel and CSS component tests are narrower than full UI E2E tests.
3. **Advanced professional editing remains incomplete:** elliptical/lasso/magic wand selections, alpha and feathered masks, full vector path operations, multi-run rich typography, RAW/PSD, color profiles, GPU tile rendering and tile-delta history are not present.
4. **FX sliders** commit to project history on release, rather than updating the full document live for every intermediate drag frame; the stack is editable and togglable.
5. **SVG** preserves geometry but will not reproduce Spectrum-specific raster FX. Use PNG/WebP for effects-heavy output.
6. Very large artwork may still stress CPU, memory and Canvas2D; performance is not guaranteed by synthetic smoke tests.

Keep the application at **Spectrum 0.1** until the complete build, UI tests, and desktop acceptance checklist actually pass.

---

## Typography + native window implementation — 2026-10-19

This newer section supersedes previous test counts above; version is still **0.1.0**.

| Verification | Result | Scope |
| --- | --- | --- |
| Node regression and source tests | **57 / 57 passed** | Includes 8 new typography, history, SVG/font, native-window configuration tests |
| Chromium pixel/CSS integration | **61 / 61 passed** | Canvas2D raster/vector/themes plus five compact-UI CSS assertions; not a full React UI run |
| CSS parsing | **17 stylesheets passed** | `tinycss2` CSS syntax parsing |
| JSON & Cargo TOML | **Passed** | Valid JSON for Tauri permissions/config, valid Rust manifest TOML |
| `tests/ui-e2e.py` Python syntax | **Passed** | Added caret-focus and font-dropdown test steps, **not executed** |
| TypeScript stand-in source check | **Checked with temporary declarations** | Stand-in typings cannot validate actual MUI/React/Tauri bindings; see limitations below |
| Real `npm install`, `npm run check` or `npm run build` | **Blocked** | Container cannot resolve `registry.npmjs.org`; no locally installed React/MUI dependencies |
| Native Rust Tauri build and Windows controls | **Not verified** | Rust toolchain and Windows desktop environment unavailable |

Changes include `src/editor/fonts.ts`, `src/components/FontPicker.tsx`, `src/components/WindowControls.tsx`, `src/styles/typography.css`, Rust `list_system_fonts` command and updated canvas/store APIs. Windows font enumeration relies on `fontdb` standard font directories, and there is a browser fallback list with explicit limitations. The new Tauri permission entries allow window minimize/close/maximize/drag actions.

**Important:** The passing tests are not a certification of a running Windows installer. Before calling Spectrum 0.1 stable, run the actual dependency-based build, native Tauri checks and full UI E2E on Windows, fix defects, and complete the added acceptance checklist. Real UI tests could not be executed here.

---

## 2026-10-19 — Animation timeline, onion-skin and obsolete cleanup (latest)

**Version:** `0.1.0`, unchanged. These results supersede earlier test counts. The ZIP contains the full source project, not a compiled installer.

| Verification | Result | Exactly what was tested |
| --- | --- | --- |
| `npm test` | **70/70 PASS** | Existing document/raster/vector/clipboard/FX regressions, plus animation frame isolation, insertion, reordering, FPS and timing, serialization, undo and timeline implementation assertions |
| `npm run test:browser` | **61/61 PASS** | Headless Chromium Canvas2D pixel assertions, clipboard, 13 themes and compact geometry |
| `npm run test:timeline` | **9/9 PASS** | Headless Chromium computed layout: 80px frame cells, draggable marker placement, distinct theme treatment, FX open/close animation, reduced motion |
| Source-only TypeScript | **PASS** | Real strict `tsc` with no stand-ins on the dependency-free animation/document modules (`src/editor/types.ts`, `src/editor/animation.ts`) |
| CSS parsing | **18 stylesheets PASS** | `tinycss2` checked for CSS syntax parser errors |
| JSON and TOML parse | **PASS** | All packaged JSON/TOML configuration manifests |
| Python test scripts | **PASS** | Python source compiled without syntax errors; **not** the same as running the UI E2E |
| Animation APNG output | **PASS, sampled** | Encoded real PNG frames; Pillow decoded APNG frame count, timings and pixel contents |
| PNG frame-sequence ZIP | **PASS, sampled** | Python `zipfile.testzip()` and Pillow independently opened each PNG member |
| Obsolete cleanup | **PASS** | Preview made no changes; explicit `--apply` removed a test `.old` backup; checked no residual candidates |
| Real `npm install` | **BLOCKED** | `npm ping --fetch-retries=0 --fetch-timeout=8000` reports `getaddrinfo EAI_AGAIN registry.npmjs.org` |
| Real React/MUI/Vite check and build | **NOT VERIFIED** | No installed dependencies, so neither `npm run check` nor `npm run build` can yet be certified |
| Native Tauri / Windows build | **NOT VERIFIED** | Rust/Cargo and a Windows desktop are unavailable here |
| Complete React interface E2E | **NOT EXECUTED** | The included `tests/ui-e2e.py` needs npm dependencies, Vite and Playwright Chromium |

### How to verify on Windows

```powershell
npm install
npm run check
npm test
npm run test:browser
npm run test:timeline
npm run test:ui
npm run build
npm run desktop:dev
```

For browser/UI checks, install Python Playwright and its Chromium browser (`python -m pip install playwright` and `python -m playwright install chromium`). For native desktop, install the Windows Tauri prerequisites and Rust. Resolve any actual build or UI failures **before** using the project as a stable release.

### Obsolete-file cleanup

`npm run clean:obsolete:dry` previews without deleting anything. `npm run clean:obsolete` removes only allowlisted legacy file names and source backup/reject files (`.bak`, `.old`, `.orig`, `.rej`, `.tmp`, `~`) found beneath `src`, `tests` and `scripts`. This is intentionally conservative: it does not delete arbitrary folders, unrecognized source files or dependencies. The old ZIP contained no functioning obsolete-cleanup script to upgrade, so this is a newly implemented replacement. Preserve a version-control checkpoint before applying cleanup to a modified tree.

### Known limitations and realistic status

The new animation interface supports a **draggable ruler playhead**, frame cards, blank/duplicate/delete/reorder operations, loop playback, optional adjacent-frame onion ghosts and APNG/PNG-sheet/PNG-sequence exporting. Ghost frames are editor-only and excluded from export. Static `.spectrum` projects remain supported. This is an implemented, tested **foundation**, not a fully verified professional animation suite: animation still uses Canvas2D, full-document history snapshots and CPU-based export. A huge animation can be memory-intensive; exports intentionally enforce limits. GIF, WebM, MP4 and animated WebP exporting, onion overlays color-tinting, sophisticated per-frame shared-layer/cel linking and a real desktop acceptance run are not included.
