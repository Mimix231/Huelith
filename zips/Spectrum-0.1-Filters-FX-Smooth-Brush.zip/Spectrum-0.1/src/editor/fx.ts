import { uid, type Effect, type EffectKind, type Layer } from './types';
import { FILTER_CATALOG, FILTER_CONTROL_MAP } from './effect-catalog';
import { applyEffect } from './effect-ops';

export const EFFECT_CONTROLS = FILTER_CONTROL_MAP;
export const FILTERS: { kind: EffectKind; label: string; initial: number; group: string }[] = FILTER_CATALOG.map(
  ({ kind, label, initial, group }) => ({ kind, label, initial, group }),
);

/** Additional controls are interpreted by the effect processor, never just decoration. */
export const EFFECT_PARAMETERS: Partial<Record<EffectKind, {
  key: string; label: string; min: number; max: number; initial: number; unit?: string;
}[]>> = {
  outline: [
    { key: 'softness', label: 'Feather', min: 0, max: 80, initial: 0, unit: 'px' },
    { key: 'opacity', label: 'Opacity', min: 0, max: 100, initial: 100, unit: '%' },
  ],
  glow: [
    { key: 'softness', label: 'Falloff', min: 0, max: 120, initial: 24, unit: 'px' },
    { key: 'spread', label: 'Solid spread', min: 0, max: 80, initial: 0, unit: 'px' },
    { key: 'opacity', label: 'Opacity', min: 0, max: 100, initial: 75, unit: '%' },
  ],
  shadow: [
    { key: 'blur', label: 'Softness', min: 0, max: 100, initial: 20, unit: 'px' },
    { key: 'offsetX', label: 'X offset', min: -250, max: 250, initial: 10, unit: 'px' },
    { key: 'offsetY', label: 'Y offset', min: -250, max: 250, initial: 10, unit: 'px' },
    { key: 'opacity', label: 'Opacity', min: 0, max: 100, initial: 100, unit: '%' },
  ],
  backdrop: [
    { key: 'offsetX', label: 'Backdrop X', min: -1000, max: 1000, initial: 0, unit: 'px' },
    { key: 'offsetY', label: 'Backdrop Y', min: -1000, max: 1000, initial: 0, unit: 'px' },
    { key: 'scale', label: 'Backdrop scale', min: 10, max: 400, initial: 100, unit: '%' },
    { key: 'opacity', label: 'Backdrop opacity', min: 0, max: 100, initial: 65, unit: '%' },
  ],
  chromatic: [
    { key: 'shiftY', label: 'Vertical shift', min: -100, max: 100, initial: 0, unit: 'px' },
    { key: 'density', label: 'Glitch density', min: 0, max: 100, initial: 0, unit: '%' },
    { key: 'seed', label: 'Seed', min: 0, max: 9999, initial: 18 },
    { key: 'scanlines', label: 'Scanlines', min: 0, max: 100, initial: 0, unit: '%' },
  ],
  glitch: [
    { key: 'density', label: 'Fragment density', min: 0, max: 100, initial: 55, unit: '%' },
    { key: 'seed', label: 'Seed', min: 0, max: 9999, initial: 21 },
    { key: 'scanlines', label: 'Scanlines', min: 0, max: 100, initial: 30, unit: '%' },
    { key: 'shiftY', label: 'Vertical offset', min: -100, max: 100, initial: 0, unit: 'px' },
  ],
  vhs: [
    { key: 'seed', label: 'Seed', min: 0, max: 9999, initial: 9 },
    { key: 'density', label: 'Dropout density', min: 0, max: 100, initial: 55, unit: '%' },
    { key: 'scanlines', label: 'Scanlines', min: 0, max: 100, initial: 60, unit: '%' },
  ],
  motionblur: [{ key: 'angle', label: 'Direction', min: -180, max: 180, initial: 0, unit: '°' }],
  grain: [{ key: 'seed', label: 'Grain seed', min: 0, max: 9999, initial: 17 }],
  noise: [{ key: 'seed', label: 'Noise seed', min: 0, max: 9999, initial: 17 }],
};

export function clampEffectAmount(kind: EffectKind, amount: number): number {
  const descriptor = EFFECT_CONTROLS[kind];
  return Math.max(descriptor.min, Math.min(descriptor.max, Number.isFinite(amount) ? amount : descriptor.min));
}

export const FX_PRESETS: Record<string, {
  kind: EffectKind; amount: number; color?: string; parameters?: Effect['parameters'];
}[]> = {
  'Hyper Outline': [
    { kind: 'cutout', amount: 38 },
    { kind: 'outline', amount: 14, color: '#ffffff', parameters: { opacity: 100, softness: 0 } },
    { kind: 'glow', amount: 17, color: '#956fff', parameters: { spread: 0, softness: 18, opacity: 75 } },
  ],
  'Neon Pulse': [
    { kind: 'outline', amount: 6, color: '#28eeff' },
    { kind: 'glow', amount: 17, color: '#a44cff', parameters: { spread: 3, softness: 27, opacity: 85 } },
    { kind: 'contrast', amount: 124 },
  ],
  'Shadow Forge': [
    { kind: 'shadow', amount: 16, color: '#11111d', parameters: { offsetX: 15, offsetY: 17, blur: 10, opacity: 90 } },
    { kind: 'shadow', amount: 12, color: '#5d42b3', parameters: { offsetX: -8, offsetY: 4, blur: 27, opacity: 65 } },
  ],
  'Dream Bloom': [
    { kind: 'highlights', amount: 27 },
    { kind: 'glow', amount: 12, color: '#ffb9ee', parameters: { spread: 0, softness: 34, opacity: 65 } },
    { kind: 'vibrance', amount: 31 },
  ],
  'Glitch Matrix': [
    { kind: 'glitch', amount: 35, parameters: { density: 70, scanlines: 45, seed: 42, shiftY: 2 } },
    { kind: 'contrast', amount: 145 },
  ],
  'Comic Pop': [
    { kind: 'cartoon', amount: 68 },
    { kind: 'comicink', amount: 68 },
    { kind: 'saturate', amount: 150 },
  ],
  'Frostbite': [
    { kind: 'temperature', amount: -50 },
    { kind: 'outline', amount: 5, color: '#b8efff' },
    { kind: 'glow', amount: 12, color: '#3aa9ff', parameters: { softness: 26, spread: 0 } },
  ],
  'Ember Glow': [
    { kind: 'temperature', amount: 65 },
    { kind: 'outline', amount: 5, color: '#ffba47' },
    { kind: 'glow', amount: 15, color: '#ff642e', parameters: { softness: 21 } },
  ],
  'Prism Split': [
    { kind: 'chromatic', amount: 9, parameters: { shiftY: 3, density: 5, seed: 8 } },
    { kind: 'glow', amount: 9, color: '#a66cff', parameters: { spread: 0, softness: 16 } },
  ],
  'Golden Hour': [
    { kind: 'temperature', amount: 48 },
    { kind: 'highlights', amount: 21 },
    { kind: 'shadows', amount: 12 },
    { kind: 'vibrance', amount: 25 },
  ],
  'Aurora Flow': [
    { kind: 'aurora', amount: 66 },
    { kind: 'glow', amount: 13, color: '#ad64f7', parameters: { softness: 20, spread: 0 } },
  ],
  'Electric Edge': [
    { kind: 'neonedge', amount: 92, color: '#42e2ff' },
    { kind: 'glow', amount: 8, color: '#55a7ff', parameters: { softness: 15 } },
  ],
  'Holographic': [
    { kind: 'gradientmap', amount: 57, color: '#87deff' },
    { kind: 'chromatic', amount: 4 },
    { kind: 'vibrance', amount: 58 },
  ],
  'Retro Vision': [
    { kind: 'crt', amount: 65 },
    { kind: 'chromatic', amount: 4, parameters: { scanlines: 30 } },
    { kind: 'vignette', amount: 55 },
  ],
  'Spectrum Burst': [
    { kind: 'burst', amount: 65 },
    { kind: 'glow', amount: 9, color: '#e77dff', parameters: { spread: 2, softness: 15 } },
  ],
};

export function newEffect(kind: EffectKind, amount?: number, color?: string, parameters?: Effect['parameters']): Effect {
  const definition = FILTERS.find(item => item.kind === kind);
  return {
    id: uid(), kind, enabled: true,
    amount: clampEffectAmount(kind, amount ?? definition?.initial ?? 100),
    color,
    ...(EFFECT_PARAMETERS[kind]?.length ? {
      parameters: {
        ...Object.fromEntries(EFFECT_PARAMETERS[kind]!.map(control => [control.key, control.initial])),
        ...parameters,
      },
    } : parameters ? { parameters } : {}),
  };
}

/** CSS filter representation kept for SVG compatibility and quick previews. */
export function effectFilter(effect: Effect): string {
  const amount = clampEffectAmount(effect.kind, effect.amount);
  if (effect.kind === 'hue') return `hue-rotate(${amount}deg)`;
  if (effect.kind === 'blur') return `blur(${amount}px)`;
  if (['brightness', 'contrast', 'saturate', 'grayscale', 'sepia', 'invert'].includes(effect.kind)) {
    const name = effect.kind === 'saturate' ? 'saturate' : effect.kind;
    return `${name}(${amount}%)`;
  }
  return 'none';
}

/** Non-destructive effect graph shared by editor, frame export, and image export. */
export function processEffects(source: HTMLCanvasElement, effects: readonly Effect[]): HTMLCanvasElement {
  let current = source;
  for (const effect of effects) {
    if (!effect.enabled) continue;
    const controls = EFFECT_CONTROLS[effect.kind];
    // A zero setting is a meaningful state for several effects; never use a universal "amount > 0" guard.
    if (effect.kind === 'outline' && effect.amount === 0) continue;
    if (effect.kind === 'cutout' && effect.amount === 0) continue;
    if (controls && !Number.isFinite(effect.amount)) continue;
    current = applyEffect(current, effect);
  }
  return current;
}

const effectCache = new WeakMap<Layer, { width: number; height: number; image: HTMLCanvasElement }>();

export function renderWithEffects(
  ctx: CanvasRenderingContext2D,
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
): void {
  const effects = layer.effects ?? [];
  if (!effects.some(effect => effect.enabled)) {
    paint(ctx, layer);
    return;
  }
  const cached = layer.type === 'vector' ? effectCache.get(layer) : undefined;
  if (cached && cached.width === width && cached.height === height) {
    ctx.drawImage(cached.image, 0, 0, width, height);
    return;
  }
  const source = document.createElement('canvas');
  const scale = Math.min(1, Math.sqrt(16_000_000 / Math.max(1, width * height)));
  source.width = Math.max(1, Math.floor(width * scale));
  source.height = Math.max(1, Math.floor(height * scale));
  const temporary = source.getContext('2d');
  if (!temporary) return;
  temporary.scale(scale, scale);
  paint(temporary, layer);
  const processed = processEffects(source, effects);
  if (layer.type === 'vector') effectCache.set(layer, { width, height, image: processed });
  ctx.drawImage(processed, 0, 0, width, height);
}
