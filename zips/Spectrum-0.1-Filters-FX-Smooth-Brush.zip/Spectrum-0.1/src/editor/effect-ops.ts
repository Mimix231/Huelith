import type { Effect, EffectKind } from './types';

/** Canvas2D processors shared by interactive previews, saved layers, and exports. */
function surface(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function context(canvas: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Spectrum requires Canvas 2D.');
  return ctx;
}

function clamp(value: number, min = 0, max = 255): number {
  return Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
}

function mix(a: number, b: number, amount: number): number {
  return a + (b - a) * amount;
}

function noise(x: number, y: number, seed: number): number {
  let n = Math.imul(x + 1, 374761393) + Math.imul(y + 1, 668265263) + Math.imul(seed, 1442695041);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}

function colorFromHex(value: string | undefined, fallback: string): [number, number, number] {
  const match = /^#([0-9a-f]{6})$/i.exec(value ?? fallback);
  const hex = match?.[1] ?? fallback.slice(1);
  return [0, 2, 4].map(index => parseInt(hex.slice(index, index + 2), 16)) as [number, number, number];
}

function pixels(canvas: HTMLCanvasElement): ImageData {
  return context(canvas).getImageData(0, 0, canvas.width, canvas.height);
}

function fromPixels(image: ImageData): HTMLCanvasElement {
  const output = surface(image.width, image.height);
  context(output).putImageData(image, 0, 0);
  return output;
}

function copyImage(source: HTMLCanvasElement): HTMLCanvasElement {
  const output = surface(source.width, source.height);
  context(output).drawImage(source, 0, 0);
  return output;
}

function filtered(source: HTMLCanvasElement, filter: string): HTMLCanvasElement {
  const output = surface(source.width, source.height);
  const ctx = context(output);
  ctx.filter = filter;
  ctx.drawImage(source, 0, 0);
  return output;
}

function softened(source: HTMLCanvasElement, radius: number): HTMLCanvasElement {
  return radius < 0.3 ? copyImage(source) : filtered(source, `blur(${clamp(radius, 0, 80)}px)`);
}

function shade(r: number, g: number, b: number): number {
  return r * 0.2126 + g * 0.7152 + b * 0.0722;
}

function pixelEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const image = pixels(source);
  const data = image.data;
  const amount = effect.amount;
  const t = amount / 100;
  const tint = colorFromHex(effect.color, '#b579ff');
  const width = image.width;
  for (let i = 0; i < data.length; i += 4) {
    const x = (i / 4) % width;
    const y = Math.floor(i / 4 / width);
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const lum = shade(r, g, b);
    let red = r, green = g, blue = b;
    switch (effect.kind) {
      case 'exposure': {
        const power = Math.pow(2, amount / 100);
        red *= power; green *= power; blue *= power;
        break;
      }
      case 'highlights': case 'whites': case 'shadows': case 'blacks': {
        const weight = effect.kind === 'highlights' ? Math.pow(lum / 255, 2)
          : effect.kind === 'whites' ? Math.pow(lum / 255, 4)
            : effect.kind === 'shadows' ? Math.pow(1 - lum / 255, 2) : Math.pow(1 - lum / 255, 4);
        const delta = amount * 1.25 * weight;
        red += delta; green += delta; blue += delta;
        break;
      }
      case 'temperature':
        red += amount * 0.8; green += amount * 0.08; blue -= amount * 0.75;
        break;
      case 'tint':
        red += amount * 0.35; green -= amount * 0.52; blue += amount * 0.35;
        break;
      case 'vibrance': {
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const strength = (max - min) / 255;
        const factor = 1 + (amount / 100) * (1 - strength) * 1.1;
        red = mix(lum, r, factor); green = mix(lum, g, factor); blue = mix(lum, b, factor);
        break;
      }
      case 'gamma': {
        const exponent = 100 / Math.max(1, amount);
        red = 255 * Math.pow(r / 255, exponent);
        green = 255 * Math.pow(g / 255, exponent);
        blue = 255 * Math.pow(b / 255, exponent);
        break;
      }
      case 'curves': {
        const curve = (value: number): number => {
          const n = value / 255;
          return 255 * clamp(n + amount / 100 * n * (1 - n) * (2 * n - 1) * 2, 0, 1);
        };
        red = curve(r); green = curve(g); blue = curve(b);
        break;
      }
      case 'levels': {
        const low = Math.max(0, amount) * 0.65;
        const high = 255 + Math.min(0, amount) * 0.65;
        red = (r - low) * 255 / (high - low);
        green = (g - low) * 255 / (high - low);
        blue = (b - low) * 255 / (high - low);
        break;
      }
      case 'balance':
        red += amount * (0.4 + 0.6 * lum / 255);
        blue -= amount * (1.1 - 0.5 * lum / 255);
        green += amount * 0.15;
        break;
      case 'selective': {
        const saturation = Math.max(r, g, b) - Math.min(r, g, b);
        red += amount * (r - lum) * saturation / 25500;
        green += amount * (g - lum) * saturation / 25500;
        blue += amount * (b - lum) * saturation / 25500;
        break;
      }
      case 'mixer':
        red = r * (1 + amount / 220) + g * amount / 600 - b * amount / 380;
        green = g + (r - b) * amount / 500;
        blue = b * (1 - amount / 240) + g * amount / 300;
        break;
      case 'gradientmap': case 'duotone': {
        const low = effect.kind === 'duotone' ? [24, 33, 65] : [34, 17, 66];
        const u = lum / 255;
        const mapped = low.map((v, k) => mix(v, tint[k], u));
        red = mix(r, mapped[0], t); green = mix(g, mapped[1], t); blue = mix(b, mapped[2], t);
        break;
      }
      case 'solarize': {
        const threshold = 255 * (1 - t);
        red = r > threshold ? 255 - r : r;
        green = g > threshold ? 255 - g : g;
        blue = b > threshold ? 255 - b : b;
        break;
      }
      case 'grain': case 'noise': {
        const v = (noise(x, y, effect.parameters?.seed ?? 17) - 0.5) * amount * 2;
        red += v;
        green += effect.kind === 'grain' ? v : (noise(x + 21, y, 2) - 0.5) * amount * 2;
        blue += effect.kind === 'grain' ? v : (noise(x, y + 31, 7) - 0.5) * amount * 2;
        break;
      }
      case 'posterize': case 'cartoon': case 'oilpaint': {
        const levels = effect.kind === 'posterize' ? Math.round(amount)
          : effect.kind === 'cartoon' ? Math.max(3, 11 - Math.round(amount / 12))
            : Math.max(3, 17 - Math.round(amount / 9));
        const unit = 255 / (levels - 1);
        red = Math.round(r / unit) * unit;
        green = Math.round(g / unit) * unit;
        blue = Math.round(b / unit) * unit;
        break;
      }
      case 'halftone': {
        const cell = Math.max(2, amount);
        const cx = x % cell - cell / 2;
        const cy = y % cell - cell / 2;
        const d = Math.hypot(cx, cy);
        const dot = d < cell * (1 - lum / 255) * 0.49;
        red = green = blue = dot ? 22 : 246;
        break;
      }
      case 'dither': {
        const grid = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
        const threshold = (grid[(x % 4) + (y % 4) * 4] - 7.5) * amount / 9;
        const v = lum + threshold > 127 ? 255 : 0;
        red = mix(r, v, t); green = mix(g, v, t); blue = mix(b, v, t);
        break;
      }
      case 'sketch': {
        const paper = 255 - (255 - lum) * t;
        red = green = blue = paper;
        break;
      }
      case 'watercolor': {
        const steps = Math.max(3, 14 - Math.floor(amount / 10));
        const unit = 255 / (steps - 1);
        red = mix(r, Math.round(r / unit) * unit, t);
        green = mix(g, Math.round(g / unit) * unit, t);
        blue = mix(b, Math.round(b / unit) * unit, t);
        break;
      }
      case 'crt': {
        const scan = y % 3 === 0 ? 1 - t * 0.58 : 1;
        const phosphor = x % 3;
        red = r * scan * (phosphor === 0 ? 1 : 1 - t * 0.18);
        green = g * scan * (phosphor === 1 ? 1 : 1 - t * 0.18);
        blue = b * scan * (phosphor === 2 ? 1 : 1 - t * 0.18);
        break;
      }
      default:
        break;
    }
    data[i] = clamp(red);
    data[i + 1] = clamp(green);
    data[i + 2] = clamp(blue);
  }
  return fromPixels(image);
}

/** Sobel luminance derivative, retaining the original alpha plane. */
function edgeMap(source: HTMLCanvasElement): ImageData {
  const original = pixels(source);
  const result = new ImageData(original.width, original.height);
  const { width, height, data } = original;
  const at = (x: number, y: number): number => {
    const i = (Math.min(height - 1, Math.max(0, y)) * width + Math.min(width - 1, Math.max(0, x))) * 4;
    return shade(data[i], data[i + 1], data[i + 2]);
  };
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const gx = -at(x - 1, y - 1) + at(x + 1, y - 1) - 2 * at(x - 1, y)
        + 2 * at(x + 1, y) - at(x - 1, y + 1) + at(x + 1, y + 1);
      const gy = -at(x - 1, y - 1) - 2 * at(x, y - 1) - at(x + 1, y - 1)
        + at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1);
      const i = (y * width + x) * 4;
      result.data[i] = result.data[i + 1] = result.data[i + 2] = clamp(Math.hypot(gx, gy) / 4);
      result.data[i + 3] = data[i + 3];
    }
  }
  return result;
}

function detailEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const amount = effect.amount;
  const { width, height } = source;
  if (['blur', 'boxblur', 'lensblur', 'surfaceblur', 'frosted'].includes(effect.kind)) {
    const radius = effect.kind === 'boxblur' ? amount * 0.55 : amount;
    if (effect.kind === 'surfaceblur') {
      const softenedImage = pixels(softened(source, radius));
      const base = pixels(source);
      for (let i = 0; i < base.data.length; i += 4) {
        const originalLum = shade(base.data[i], base.data[i + 1], base.data[i + 2]);
        const blurredLum = shade(softenedImage.data[i], softenedImage.data[i + 1], softenedImage.data[i + 2]);
        const weight = 1 - clamp(Math.abs(originalLum - blurredLum) / 60, 0, 1);
        for (let channel = 0; channel < 3; channel++) base.data[i + channel] = mix(base.data[i + channel], softenedImage.data[i + channel], weight);
      }
      return fromPixels(base);
    }
    return effect.kind === 'frosted' ? distort(softened(source, radius * 0.5), effect) : softened(source, radius);
  }
  if (effect.kind === 'pixelate' || effect.kind === 'mosaic') {
    const cell = Math.max(1, Math.round(amount));
    const small = surface(Math.max(1, Math.ceil(width / cell)), Math.max(1, Math.ceil(height / cell)));
    context(small).drawImage(source, 0, 0, small.width, small.height);
    const output = surface(width, height);
    const ctx = context(output);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(small, 0, 0, width, height);
    if (effect.kind === 'mosaic') {
      ctx.strokeStyle = '#00000055';
      ctx.lineWidth = Math.max(0.5, cell * 0.06);
      for (let x = cell; x < width; x += cell) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke(); }
      for (let y = cell; y < height; y += cell) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke(); }
    }
    return output;
  }
  if (effect.kind === 'motionblur' || effect.kind === 'radialblur' || effect.kind === 'zoomblur') {
    const output = surface(width, height);
    const ctx = context(output);
    const count = 13;
    const radius = amount * 0.8;
    ctx.globalAlpha = 1 / count;
    for (let i = 0; i < count; i++) {
      const t = (i / (count - 1)) * 2 - 1;
      ctx.save();
      if (effect.kind === 'motionblur') {
        const angle = (effect.parameters?.angle ?? 0) * Math.PI / 180;
        ctx.drawImage(source, Math.cos(angle) * t * radius, Math.sin(angle) * t * radius);
      } else {
        ctx.translate(width / 2, height / 2);
        if (effect.kind === 'radialblur') ctx.rotate(t * radius / 180);
        else ctx.scale(1 + t * radius / 400, 1 + t * radius / 400);
        ctx.drawImage(source, -width / 2, -height / 2);
      }
      ctx.restore();
    }
    return output;
  }
  if (['sharpen', 'unsharp', 'highpass', 'clarity', 'texture', 'denoise', 'emboss', 'edges', 'ink', 'comicink', 'neonedge', 'cartoon'].includes(effect.kind)) {
    const output = pixels(source);
    const base = output.data;
    const blur = pixels(softened(source, effect.kind === 'clarity' ? 9 : effect.kind === 'texture' ? 3 : effect.kind === 'highpass' ? amount : 2)).data;
    const edges = ['edges', 'emboss', 'ink', 'comicink', 'neonedge', 'cartoon'].includes(effect.kind) ? edgeMap(source).data : null;
    for (let i = 0; i < base.length; i += 4) {
      const diff = edges?.[i] ?? 0;
      const a = effect.kind === 'texture' ? amount / 100 : effect.kind === 'clarity' ? amount / 100 : amount / 100;
      for (let c = 0; c < 3; c++) {
        if (['sharpen', 'unsharp', 'clarity', 'texture'].includes(effect.kind)) {
          base[i + c] = clamp(base[i + c] + (base[i + c] - blur[i + c]) * a * (effect.kind === 'sharpen' ? 2 : 1));
        } else if (effect.kind === 'highpass') {
          base[i + c] = clamp(128 + base[i + c] - blur[i + c]);
        } else if (effect.kind === 'denoise') {
          base[i + c] = mix(base[i + c], blur[i + c], a);
        } else if (effect.kind === 'edges') {
          base[i + c] = clamp(diff * a);
        } else if (effect.kind === 'emboss') {
          base[i + c] = clamp(128 + (base[i + c] - blur[i + c]) * a * 4 + diff * a * 0.15);
        } else if (effect.kind === 'ink' || effect.kind === 'comicink') {
          base[i + c] = diff > (effect.kind === 'ink' ? 20 : 34) ? clamp(base[i + c] * (1 - a)) : (effect.kind === 'ink' ? 245 : base[i + c]);
        } else if (effect.kind === 'cartoon') {
          const step = 255 / Math.max(3, 11 - Math.round(amount / 12));
          base[i + c] = diff > 38 ? 18 : Math.round(base[i + c] / step) * step;
        } else if (effect.kind === 'neonedge') {
          const rgb = colorFromHex(effect.color, '#52dcff');
          base[i + c] = clamp(base[i + c] * 0.12 + diff * rgb[c] / 80 * a);
        }
      }
    }
    return fromPixels(output);
  }
  return pixelEffect(source, effect);
}

/** Squared Euclidean distance transform, linear in pixel count (two separable 1D passes). */
function distanceTransform(source: Uint8ClampedArray, width: number, height: number): Float64Array {
  const n = width * height;
  const stage = new Float64Array(n);
  const out = new Float64Array(n);
  const inf = 1e14;
  function edt(length: number, sample: (i: number) => number, write: (i: number, value: number) => void): void {
    const sites = new Int32Array(length);
    const cuts = new Float64Array(length + 1);
    let count = -1;
    for (let q = 0; q < length; q++) {
      const fq = sample(q);
      if (fq >= inf) continue;
      let intersect = -Infinity;
      while (count >= 0) {
        const k = sites[count];
        intersect = ((fq + q * q) - (sample(k) + k * k)) / (2 * (q - k));
        if (intersect > cuts[count]) break;
        count--;
      }
      count++;
      sites[count] = q;
      cuts[count] = count === 0 ? -Infinity : intersect;
      cuts[count + 1] = Infinity;
    }
    if (count < 0) { for (let q = 0; q < length; q++) write(q, inf); return; }
    let k = 0;
    for (let q = 0; q < length; q++) {
      while (cuts[k + 1] < q) k++;
      const d = q - sites[k];
      write(q, d * d + sample(sites[k]));
    }
  }
  for (let x = 0; x < width; x++) {
    edt(height, y => source[(y * width + x) * 4 + 3] >= 15 ? 0 : inf, (y, value) => { stage[y * width + x] = value; });
  }
  for (let y = 0; y < height; y++) {
    edt(width, x => stage[y * width + x], (x, value) => { out[y * width + x] = value; });
  }
  return out;
}

function silhouetteEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const { width, height } = source;
  const original = pixels(source);
  const out = new ImageData(width, height);
  const { data } = out;
  const tint = colorFromHex(effect.color, effect.kind === 'glow' ? '#9b6bff' : '#ffffff');
  const radius = Math.max(0, effect.amount);
  const softness = Math.max(0, effect.kind === 'glow'
    ? (effect.parameters?.softness ?? 24) * (0.5 + radius / 30)
    : effect.parameters?.softness ?? 0);
  const spread = Math.max(0, effect.kind === 'glow'
    ? (effect.parameters?.spread ?? 0) + radius * 0.2
    : radius);
  const opacity = clamp(effect.parameters?.opacity ?? (effect.kind === 'glow' ? 75 : 100), 0, 100) / 100;
  const distance = distanceTransform(original.data, width, height);
  for (let i = 0; i < width * height; i++) {
    const dist = Math.sqrt(distance[i]);
    const alpha = dist <= spread ? 1 : softness > 0 ? Math.max(0, 1 - (dist - spread) / softness) : 0;
    data[i * 4] = tint[0];
    data[i * 4 + 1] = tint[1];
    data[i * 4 + 2] = tint[2];
    data[i * 4 + 3] = Math.round(255 * opacity * alpha);
  }
  const output = fromPixels(out);
  context(output).drawImage(source, 0, 0);
  return output;
}

/** Flood-fill only corners' connected background; opaque subjects remain intact. */
function removeCornerBackground(source: HTMLCanvasElement, tolerance: number): HTMLCanvasElement {
  const image = pixels(source);
  const { width, height, data } = image;
  const seen = new Uint8Array(width * height);
  const queue = new Int32Array(width * height);
  const seeds = [0, width - 1, (height - 1) * width, width * height - 1];
  let head = 0, tail = 0;
  const colors = seeds.map(index => [data[index * 4], data[index * 4 + 1], data[index * 4 + 2]]);
  const similar = (index: number): boolean => colors.some(([r, g, b]) => {
    const i = index * 4;
    return Math.hypot(data[i] - r, data[i + 1] - g, data[i + 2] - b) <= tolerance;
  });
  for (const index of seeds) {
    if (!seen[index] && similar(index)) { seen[index] = 1; queue[tail++] = index; }
  }
  while (head < tail) {
    const index = queue[head++];
    const x = index % width;
    const next = [index - width, index + width, x > 0 ? index - 1 : -1, x < width - 1 ? index + 1 : -1];
    for (const candidate of next) {
      if (candidate < 0 || candidate >= width * height || seen[candidate] || !similar(candidate)) continue;
      seen[candidate] = 1;
      queue[tail++] = candidate;
    }
    data[index * 4 + 3] = 0;
  }
  return fromPixels(image);
}

function distort(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const original = pixels(source);
  const out = new ImageData(original.width, original.height);
  const { width, height, data } = original;
  const amplitude = effect.amount;
  const cx = width / 2, cy = height / 2;
  const limit = Math.max(width, height);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const dx = x - cx, dy = y - cy;
      const radial = Math.hypot(dx, dy);
      let sx = x, sy = y;
      switch (effect.kind) {
        case 'swirl': {
          const angle = amplitude * Math.PI / 180 * Math.max(0, 1 - radial / limit);
          sx = cx + dx * Math.cos(angle) - dy * Math.sin(angle);
          sy = cy + dx * Math.sin(angle) + dy * Math.cos(angle);
          break;
        }
        case 'ripple': {
          const displacement = Math.sin(radial / 12) * amplitude * 0.4;
          sx = x + displacement * dx / Math.max(1, radial);
          sy = y + displacement * dy / Math.max(1, radial);
          break;
        }
        case 'wave': sx = x + Math.sin(y / 17) * amplitude * 0.5; break;
        case 'glass': case 'frosted': {
          sx = x + (noise(Math.floor(x / 4), Math.floor(y / 4), 91) - 0.5) * amplitude;
          sy = y + (noise(Math.floor(x / 4), Math.floor(y / 4), 27) - 0.5) * amplitude;
          break;
        }
        default: break;
      }
      const sampleX = Math.round(sx), sampleY = Math.round(sy);
      const destination = (y * width + x) * 4;
      if (sampleX >= 0 && sampleX < width && sampleY >= 0 && sampleY < height) {
        const start = (sampleY * width + sampleX) * 4;
        for (let channel = 0; channel < 4; channel++) out.data[destination + channel] = data[start + channel];
      }
    }
  }
  return fromPixels(out);
}

function scanDistortion(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const output = surface(source.width, source.height);
  const ctx = context(output);
  const amount = effect.amount;
  const seed = effect.parameters?.seed ?? 7;
  const density = clamp(effect.parameters?.density ?? amount, 0, 100);
  const shift = effect.kind === 'chromatic' ? amount : amount / 2;
  const stripe = Math.max(2, Math.round(5 - amount / 45));
  ctx.drawImage(source, 0, 0);
  ctx.save();
  for (let y = 0; y < source.height; y += stripe) {
    const rand = noise(0, y, seed);
    if (rand * 100 >= density) continue;
    ctx.drawImage(source, 0, y, source.width, Math.min(stripe, source.height - y),
      (rand - 0.5) * shift * 2, y + (effect.parameters?.shiftY ?? 0), source.width, Math.min(stripe, source.height - y));
  }
  if (effect.kind === 'chromatic' || effect.kind === 'vhs' || effect.kind === 'glitch') {
    for (const [dx, fill] of [[-shift, '#ff2856'], [shift, '#238bff']] as const) {
      const channel = surface(source.width, source.height);
      const layer = context(channel);
      layer.drawImage(source, 0, 0);
      layer.globalCompositeOperation = 'source-in';
      layer.fillStyle = fill;
      layer.fillRect(0, 0, channel.width, channel.height);
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = 0.4;
      ctx.drawImage(channel, dx, effect.parameters?.shiftY ?? 0);
    }
  }
  ctx.restore();
  const scanlines = clamp(effect.parameters?.scanlines ?? (effect.kind === 'chromatic' ? 0 : amount), 0, 100);
  if (scanlines) {
    ctx.save();
    ctx.globalCompositeOperation = 'source-atop';
    ctx.fillStyle = `rgba(3,4,16,${scanlines / 220})`;
    for (let y = 0; y < source.height; y += 3) ctx.fillRect(0, y, source.width, 1);
    ctx.restore();
  }
  return output;
}

function shadowEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const output = surface(source.width, source.height);
  const ctx = context(output);
  const offsetX = effect.parameters?.offsetX ?? 10;
  const offsetY = effect.parameters?.offsetY ?? 10;
  const blur = Math.max(0, (effect.parameters?.blur ?? 20) + effect.amount * 0.25);
  const tint = effect.color ?? '#172035';
  const shadow = surface(source.width, source.height);
  const layer = context(shadow);
  layer.drawImage(source, 0, 0);
  layer.globalCompositeOperation = 'source-in';
  layer.fillStyle = tint;
  layer.fillRect(0, 0, source.width, source.height);
  ctx.save();
  ctx.globalAlpha = clamp(effect.parameters?.opacity ?? 100, 0, 100) / 100 * clamp(effect.amount / 30, 0, 1);
  ctx.filter = `blur(${blur}px)`;
  ctx.drawImage(shadow, offsetX, offsetY);
  ctx.restore();
  ctx.drawImage(source, 0, 0);
  return output;
}

function auroraEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const output = copyImage(source);
  const { width, height } = output;
  const image = pixels(output);
  const strength = clamp(effect.amount / 100, 0, 1);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const wave = Math.sin(x / 27 + Math.sin(y / 41) * 2.5) * 0.5 + 0.5;
      const band = Math.pow(Math.max(0, Math.sin(y / 19 + x / 53)), 4);
      const intensity = wave * band * strength;
      const i = (y * width + x) * 4;
      image.data[i] = clamp(image.data[i] + 88 * intensity);
      image.data[i + 1] = clamp(image.data[i + 1] + 148 * intensity);
      image.data[i + 2] = clamp(image.data[i + 2] + 204 * intensity);
    }
  }
  return fromPixels(image);
}

function burstEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const output = copyImage(source);
  const ctx = context(output);
  const radius = Math.hypot(source.width, source.height) / 2;
  const width = source.width;
  const height = source.height;
  const intensity = clamp(effect.amount / 100, 0, 1);
  const seed = effect.parameters?.seed ?? 19;
  ctx.save();
  ctx.translate(width / 2, height / 2);
  ctx.globalCompositeOperation = 'screen';
  for (let i = 0; i < 88; i++) {
    const angle = i / 88 * Math.PI * 2;
    const scatter = noise(i, 17, seed);
    const length = radius * (0.15 + scatter * 0.95);
    const start = radius * (0.03 + scatter * 0.1);
    ctx.globalAlpha = (0.1 + scatter * 0.45) * intensity;
    ctx.strokeStyle = i % 3 === 0 ? '#f37cff' : i % 3 === 1 ? '#60d5ff' : '#ffda91';
    ctx.lineWidth = 0.6 + scatter * 1.7;
    ctx.beginPath();
    ctx.moveTo(Math.cos(angle) * start, Math.sin(angle) * start);
    ctx.lineTo(Math.cos(angle) * length, Math.sin(angle) * length);
    ctx.stroke();
  }
  ctx.restore();
  return output;
}

function backdropEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const output = surface(source.width, source.height);
  const ctx = context(output);
  const x = effect.parameters?.offsetX ?? 0;
  const y = effect.parameters?.offsetY ?? 0;
  const scale = Math.max(0.1, (effect.parameters?.scale ?? 100) / 100);
  ctx.save();
  ctx.globalAlpha = clamp(effect.parameters?.opacity ?? 65, 0, 100) / 100 * clamp(effect.amount / 100, 0, 1);
  ctx.fillStyle = effect.color ?? '#694dca';
  ctx.translate(source.width / 2 + x, source.height / 2 + y);
  ctx.scale(scale, scale);
  ctx.fillRect(-source.width / 2, -source.height / 2, source.width, source.height);
  ctx.restore();
  ctx.drawImage(source, 0, 0);
  return output;
}

/** Every catalog entry has a distinct, deterministically rendered image operation. */
export function applyEffect(source: HTMLCanvasElement, effect: Effect): HTMLCanvasElement {
  const kind: EffectKind = effect.kind;
  switch (kind) {
    case 'brightness': case 'contrast': case 'saturate': case 'hue':
    case 'grayscale': case 'sepia': case 'invert': {
      const name = kind === 'saturate' ? 'saturate' : kind === 'hue' ? 'hue-rotate' : kind;
      return filtered(source, `${name}(${effect.amount}${kind === 'hue' ? 'deg' : '%'})`);
    }
    case 'blur': case 'boxblur': case 'motionblur': case 'radialblur': case 'zoomblur':
    case 'lensblur': case 'surfaceblur': case 'sharpen': case 'unsharp': case 'highpass':
    case 'clarity': case 'texture': case 'denoise': case 'emboss': case 'edges': case 'pixelate':
    case 'mosaic': case 'ink': case 'comicink': case 'neonedge': case 'cartoon': case 'frosted':
      return detailEffect(source, effect);
    case 'cutout': return removeCornerBackground(source, effect.amount);
    case 'outline': case 'glow': return silhouetteEffect(source, effect);
    case 'shadow': return shadowEffect(source, effect);
    case 'aurora': return auroraEffect(source, effect);
    case 'burst': return burstEffect(source, effect);
    case 'backdrop': return backdropEffect(source, effect);
    case 'chromatic': case 'glitch': case 'vhs': return scanDistortion(source, effect);
    case 'swirl': case 'ripple': case 'wave': case 'glass': return distort(source, effect);
    case 'vignette': {
      const output = copyImage(source);
      const ctx = context(output);
      const radius = Math.hypot(source.width, source.height) * 0.5;
      const gradient = ctx.createRadialGradient(source.width / 2, source.height / 2, radius * 0.1,
        source.width / 2, source.height / 2, radius);
      gradient.addColorStop(0, '#00000000');
      gradient.addColorStop(1, `rgba(0,0,0,${clamp(effect.amount / 100, 0, 1)})`);
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, source.width, source.height);
      return output;
    }
    default:
      return pixelEffect(source, effect);
  }
}
