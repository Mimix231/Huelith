import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import {
  Button, Dialog, DialogActions, DialogContent, DialogTitle, Divider, IconButton,
  Menu, MenuItem, Slider, Stack, TextField, Tooltip, Typography,
} from '@mui/material';
import {
  Add, ArrowDownward, ArrowUpward, AutoAwesome, Brush, Close, Code,
  Colorize, ContentCopy, Create, Delete, Download, Edit, Favorite,
  FileOpen, FlipToFront, FolderOpen, GridOn, History, Image, Layers,
  Lock, LockOpen, Menu as MenuIcon, Mouse, Palette, PanTool, PhotoCamera,
  RadioButtonUnchecked, Rectangle, Redo, Save, Settings, ShapeLine,
  TextFields, Undo, Visibility, VisibilityOff, ZoomIn, ZoomOut, HorizontalRule,
} from '@mui/icons-material';
import { activeLayer, activeTab, useEditor, type EditorStore } from './editor/store';
import { flattenLayers, validSize, type Tool, type Workspace } from './editor/types';
import { exportImage, exportSvg, importImage, openProject, saveProject } from './editor/files';
import { getRecovery, storeRecovery } from './editor/recovery';
import Canvas from './components/Canvas';
import './styles/app.css';

interface ToolEntry {
  id: Tool;
  label: string;
  icon: ReactNode;
  shortcut: string;
}

const tools: ToolEntry[] = [
  { id: 'move', label: 'Move', icon: <Mouse />, shortcut: 'V' },
  { id: 'hand', label: 'Pan', icon: <PanTool />, shortcut: 'H' },
  { id: 'brush', label: 'Brush', icon: <Brush />, shortcut: 'B' },
  { id: 'eraser', label: 'Eraser', icon: <Edit />, shortcut: 'E' },
  { id: 'eyedropper', label: 'Eyedropper', icon: <Colorize />, shortcut: 'I' },
  { id: 'rectangle', label: 'Rectangle', icon: <Rectangle />, shortcut: 'R' },
  { id: 'ellipse', label: 'Ellipse', icon: <RadioButtonUnchecked />, shortcut: 'O' },
  { id: 'line', label: 'Line', icon: <HorizontalRule />, shortcut: 'L' },
  { id: 'pen', label: 'Freehand vector', icon: <Create />, shortcut: 'P' },
  { id: 'text', label: 'Text', icon: <TextFields />, shortcut: 'T' },
];

function makeTheme(workspace: Workspace) {
  const primary = workspace === 'material' ? '#80dbc9' : workspace === 'classic' ? '#b7c6f8' : '#a99bff';
  return createTheme({
    palette: {
      mode: 'dark', primary: { main: primary }, secondary: { main: '#6fe2d1' },
      background: { default: '#111525', paper: '#1c2235' },
    },
    shape: { borderRadius: workspace === 'classic' ? 5 : 12 },
    typography: {
      fontFamily: 'Inter, system-ui, -apple-system, Segoe UI, sans-serif',
      button: { textTransform: 'none', fontWeight: 650 },
    },
    components: {
      MuiButton: { styleOverrides: { root: { borderRadius: workspace === 'classic' ? 5 : 11 } } },
      MuiIconButton: { styleOverrides: { root: { borderRadius: workspace === 'classic' ? 5 : 10 } } },
    },
  });
}

interface ActionIconProps {
  title: string;
  children: ReactNode;
  onClick: () => void;
  active?: boolean;
  disabled?: boolean;
}

function ActionIcon({ title, children, onClick, active = false, disabled = false }: ActionIconProps) {
  return (
    <Tooltip title={title} placement="right">
      <span>
        <IconButton
          aria-label={title}
          size="small"
          className={active ? 'selected' : ''}
          onClick={onClick}
          disabled={disabled}
        >
          {children}
        </IconButton>
      </span>
    </Tooltip>
  );
}

function ToolRail({ state, openNew }: { state: EditorStore; openNew: () => void }) {
  return (
    <aside className="toolrail" aria-label="Editing tools">
      <div className="rail-heading">TOOLS</div>
      {tools.map(tool => (
        <ActionIcon
          key={tool.id}
          title={`${tool.label} (${tool.shortcut})`}
          active={tool.id === state.tool}
          onClick={() => {
            state.setTool(tool.id);
            state.selectShape(null);
          }}
        >
          {tool.icon}
        </ActionIcon>
      ))}
      <div className="rail-spacer" />
      <ActionIcon title="Toggle grid" active={state.grid} onClick={() => state.setGrid(!state.grid)}>
        <GridOn />
      </ActionIcon>
      <ActionIcon title="Reset canvas position" onClick={() => { state.setZoom(1); state.setPan({ x: 0, y: 0 }); }}>
        <FlipToFront />
      </ActionIcon>
      <ActionIcon title="New document" onClick={openNew}>
        <Add />
      </ActionIcon>
    </aside>
  );
}

function ContextToolbar({ state }: { state: EditorStore }) {
  const entry = tools.find(tool => tool.id === state.tool);
  return (
    <div className="contextbar">
      <div className="tool-label">{entry?.icon}<strong>{entry?.label}</strong></div>
      <span className="context-divider" />
      <label className="field-label" htmlFor="spectrum-stroke">Stroke</label>
      <input id="spectrum-stroke" aria-label="Stroke color" type="color" value={state.color}
        onChange={event => state.setColor(event.target.value)} />
      <label className="field-label" htmlFor="spectrum-fill">Fill</label>
      <input id="spectrum-fill" aria-label="Fill color" type="color" value={state.fill}
        onChange={event => state.setFill(event.target.value)} />
      <span className="field-label">Size</span>
      <Slider aria-label="Brush or stroke size" size="small" value={state.strokeWidth}
        onChange={(_, value) => state.setStrokeWidth(value as number)} min={1} max={120} sx={{ width: 102 }} />
      <span className="value-chip">{state.strokeWidth}px</span>
      <span className="field-label">Opacity</span>
      <Slider aria-label="Brush opacity" size="small" value={state.opacity * 100}
        onChange={(_, value) => state.setOpacity((value as number) / 100)} min={1} max={100} sx={{ width: 83 }} />
      <span className="value-chip">{Math.round(state.opacity * 100)}%</span>
      <span className="context-grow" />
      <ActionIcon title="Zoom out" onClick={() => state.setZoom(state.zoom / 1.25)}><ZoomOut /></ActionIcon>
      <span className="zoom-value">{Math.round(state.zoom * 100)}%</span>
      <ActionIcon title="Zoom in" onClick={() => state.setZoom(state.zoom * 1.25)}><ZoomIn /></ActionIcon>
    </div>
  );
}

function DocumentTabs({ state, openNew }: { state: EditorStore; openNew: () => void }) {
  return (
    <div className="document-strip">
      <div className="document-tabs" role="tablist" aria-label="Open documents">
        {state.tabs.map(tab => (
          <div className={`doc-tab ${tab.doc.id === state.activeId ? 'active' : ''}`} key={tab.doc.id}>
            <button
              type="button"
              className="doc-tab-select"
              role="tab"
              aria-selected={tab.doc.id === state.activeId}
              onClick={() => state.activate(tab.doc.id)}
            >
              <Image sx={{ fontSize: 16 }} />
              <span>{tab.doc.name}{tab.dirty ? ' ●' : ''}</span>
            </button>
            <button
              type="button"
              className="tab-close"
              aria-label={`Close ${tab.doc.name}`}
              title={`Close ${tab.doc.name}`}
              onClick={() => {
                if (tab.dirty && !window.confirm('Close this document with unsaved changes?')) return;
                state.closeDoc(tab.doc.id);
              }}
            >
              <Close sx={{ fontSize: 14 }} />
            </button>
          </div>
        ))}
        <ActionIcon title="New document (Ctrl+N)" onClick={openNew}><Add fontSize="small" /></ActionIcon>
      </div>
      <span className="workspace-indicator"><AutoAwesome sx={{ fontSize: 14 }} /> Creative workspace</span>
    </div>
  );
}

type InspectorPanel = 'layers' | 'properties' | 'history';

function LayerOpacityControl({ state }: { state: EditorStore }) {
  const active = activeLayer(state);
  const [preview, setPreview] = useState(Math.round((active?.opacity ?? 1) * 100));

  useEffect(() => {
    setPreview(Math.round((active?.opacity ?? 1) * 100));
  }, [active?.id, active?.opacity]);

  return (
    <div className="properties-box">
      <label>Selected layer opacity <b>{preview}%</b></label>
      <Slider
        aria-label="Selected layer opacity"
        size="small"
        disabled={!active}
        value={preview}
        min={0}
        max={100}
        onChange={(_, value) => setPreview(value as number)}
        onChangeCommitted={(_, value) => {
          if (active) state.setLayerOpacity(active.id, (value as number) / 100);
        }}
      />
      <div className="small-note">Select a layer to edit it. Double-click its name to rename it.</div>
    </div>
  );
}

function Inspector({ state }: { state: EditorStore }) {
  const [panel, setPanel] = useState<InspectorPanel>('layers');
  const tab = activeTab(state);
  const doc = tab.doc;
  const layers = [...doc.layers].reverse();

  return (
    <aside className="inspector" aria-label="Document inspector">
      <div className="inspector-tabs">
        {(['layers', 'properties', 'history'] as const).map(key => (
          <button type="button" className={panel === key ? 'active' : ''} key={key}
            aria-pressed={panel === key} onClick={() => setPanel(key)}>
            {key === 'layers' ? <Layers /> : key === 'properties' ? <Settings /> : <History />}
            {key}
          </button>
        ))}
      </div>

      {panel === 'layers' && (
        <>
          <div className="panel-title"><span>Layers</span><span>{doc.layers.length}</span></div>
          <div className="layer-list">
            {layers.map(layer => (
              <div className={`layer-row ${doc.activeLayerId === layer.id ? 'active' : ''}`} key={layer.id}>
                <button type="button" title={layer.visible ? 'Hide layer' : 'Show layer'}
                  aria-label={`${layer.visible ? 'Hide' : 'Show'} ${layer.name}`}
                  onClick={() => state.toggleLayer(layer.id, 'visible')}>
                  {layer.visible ? <Visibility fontSize="small" /> : <VisibilityOff fontSize="small" />}
                </button>
                <div className={`layer-thumb ${layer.type}`}>
                  {layer.type === 'vector' ? <ShapeLine /> : <Image />}
                </div>
                <button type="button" className="layer-info" title="Click to select, double-click to rename"
                  aria-current={doc.activeLayerId === layer.id}
                  onClick={() => state.selectLayer(layer.id)}
                  onDoubleClick={() => {
                    const value = window.prompt('Rename layer', layer.name);
                    if (value?.trim()) state.renameLayer(layer.id, value);
                  }}>
                  <span>{layer.name}</span>
                  <small>{layer.type} · {Math.round(layer.opacity * 100)}%</small>
                </button>
                <button type="button" title="Lock / unlock" aria-label={`Toggle lock for ${layer.name}`}
                  onClick={() => state.toggleLayer(layer.id, 'locked')}>
                  {layer.locked ? <Lock fontSize="small" /> : <LockOpen fontSize="small" />}
                </button>
              </div>
            ))}
          </div>
          <div className="layer-buttons">
            <ActionIcon title="Add raster layer" onClick={() => state.addLayer('raster')}><Add /></ActionIcon>
            <ActionIcon title="Add vector layer" onClick={() => state.addLayer('vector')}><ShapeLine /></ActionIcon>
            <ActionIcon title="Duplicate layer" onClick={state.duplicateLayer}><ContentCopy /></ActionIcon>
            <ActionIcon title="Move layer up" onClick={() => { if (doc.activeLayerId) state.moveLayer(doc.activeLayerId, 1); }}>
              <ArrowUpward />
            </ActionIcon>
            <ActionIcon title="Move layer down" onClick={() => { if (doc.activeLayerId) state.moveLayer(doc.activeLayerId, -1); }}>
              <ArrowDownward />
            </ActionIcon>
            <ActionIcon title="Remove layer" disabled={doc.layers.length <= 1} onClick={state.removeLayer}><Delete /></ActionIcon>
          </div>
          <LayerOpacityControl state={state} />
        </>
      )}

      {panel === 'properties' && (
        <div className="properties-box">
          <h3>Document</h3>
          <div className="property-line">Name <strong>{doc.name}</strong></div>
          <div className="property-line">Dimensions <strong>{doc.width} × {doc.height}</strong></div>
          <div className="property-line">Background <strong>{doc.background}</strong></div>
          <div className="property-line">Layers <strong>{flattenLayers(doc.layers).length}</strong></div>
          <Divider sx={{ my: 2, borderColor: '#ffffff22' }} />
          <h3>Selected object</h3>
          {state.selectedShapeId ? (
            <>
              <p className="small-note">Vector object: {state.selectedShapeId.slice(0, 8)}</p>
              <Button size="small" startIcon={<Delete />} onClick={() => {
                if (!state.selectedShapeId) return;
                state.removeShape(state.selectedShapeId);
                state.selectShape(null);
              }}>Delete object</Button>
            </>
          ) : (
            <p className="small-note">Use Move to select a vector object; double-click text to edit it.</p>
          )}
        </div>
      )}

      {panel === 'history' && (
        <div className="properties-box">
          <h3>Undo history</h3>
          <div className="property-line">Undo steps <strong>{tab.past.length}</strong></div>
          <div className="property-line">Redo steps <strong>{tab.future.length}</strong></div>
          <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
            <Button variant="outlined" size="small" startIcon={<Undo />}
              onClick={state.undo} disabled={!tab.past.length}>Undo</Button>
            <Button variant="outlined" size="small" startIcon={<Redo />}
              onClick={state.redo} disabled={!tab.future.length}>Redo</Button>
          </Stack>
          <p className="small-note">Up to 40 document snapshots are retained in memory.</p>
        </div>
      )}

      <div className="inspector-bottom">
        <div className="help-card">
          <span className="help-icon">✦</span>
          <strong>Made for creativity</strong>
          <p>Professional tools. No subscription. No paywalls. Open source, forever.</p>
          <span><Favorite sx={{ fontSize: 13, color: '#ff9bb7' }} /> Spectrum community</span>
        </div>
      </div>
    </aside>
  );
}

export default function App() {
  const state = useEditor();
  const theme = useMemo(() => makeTheme(state.workspace), [state.workspace]);
  const tab = activeTab(state);
  const doc = tab.doc;
  const [newOpen, setNewOpen] = useState(false);
  const [name, setName] = useState('Untitled artwork');
  const [width, setWidth] = useState(1280);
  const [height, setHeight] = useState(800);
  const [background, setBackground] = useState('#ffffff');
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const [exportAnchor, setExportAnchor] = useState<HTMLElement | null>(null);
  const [notice, setNotice] = useState('Ready to create');

  function handleError(error: unknown): void {
    const message = error instanceof Error ? error.message : String(error);
    setNotice(`Error: ${message}`);
    window.alert(`Spectrum: ${message}`);
  }

  function guarded(operation: Promise<boolean>, message: string): void {
    void operation.then(completed => {
      if (completed) setNotice(message);
    }).catch(handleError);
  }

  useEffect(() => {
    function handleKey(event: KeyboardEvent): void {
      const target = event.target as HTMLElement | null;
      if (target && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName))) return;
      if (document.querySelector('[role="dialog"]')) return;
      const modifier = event.ctrlKey || event.metaKey;
      const key = event.key.toLowerCase();
      const current = useEditor.getState();

      if (modifier) {
        switch (key) {
          case 'n':
            event.preventDefault();
            setNewOpen(true);
            return;
          case 'o':
            event.preventDefault();
            guarded(openProject(), 'Project opened');
            return;
          case 's':
            event.preventDefault();
            guarded(saveProject(event.shiftKey), 'Project saved');
            return;
          case 'z':
            event.preventDefault();
            if (event.shiftKey) current.redo(); else current.undo();
            return;
          case 'y':
            event.preventDefault();
            current.redo();
            return;
          case 'd':
            event.preventDefault();
            current.duplicateLayer();
            return;
        }
        return;
      }

      if (key === 'delete' && current.selectedShapeId) {
        current.removeShape(current.selectedShapeId);
        current.selectShape(null);
      } else if (key === 'escape') {
        current.selectShape(null);
      } else {
        const found = tools.find(tool => tool.shortcut.toLowerCase() === key);
        if (found) current.setTool(found.id);
      }
    }

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    let mounted = true;
    void getRecovery().then(documents => {
      if (!mounted || documents.length === 0) return;
      if (window.confirm(`Spectrum found ${documents.length} recoverable document(s). Restore them?`)) {
        for (const recovered of documents) useEditor.getState().openDoc(recovered);
        setNotice(`${documents.length} document(s) recovered`);
      }
    }).catch(() => {
      // Private browsing can block IndexedDB. Editing remains available.
    });
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (state.showWelcome) return;
    const timer = window.setTimeout(() => {
      void storeRecovery(state.tabs.filter(item => item.dirty).map(item => item.doc)).catch(() => {
        setNotice('Recovery storage unavailable; save your project regularly.');
      });
    }, 4500);
    return () => window.clearTimeout(timer);
  }, [state.tabs, state.showWelcome]);

  function create(): void {
    if (!validSize(width, height)) {
      handleError(new Error('Canvas must be 1–16384 pixels per side and at most 64 million pixels.'));
      return;
    }
    state.newDoc(name, width, height, background);
    setNewOpen(false);
    setNotice('New canvas created');
  }

  const cycleTheme = (): void => {
    const next = state.workspace === 'glass' ? 'material' : state.workspace === 'material' ? 'classic' : 'glass';
    state.setWorkspace(next);
  };

  const fileCommands = [
    { name: 'New document', icon: <Add />, action: () => setNewOpen(true) },
    { name: 'Open project', icon: <FileOpen />, action: () => guarded(openProject(), 'Project opened') },
    { name: 'Import image', icon: <Image />, action: () => guarded(importImage(), 'Image imported') },
    { name: 'Save project', icon: <Save />, action: () => guarded(saveProject(), 'Project saved') },
    { name: 'Save project as…', icon: <Save />, action: () => guarded(saveProject(true), 'Project saved') },
    { name: 'Export PNG', icon: <Download />, action: () => guarded(exportImage('png'), 'PNG exported') },
    { name: 'Export SVG', icon: <ShapeLine />, action: () => guarded(exportSvg(), 'SVG exported') },
  ];

  return (
    <ThemeProvider theme={theme}>
      <div className={`app theme-${state.workspace}`}>
        <header className="titlebar">
          <div className="brand">
            <div className="brand-mark">✦</div>
            <span>Spectrum</span>
            <span className="badge">0.1</span>
          </div>
          <div className="title-actions">
            <Button size="small" startIcon={<MenuIcon />} onClick={event => setMenuAnchor(event.currentTarget)}>File</Button>
            <Button size="small" onClick={state.undo} startIcon={<Undo />} disabled={!tab.past.length}>Undo</Button>
            <Button size="small" onClick={state.redo} startIcon={<Redo />} disabled={!tab.future.length}>Redo</Button>
            <span className="title-sep" />
            <Button size="small" startIcon={<FileOpen />} onClick={() => guarded(openProject(), 'Project opened')}>Open</Button>
            <Button variant="contained" size="small" startIcon={<Save />}
              onClick={() => guarded(saveProject(), 'Project saved')}>Save</Button>
            <Button size="small" startIcon={<Download />}
              onClick={event => setExportAnchor(event.currentTarget)}>Export</Button>
          </div>
          <div className="title-right">
            <span className="live-dot" />
            <span>Free & open source</span>
            <ActionIcon title="Change appearance" onClick={cycleTheme}><Palette fontSize="small" /></ActionIcon>
          </div>
        </header>

        <DocumentTabs state={state} openNew={() => setNewOpen(true)} />
        <div className="editor-grid">
          <ToolRail state={state} openNew={() => setNewOpen(true)} />
          <main className="main-editor">
            <ContextToolbar state={state} />
            <Canvas onError={handleError} />
            <footer className="statusbar">
              <div><span className="status-led" />{notice}</div>
              <div>
                {doc.width} × {doc.height} px
                <span className="status-sep">|</span>{doc.layers.length} layers
                <span className="status-sep">|</span>{state.workspace} theme
                <span className="status-sep">|</span>Spectrum 0.1
              </div>
            </footer>
          </main>
          <Inspector state={state} />
        </div>

        {state.showWelcome && (
          <div className="welcome-scrim">
            <div className="welcome-card">
              <div className="welcome-logo">✦</div>
              <p className="eyebrow">A NEW SPACE FOR IDEAS</p>
              <h1>Create without<br /><em>limits.</em></h1>
              <p className="welcome-desc">
                Meet Spectrum. An open-source canvas for pixels, vectors, and everything in between.
                Entirely yours. Entirely free.
              </p>
              <Stack direction="row" spacing={1.5} justifyContent="center">
                <Button size="large" variant="contained" startIcon={<Add />}
                  onClick={() => setNewOpen(true)}>New document</Button>
                <Button size="large" variant="outlined" startIcon={<FolderOpen />}
                  onClick={() => guarded(openProject(), 'Project opened')}>Open project</Button>
              </Stack>
              <Button sx={{ mt: 1 }} size="small" startIcon={<PhotoCamera />}
                onClick={() => guarded(importImage(), 'Image imported')}>Import an image</Button>
              <div className="welcome-foot"><Code fontSize="small" /> Free & open source <span>·</span> Version 0.1</div>
            </div>
          </div>
        )}

        <Dialog open={newOpen} onClose={() => setNewOpen(false)} fullWidth maxWidth="xs">
          <DialogTitle>New document</DialogTitle>
          <DialogContent>
            <Stack spacing={2} sx={{ pt: 1 }}>
              <TextField label="Document name" value={name} onChange={event => setName(event.target.value)} />
              <Stack direction="row" spacing={2}>
                <TextField label="Width (px)" type="number" value={width}
                  onChange={event => setWidth(Number(event.target.value))} />
                <TextField label="Height (px)" type="number" value={height}
                  onChange={event => setHeight(Number(event.target.value))} />
              </Stack>
              <Typography variant="body2">Background</Typography>
              <Stack direction="row" spacing={1} alignItems="center">
                <Button variant={background === '#ffffff' ? 'contained' : 'outlined'} size="small"
                  onClick={() => setBackground('#ffffff')}>White</Button>
                <Button variant={background === 'transparent' ? 'contained' : 'outlined'} size="small"
                  onClick={() => setBackground('transparent')}>Transparent</Button>
                <input aria-label="Custom background" title="Custom background" type="color"
                  value={background === 'transparent' ? '#ffffff' : background}
                  onChange={event => setBackground(event.target.value)} />
              </Stack>
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setNewOpen(false)}>Cancel</Button>
            <Button variant="contained" onClick={create}>Create document</Button>
          </DialogActions>
        </Dialog>

        <Menu anchorEl={menuAnchor} open={Boolean(menuAnchor)} onClose={() => setMenuAnchor(null)}>
          {fileCommands.map(command => (
            <MenuItem key={command.name} onClick={() => { setMenuAnchor(null); command.action(); }}>
              <span className="menu-icon">{command.icon}</span>{command.name}
            </MenuItem>
          ))}
        </Menu>

        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)} onClose={() => setExportAnchor(null)}>
          {(['png', 'jpeg', 'webp', 'svg'] as const).map(format => (
            <MenuItem key={format} onClick={() => {
              setExportAnchor(null);
              guarded(format === 'svg' ? exportSvg() : exportImage(format), `${format.toUpperCase()} exported`);
            }}>
              <Download sx={{ mr: 1, fontSize: 18 }} />{format.toUpperCase()}
            </MenuItem>
          ))}
        </Menu>
      </div>
    </ThemeProvider>
  );
}
