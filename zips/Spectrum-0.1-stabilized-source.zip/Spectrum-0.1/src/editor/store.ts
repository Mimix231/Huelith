import { create } from 'zustand';
import {
  createDocument, layerById, makeRaster, makeVector, uid,
  type Document, type Layer, type Tool, type VectorShape, type Workspace, type Point,
} from './types';

const HISTORY_LIMIT = 40;
const clone = <T,>(value: T): T => structuredClone(value);

export interface EditorTab {
  doc: Document;
  past: Document[];
  future: Document[];
  dirty: boolean;
  path?: string;
  revision: number;
  savedRevision: number;
}

export interface EditorStore {
  tabs: EditorTab[];
  activeId: string;
  tool: Tool;
  color: string;
  fill: string;
  strokeWidth: number;
  opacity: number;
  zoom: number;
  pan: Point;
  workspace: Workspace;
  grid: boolean;
  showWelcome: boolean;
  selectedShapeId: string | null;
  setTool: (tool: Tool) => void;
  setColor: (color: string) => void;
  setFill: (fill: string) => void;
  setStrokeWidth: (width: number) => void;
  setOpacity: (opacity: number) => void;
  setZoom: (zoom: number) => void;
  setPan: (pan: Point) => void;
  setWorkspace: (workspace: Workspace) => void;
  setGrid: (grid: boolean) => void;
  setWelcome: (show: boolean) => void;
  selectShape: (id: string | null) => void;
  newDoc: (name?: string, width?: number, height?: number, background?: string) => void;
  openDoc: (doc: Document, path?: string) => void;
  closeDoc: (id: string) => void;
  activate: (id: string) => void;
  mutate: (edit: (doc: Document) => void) => void;
  undo: () => void;
  redo: () => void;
  markSaved: (id: string, revision: number, path?: string) => void;
  addLayer: (type: 'raster' | 'vector') => void;
  duplicateLayer: () => void;
  removeLayer: () => void;
  selectLayer: (id: string) => void;
  moveLayer: (id: string, step: number) => void;
  toggleLayer: (id: string, field: 'visible' | 'locked') => void;
  renameLayer: (id: string, name: string) => void;
  setLayerOpacity: (id: string, opacity: number) => void;
  addShape: (shape: VectorShape) => void;
  updateShape: (id: string, edit: (shape: VectorShape) => void) => void;
  removeShape: (id: string) => void;
}

function regenerateLayerIds(layer: Layer): void {
  layer.id = uid();
  if (layer.type === 'vector') {
    for (const shape of layer.shapes) shape.id = uid();
  }
  if (layer.type === 'group') {
    for (const child of layer.children) regenerateLayerIds(child);
  }
}

function tabFor(doc: Document, path?: string): EditorTab {
  return { doc, past: [], future: [], dirty: false, path, revision: 0, savedRevision: 0 };
}

const first = createDocument('Welcome canvas');

export const useEditor = create<EditorStore>((set, get) => ({
  tabs: [tabFor(first)],
  activeId: first.id,
  tool: 'brush',
  color: '#8e83ff',
  fill: '#8e83ff',
  strokeWidth: 12,
  opacity: 1,
  zoom: 0.8,
  pan: { x: 0, y: 0 },
  workspace: 'glass',
  grid: false,
  showWelcome: true,
  selectedShapeId: null,

  setTool: tool => set({ tool }),
  setColor: color => set({ color }),
  setFill: fill => set({ fill }),
  setStrokeWidth: strokeWidth => set({ strokeWidth: Math.max(1, Math.min(120, strokeWidth)) }),
  setOpacity: opacity => set({ opacity: Math.max(0, Math.min(1, opacity)) }),
  setZoom: zoom => set({ zoom: Math.max(0.05, Math.min(32, zoom)) }),
  setPan: pan => set({ pan }),
  setWorkspace: workspace => set({ workspace }),
  setGrid: grid => set({ grid }),
  setWelcome: showWelcome => set({ showWelcome }),
  selectShape: selectedShapeId => set({ selectedShapeId }),

  newDoc: (name, width, height, background) => {
    const doc = createDocument(name, width, height, background);
    set(state => ({
      tabs: [...state.tabs, tabFor(doc)], activeId: doc.id, showWelcome: false,
      pan: { x: 0, y: 0 }, selectedShapeId: null,
    }));
  },

  openDoc: (doc, path) => {
    const opened = clone(doc);
    // An already open copy must never share a tab identity with another document.
    opened.id = uid();
    set(state => ({
      tabs: [...state.tabs, tabFor(opened, path)], activeId: opened.id,
      showWelcome: false, pan: { x: 0, y: 0 }, selectedShapeId: null,
    }));
  },

  closeDoc: id => set(state => {
    const tabs = state.tabs.filter(tab => tab.doc.id !== id);
    if (tabs.length === 0) {
      const doc = createDocument();
      return { tabs: [tabFor(doc)], activeId: doc.id, showWelcome: true, selectedShapeId: null };
    }
    return {
      tabs,
      activeId: state.activeId === id ? tabs[tabs.length - 1].doc.id : state.activeId,
      selectedShapeId: null,
    };
  }),

  activate: activeId => set({ activeId, showWelcome: false, selectedShapeId: null }),

  mutate: edit => set(state => ({
    tabs: state.tabs.map(tab => {
      if (tab.doc.id !== state.activeId) return tab;
      const doc = clone(tab.doc);
      edit(doc);
      // Do not fill undo history with no-op clicks or edits to locked layers.
      if (JSON.stringify(doc) === JSON.stringify(tab.doc)) return tab;
      doc.updatedAt = new Date().toISOString();
      return {
        ...tab, doc, past: [...tab.past, tab.doc].slice(-HISTORY_LIMIT), future: [],
        dirty: true, revision: tab.revision + 1,
      };
    }),
  })),

  undo: () => set(state => ({
    tabs: state.tabs.map(tab => {
      if (tab.doc.id !== state.activeId || tab.past.length === 0) return tab;
      const doc = tab.past[tab.past.length - 1];
      return {
        ...tab, doc, past: tab.past.slice(0, -1), future: [tab.doc, ...tab.future],
        revision: tab.revision + 1, dirty: true,
      };
    }),
    selectedShapeId: null,
  })),

  redo: () => set(state => ({
    tabs: state.tabs.map(tab => {
      if (tab.doc.id !== state.activeId || tab.future.length === 0) return tab;
      const [doc, ...future] = tab.future;
      return {
        ...tab, doc, past: [...tab.past, tab.doc].slice(-HISTORY_LIMIT), future,
        revision: tab.revision + 1, dirty: true,
      };
    }),
    selectedShapeId: null,
  })),

  markSaved: (id, revision, path) => set(state => ({
    tabs: state.tabs.map(tab => tab.doc.id === id ? {
      ...tab, path: path ?? tab.path, savedRevision: revision,
      dirty: tab.revision !== revision,
    } : tab),
  })),

  addLayer: type => get().mutate(doc => {
    const layer = type === 'raster' ? makeRaster() : makeVector();
    doc.layers.push(layer);
    doc.activeLayerId = layer.id;
  }),

  duplicateLayer: () => get().mutate(doc => {
    const index = doc.layers.findIndex(layer => layer.id === doc.activeLayerId);
    if (index < 0) return;
    const duplicated = clone(doc.layers[index]);
    regenerateLayerIds(duplicated);
    duplicated.name += ' copy';
    doc.layers.splice(index + 1, 0, duplicated);
    doc.activeLayerId = duplicated.id;
  }),

  removeLayer: () => get().mutate(doc => {
    if (doc.layers.length <= 1) return;
    doc.layers = doc.layers.filter(layer => layer.id !== doc.activeLayerId);
    doc.activeLayerId = doc.layers.at(-1)?.id ?? null;
  }),

  selectLayer: id => set(state => ({
    tabs: state.tabs.map(tab => tab.doc.id === state.activeId ? {
      ...tab, doc: { ...tab.doc, activeLayerId: id },
    } : tab),
    selectedShapeId: null,
  })),

  moveLayer: (id, step) => get().mutate(doc => {
    const index = doc.layers.findIndex(layer => layer.id === id);
    const target = index + step;
    if (index < 0 || target < 0 || target >= doc.layers.length) return;
    [doc.layers[index], doc.layers[target]] = [doc.layers[target], doc.layers[index]];
  }),

  toggleLayer: (id, field) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer) layer[field] = !layer[field];
  }),

  renameLayer: (id, name) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer && name.trim()) layer.name = name.trim();
  }),

  setLayerOpacity: (id, opacity) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer) layer.opacity = Math.max(0, Math.min(1, opacity));
  }),

  addShape: shape => get().mutate(doc => {
    let layer = layerById(doc, doc.activeLayerId);
    if (layer?.type !== 'vector' || layer.locked || !layer.visible) {
      const fresh = makeVector();
      doc.layers.push(fresh);
      doc.activeLayerId = fresh.id;
      layer = fresh;
    }
    if (layer.type === 'vector') {
      layer.shapes.push({ ...shape, x: shape.x - layer.x, y: shape.y - layer.y,
        points: shape.points?.map(point => ({ x: point.x - layer.x, y: point.y - layer.y })) });
    }
  }),

  updateShape: (id, edit) => get().mutate(doc => {
    for (const layer of doc.layers) {
      if (layer.type !== 'vector' || layer.locked) continue;
      const shape = layer.shapes.find(item => item.id === id);
      if (shape) {
        edit(shape);
        break;
      }
    }
  }),

  removeShape: id => get().mutate(doc => {
    for (const layer of doc.layers) {
      if (layer.type === 'vector' && !layer.locked) {
        layer.shapes = layer.shapes.filter(shape => shape.id !== id);
      }
    }
  }),
}));

export function activeTab(state: EditorStore): EditorTab {
  return state.tabs.find(tab => tab.doc.id === state.activeId) ?? state.tabs[0];
}

export function activeLayer(state: EditorStore): Layer | undefined {
  const doc = activeTab(state).doc;
  return layerById(doc, doc.activeLayerId);
}
