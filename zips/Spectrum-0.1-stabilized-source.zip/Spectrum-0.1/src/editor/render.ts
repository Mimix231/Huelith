import type { Document, Layer, VectorShape } from './types';

interface CachedImage {
  image: HTMLImageElement;
  promise: Promise<HTMLImageElement>;
}

const cache = new Map<string, CachedImage>();
const CACHE_LIMIT = 16;

function imageEntry(source: string): CachedImage {
  const existing = cache.get(source);
  if (existing) return existing;

  const image = new Image();
  const promise = new Promise<HTMLImageElement>((resolve, reject) => {
    image.onload = () => resolve(image);
    image.onerror = () => {
      cache.delete(source);
      reject(new Error('An embedded image could not be decoded.'));
    };
  });
  // Rendering can be fire-and-forget; avoid unhandled rejections on invalid images.
  void promise.catch(() => {});
  const entry = { image, promise };
  cache.set(source, entry);
  image.src = source;

  while (cache.size > CACHE_LIMIT) {
    const oldest = cache.keys().next().value;
    if (oldest === undefined) break;
    cache.delete(oldest);
  }
  return entry;
}

export function loadImage(source: string, onReady?: () => void): HTMLImageElement | null {
  if (!source) return null;
  const entry = imageEntry(source);
  if (entry.image.complete && entry.image.naturalWidth > 0) return entry.image;
  if (onReady) void entry.promise.then(onReady).catch(() => onReady());
  return null;
}

export function decodeImage(source: string): Promise<HTMLImageElement | null> {
  return source ? imageEntry(source).promise : Promise.resolve(null);
}

export function drawShape(ctx: CanvasRenderingContext2D, shape: VectorShape, dx = 0, dy = 0): void {
  ctx.save();
  ctx.translate(dx, dy);
  ctx.beginPath();

  switch (shape.kind) {
    case 'rect':
      ctx.rect(shape.x, shape.y, shape.width, shape.height);
      break;
    case 'ellipse':
      ctx.ellipse(
        shape.x + shape.width / 2, shape.y + shape.height / 2,
        Math.max(0.01, Math.abs(shape.width / 2)), Math.max(0.01, Math.abs(shape.height / 2)),
        0, 0, Math.PI * 2,
      );
      break;
    case 'line':
      ctx.moveTo(shape.x, shape.y);
      ctx.lineTo(shape.x + shape.width, shape.y + shape.height);
      break;
    case 'path': {
      const points = shape.points ?? [];
      if (points[0]) ctx.moveTo(points[0].x, points[0].y);
      for (let index = 1; index < points.length; index++) ctx.lineTo(points[index].x, points[index].y);
      break;
    }
    case 'text': {
      const family = shape.fontFamily ?? 'Arial, sans-serif';
      ctx.font = `${shape.fontSize ?? 48}px ${family}`;
      ctx.textBaseline = 'top';
      if (shape.fill !== 'none') {
        ctx.fillStyle = shape.fill;
        ctx.fillText(shape.text ?? '', shape.x, shape.y);
      }
      if (shape.stroke !== 'none' && shape.strokeWidth > 0) {
        ctx.strokeStyle = shape.stroke;
        ctx.lineWidth = shape.strokeWidth;
        ctx.strokeText(shape.text ?? '', shape.x, shape.y);
      }
      ctx.restore();
      return;
    }
  }

  if (shape.fill !== 'none' && (shape.kind === 'rect' || shape.kind === 'ellipse')) {
    ctx.fillStyle = shape.fill;
    ctx.fill();
  }
  if (shape.stroke !== 'none' && shape.strokeWidth > 0) {
    ctx.strokeStyle = shape.stroke;
    ctx.lineWidth = shape.strokeWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  }
  ctx.restore();
}

export function renderLayer(ctx: CanvasRenderingContext2D, layer: Layer, onReady?: () => void): void {
  if (!layer.visible || layer.opacity <= 0) return;
  ctx.save();
  ctx.globalAlpha *= layer.opacity;
  ctx.globalCompositeOperation = layer.blend;

  if (layer.type === 'raster') {
    const image = loadImage(layer.image, onReady);
    if (image) ctx.drawImage(image, layer.x, layer.y);
  } else if (layer.type === 'vector') {
    for (const shape of layer.shapes) drawShape(ctx, shape, layer.x, layer.y);
  } else {
    ctx.translate(layer.x, layer.y);
    for (const child of layer.children) renderLayer(ctx, child, onReady);
  }
  ctx.restore();
}

/** Draw document pixels; `clear` is false when drawing on a prepainted checkerboard. */
export function drawDocument(ctx: CanvasRenderingContext2D, doc: Document, onReady?: () => void, clear = true): void {
  if (clear) ctx.clearRect(0, 0, doc.width, doc.height);
  if (doc.background !== 'transparent') {
    ctx.fillStyle = doc.background;
    ctx.fillRect(0, 0, doc.width, doc.height);
  }
  for (const layer of doc.layers) renderLayer(ctx, layer, onReady);
}

export function exportCanvas(doc: Document): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = doc.width;
  canvas.height = doc.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D is unavailable.');
  drawDocument(ctx, doc);
  return canvas;
}

export async function prepareImages(doc: Document): Promise<void> {
  const sources: string[] = [];
  const visit = (layers: Layer[]): void => {
    for (const layer of layers) {
      if (layer.type === 'raster' && layer.image) sources.push(layer.image);
      if (layer.type === 'group') visit(layer.children);
    }
  };
  visit(doc.layers);
  await Promise.all([...new Set(sources)].map(source => decodeImage(source)));
}

export function drawChecker(ctx: CanvasRenderingContext2D, width: number, height: number, tile = 16): void {
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = '#e5e7ed';
  for (let y = 0; y < height; y += tile) {
    for (let x = (Math.floor(y / tile) % 2) * tile; x < width; x += tile * 2) {
      ctx.fillRect(x, y, tile, tile);
    }
  }
}
