import type { Document, Layer, VectorShape } from './types';

const escapeXML = (value: string): string => value.replace(/&/g, '&amp;')
  .replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');

function shapeToSVG(shape: VectorShape): string {
  const common = `fill="${escapeXML(shape.fill)}" stroke="${escapeXML(shape.stroke)}" stroke-width="${shape.strokeWidth}"`;
  switch (shape.kind) {
    case 'rect':
      return `<rect x="${shape.x}" y="${shape.y}" width="${shape.width}" height="${shape.height}" ${common}/>`;
    case 'ellipse': {
      const centerX = shape.x + shape.width / 2;
      const centerY = shape.y + shape.height / 2;
      const radiusX = Math.abs(shape.width / 2);
      const radiusY = Math.abs(shape.height / 2);
      return `<ellipse cx="${centerX}" cy="${centerY}" rx="${radiusX}" ry="${radiusY}" ${common}/>`;
    }
    case 'line':
      return `<line x1="${shape.x}" y1="${shape.y}" x2="${shape.x + shape.width}" y2="${shape.y + shape.height}" ${common}/>`;
    case 'path':
      return `<polyline points="${(shape.points ?? []).map(point => `${point.x},${point.y}`).join(' ')}" ${common}/>`;
    case 'text': {
      const family = escapeXML(shape.fontFamily ?? 'Arial, sans-serif');
      const text = escapeXML(shape.text ?? '');
      const attributes = `x="${shape.x}" y="${shape.y}" font-size="${shape.fontSize ?? 48}"`;
      return `<text ${attributes} font-family="${family}" dominant-baseline="text-before-edge" ${common}>${text}</text>`;
    }
  }
}

function layerToSVG(layer: Layer, width: number, height: number): string {
  if (!layer.visible || layer.opacity <= 0) return '';
  const blend = layer.blend === 'source-over' ? '' : ` style="mix-blend-mode:${layer.blend}"`;
  const content = layer.type === 'raster'
    ? (layer.image
      ? `<image x="0" y="0" width="${layer.imageWidth ?? width}" height="${layer.imageHeight ?? height}" href="${escapeXML(layer.image)}"/>`
      : '')
    : layer.type === 'vector'
      ? layer.shapes.map(shapeToSVG).join('\n')
      : layer.children.map(child => layerToSVG(child, width, height)).join('\n');

  return `<g opacity="${layer.opacity}" transform="translate(${layer.x} ${layer.y})"${blend}>\n${content}\n</g>`;
}

/** SVG preserves vector shapes and embeds raster pixels. Fonts/blend modes depend on SVG viewers. */
export function documentToSVG(doc: Document): string {
  const output = [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${doc.width}" height="${doc.height}" viewBox="0 0 ${doc.width} ${doc.height}">`,
  ];
  if (doc.background !== 'transparent') {
    output.push(`<rect width="100%" height="100%" fill="${escapeXML(doc.background)}"/>`);
  }
  for (const layer of doc.layers) output.push(layerToSVG(layer, doc.width, doc.height));
  output.push('</svg>');
  return output.join('\n');
}
