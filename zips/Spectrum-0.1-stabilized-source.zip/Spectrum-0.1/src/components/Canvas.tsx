import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type MouseEvent as ReactMouseEvent } from 'react';
import { activeLayer, activeTab, useEditor } from '../editor/store';
import { decodeImage, drawChecker, drawShape, renderLayer } from '../editor/render';
import { uid, type Point, type VectorShape } from '../editor/types';
import './Canvas.css';

type Gesture =
  | { kind: 'pan'; start: Point; original: Point }
  | { kind: 'move'; start: Point; last: Point; layerId: string; shapeId: string | null }
  | { kind: 'shape'; start: Point; last: Point; shape: VectorShape }
  | { kind: 'loading'; start: Point; last: Point; layerId: string; erase: boolean; finish: boolean }
  | { kind: 'draw'; start: Point; last: Point; layerId: string; erase: boolean;
      canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D };

interface CanvasProps {
  onError?: (error: unknown) => void;
}

function hitShape(point: Point, shape: VectorShape, offset: Point): boolean {
  const tolerance = Math.max(5, shape.strokeWidth);
  const left = Math.min(shape.x, shape.x + shape.width) + offset.x - tolerance;
  const right = Math.max(shape.x, shape.x + shape.width) + offset.x + tolerance;
  const top = Math.min(shape.y, shape.y + shape.height) + offset.y - tolerance;
  const bottom = Math.max(shape.y, shape.y + shape.height) + offset.y + tolerance;
  return point.x >= left && point.x <= right && point.y >= top && point.y <= bottom;
}

export default function Canvas({ onError }: CanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const gesture = useRef<Gesture | null>(null);
  const [size, setSize] = useState({ width: 800, height: 600 });
  const [cursor, setCursor] = useState<Point | null>(null);
  const [draft, setDraft] = useState<VectorShape | null>(null);
  const [drawing, setDrawing] = useState<HTMLCanvasElement | null>(null);
  const [revision, setRevision] = useState(0);

  const doc = useEditor(state => activeTab(state).doc);
  const tool = useEditor(state => state.tool);
  const zoom = useEditor(state => state.zoom);
  const pan = useEditor(state => state.pan);
  const grid = useEditor(state => state.grid);
  const color = useEditor(state => state.color);
  const fill = useEditor(state => state.fill);
  const strokeWidth = useEditor(state => state.strokeWidth);
  const opacity = useEditor(state => state.opacity);
  const selectedShapeId = useEditor(state => state.selectedShapeId);

  useEffect(() => {
    if (!hostRef.current) return;
    const observer = new ResizeObserver(entries => {
      const rect = entries[0]?.contentRect;
      if (rect) {
        setSize({ width: Math.max(1, Math.floor(rect.width)), height: Math.max(1, Math.floor(rect.height)) });
      }
    });
    observer.observe(hostRef.current);
    return () => observer.disconnect();
  }, []);

  const position = useCallback((event: { clientX: number; clientY: number }): Point => {
    const bounds = canvasRef.current!.getBoundingClientRect();
    return {
      x: (event.clientX - bounds.left - bounds.width / 2 - pan.x) / zoom + doc.width / 2,
      y: (event.clientY - bounds.top - bounds.height / 2 - pan.y) / zoom + doc.height / 2,
    };
  }, [doc.height, doc.width, pan.x, pan.y, zoom]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    canvas.width = Math.round(size.width * dpr);
    canvas.height = Math.round(size.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size.width, size.height);
    ctx.translate(size.width / 2 + pan.x - doc.width * zoom / 2,
      size.height / 2 + pan.y - doc.height * zoom / 2);
    ctx.scale(zoom, zoom);

    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, .38)';
    ctx.shadowBlur = 28 / zoom;
    ctx.fillStyle = 'rgba(0, 0, 0, .15)';
    ctx.fillRect(0, 0, doc.width, doc.height);
    ctx.restore();

    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, doc.width, doc.height);
    ctx.clip();
    if (doc.background === 'transparent') {
      drawChecker(ctx, doc.width, doc.height);
    } else {
      ctx.fillStyle = doc.background;
      ctx.fillRect(0, 0, doc.width, doc.height);
    }

    const working = gesture.current?.kind === 'draw' ? gesture.current : null;
    for (const layer of doc.layers) {
      if (drawing && working && layer.id === working.layerId && layer.type === 'raster') {
        if (!layer.visible) continue;
        ctx.save();
        ctx.globalAlpha = layer.opacity;
        ctx.globalCompositeOperation = layer.blend;
        ctx.drawImage(drawing, layer.x, layer.y);
        ctx.restore();
      } else {
        renderLayer(ctx, layer, () => setRevision(value => value + 1));
      }
    }

    if (draft) drawShape(ctx, draft);
    if (grid && zoom >= 0.6) {
      ctx.strokeStyle = 'rgba(120, 128, 155, .2)';
      ctx.lineWidth = 1 / zoom;
      ctx.beginPath();
      for (let x = 0; x <= doc.width; x += 50) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, doc.height);
      }
      for (let y = 0; y <= doc.height; y += 50) {
        ctx.moveTo(0, y);
        ctx.lineTo(doc.width, y);
      }
      ctx.stroke();
    }
    ctx.restore();

    if (selectedShapeId) {
      for (const layer of doc.layers) {
        if (layer.type !== 'vector' || !layer.visible) continue;
        const shape = layer.shapes.find(item => item.id === selectedShapeId);
        if (!shape) continue;
        ctx.strokeStyle = '#a99dff';
        ctx.setLineDash([6 / zoom, 4 / zoom]);
        ctx.lineWidth = 2 / zoom;
        ctx.strokeRect(
          shape.x + layer.x - 4 / zoom, shape.y + layer.y - 4 / zoom,
          shape.width + 8 / zoom, shape.height + 8 / zoom,
        );
        ctx.setLineDash([]);
      }
    }
  }, [doc, size, zoom, pan, grid, draft, drawing, selectedShapeId, revision]);

  function commitDrawing(current: Extract<Gesture, { kind: 'draw' }>): void {
    const image = current.canvas.toDataURL('image/png');
    useEditor.getState().mutate(document => {
      const layer = document.layers.find(item => item.id === current.layerId);
      if (layer?.type === 'raster' && !layer.locked) {
        layer.image = image;
        layer.imageWidth = current.canvas.width;
        layer.imageHeight = current.canvas.height;
      }
    });
    if (gesture.current === current) gesture.current = null;
    setDrawing(null);
  }

  function stroke(current: Extract<Gesture, { kind: 'draw' }>, point: Point): void {
    const doc = activeTab(useEditor.getState()).doc;
    const layer = doc.layers.find(item => item.id === current.layerId);
    const x = layer?.x ?? 0;
    const y = layer?.y ?? 0;
    current.ctx.beginPath();
    current.ctx.moveTo(current.last.x - x, current.last.y - y);
    current.ctx.lineTo(point.x - x, point.y - y);
    current.ctx.stroke();
    current.last = point;
    setRevision(value => value + 1);
  }

  function startDrawing(start: Point, layerId: string, source: string, erase: boolean): void {
    const pending: Extract<Gesture, { kind: 'loading' }> = {
      kind: 'loading', start, last: start, layerId, erase, finish: false,
    };
    gesture.current = pending;

    void decodeImage(source).then(image => {
      if (gesture.current !== pending) return;
      const document = activeTab(useEditor.getState()).doc;
      const layer = document.layers.find(item => item.id === layerId);
      if (!layer || layer.type !== 'raster' || layer.locked) {
        gesture.current = null;
        return;
      }
      const working = window.document.createElement('canvas');
      working.width = document.width;
      working.height = document.height;
      const ctx = working.getContext('2d');
      if (!ctx) throw new Error('Canvas 2D is unavailable.');
      if (image) ctx.drawImage(image, 0, 0);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = strokeWidth;
      ctx.globalAlpha = opacity;
      ctx.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
      ctx.strokeStyle = erase ? '#000000' : color;

      const current: Extract<Gesture, { kind: 'draw' }> = {
        kind: 'draw', start, last: start, layerId, erase, canvas: working, ctx,
      };
      gesture.current = current;
      // Draw a dot for clicks as well as a line for actual drags.
      stroke(current, { x: start.x + 0.001, y: start.y + 0.001 });
      if (pending.last.x !== start.x || pending.last.y !== start.y) stroke(current, pending.last);
      setDrawing(working);
      if (pending.finish) commitDrawing(current);
    }).catch(error => {
      gesture.current = null;
      setDrawing(null);
      onError?.(error);
    });
  }

  function pointerDown(event: ReactPointerEvent<HTMLCanvasElement>): void {
    if (event.button !== 0 && event.button !== 1) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    const point = position(event);
    setCursor(point);
    const state = useEditor.getState();
    const layer = activeLayer(state);

    if (event.button === 1 || tool === 'hand' || event.altKey) {
      gesture.current = { kind: 'pan', start: { x: event.clientX, y: event.clientY }, original: { ...pan } };
      return;
    }

    if (tool === 'eyedropper') {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      const bounds = canvas?.getBoundingClientRect();
      if (!canvas || !ctx || !bounds) return;
      const x = Math.floor((event.clientX - bounds.left) * canvas.width / bounds.width);
      const y = Math.floor((event.clientY - bounds.top) * canvas.height / bounds.height);
      if (x < 0 || y < 0 || x >= canvas.width || y >= canvas.height) return;
      const sample = ctx.getImageData(x, y, 1, 1).data;
      state.setColor(`#${[...sample.slice(0, 3)].map(value => value.toString(16).padStart(2, '0')).join('')}`);
      return;
    }

    if (tool === 'move') {
      const shapes = doc.layers.filter(item => item.type === 'vector' && item.visible && !item.locked)
        .flatMap(item => item.type === 'vector' ? item.shapes.map(shape => ({ shape, layer: item })) : [])
        .reverse();
      const hit = shapes.find(({ shape, layer: shapeLayer }) => hitShape(point, shape, shapeLayer));
      if (hit) {
        state.selectLayer(hit.layer.id);
        state.selectShape(hit.shape.id);
        gesture.current = { kind: 'move', start: point, last: point, layerId: hit.layer.id, shapeId: hit.shape.id };
      } else if (layer && !layer.locked) {
        state.selectShape(null);
        gesture.current = { kind: 'move', start: point, last: point, layerId: layer.id, shapeId: null };
      }
      return;
    }

    if (tool === 'brush' || tool === 'eraser') {
      if (!layer || layer.locked || !layer.visible) return;
      if (layer.type !== 'raster') state.addLayer('raster');
      const target = activeLayer(useEditor.getState());
      if (target?.type === 'raster') startDrawing(point, target.id, target.image, tool === 'eraser');
      return;
    }

    if (tool === 'text') {
      const text = window.prompt('Text to add', 'Spectrum');
      if (!text) return;
      const fontSize = Math.max(16, strokeWidth * 3);
      const shape: VectorShape = {
        id: uid(), kind: 'text', x: point.x, y: point.y,
        width: Math.max(20, text.length * fontSize * 0.6), height: fontSize,
        fill: color, stroke: 'none', strokeWidth: 0, fontSize, text,
      };
      state.addShape(shape);
      state.selectShape(shape.id);
      return;
    }

    if (tool === 'rectangle' || tool === 'ellipse' || tool === 'line' || tool === 'pen') {
      const kind = tool === 'rectangle' ? 'rect' : tool === 'ellipse' ? 'ellipse' : tool === 'line' ? 'line' : 'path';
      const shape: VectorShape = {
        id: uid(), kind, x: point.x, y: point.y, width: 0, height: 0,
        fill: kind === 'rect' || kind === 'ellipse' ? fill : 'none',
        stroke: color, strokeWidth: Math.max(1, strokeWidth / 3),
        points: kind === 'path' ? [point] : undefined,
      };
      gesture.current = { kind: 'shape', start: point, last: point, shape };
      setDraft(shape);
    }
  }

  function pointerMove(event: ReactPointerEvent<HTMLCanvasElement>): void {
    const point = position(event);
    setCursor(point);
    const current = gesture.current;
    if (!current) return;

    if (current.kind === 'pan') {
      useEditor.getState().setPan({
        x: current.original.x + event.clientX - current.start.x,
        y: current.original.y + event.clientY - current.start.y,
      });
    } else if (current.kind === 'loading') {
      current.last = point;
    } else if (current.kind === 'draw') {
      stroke(current, point);
    } else if (current.kind === 'move') {
      current.last = point;
    } else if (current.kind === 'shape') {
      const shape = current.shape;
      if (shape.kind === 'path') {
        shape.points?.push(point);
        const points = shape.points ?? [];
        let minX = Infinity;
        let minY = Infinity;
        let maxX = -Infinity;
        let maxY = -Infinity;
        for (const item of points) {
          minX = Math.min(minX, item.x);
          minY = Math.min(minY, item.y);
          maxX = Math.max(maxX, item.x);
          maxY = Math.max(maxY, item.y);
        }
        shape.x = minX;
        shape.y = minY;
        shape.width = maxX - minX;
        shape.height = maxY - minY;
      } else if (shape.kind === 'line') {
        shape.width = point.x - current.start.x;
        shape.height = point.y - current.start.y;
      } else {
        shape.x = Math.min(current.start.x, point.x);
        shape.y = Math.min(current.start.y, point.y);
        shape.width = Math.abs(point.x - current.start.x);
        shape.height = Math.abs(point.y - current.start.y);
      }
      current.last = point;
      setDraft({ ...shape, points: shape.points ? [...shape.points] : undefined });
    }
  }

  function editText(event: ReactMouseEvent<HTMLCanvasElement>): void {
    if (tool !== 'move') return;
    const point = position(event);
    for (const layer of [...doc.layers].reverse()) {
      if (layer.type !== 'vector' || !layer.visible || layer.locked) continue;
      const shape = [...layer.shapes].reverse().find(item =>
        item.kind === 'text' && hitShape(point, item, layer));
      if (!shape) continue;
      const changed = window.prompt('Edit text', shape.text ?? '');
      if (changed === null) return;
      useEditor.getState().updateShape(shape.id, selected => {
        selected.text = changed;
        selected.width = Math.max(20, changed.length * (selected.fontSize ?? 48) * 0.6);
      });
      useEditor.getState().selectShape(shape.id);
      return;
    }
  }

  function pointerUp(): void {
    const current = gesture.current;
    if (!current) return;
    if (current.kind === 'loading') {
      current.finish = true;
      return;
    }
    gesture.current = null;

    if (current.kind === 'draw') {
      commitDrawing(current);
    } else if (current.kind === 'shape') {
      const shape = current.shape;
      const valid = shape.kind === 'path' ? (shape.points?.length ?? 0) > 1
        : Math.abs(shape.width) > 2 || Math.abs(shape.height) > 2;
      if (valid) {
        useEditor.getState().addShape(shape);
        useEditor.getState().selectShape(shape.id);
      }
      setDraft(null);
    } else if (current.kind === 'move') {
      const dx = current.last.x - current.start.x;
      const dy = current.last.y - current.start.y;
      if (dx === 0 && dy === 0) return;
      useEditor.getState().mutate(document => {
        const layer = document.layers.find(item => item.id === current.layerId);
        if (!layer || layer.locked) return;
        const shape = layer.type === 'vector'
          ? layer.shapes.find(item => item.id === current.shapeId) : undefined;
        if (shape) {
          shape.x += dx;
          shape.y += dy;
          if (shape.points) shape.points = shape.points.map(point => ({ x: point.x + dx, y: point.y + dy }));
        } else {
          layer.x += dx;
          layer.y += dy;
        }
      });
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    // A non-passive native handler prevents Ctrl+wheel from zooming the entire WebView.
    const handleWheel = (event: WheelEvent): void => {
      event.preventDefault();
      const state = useEditor.getState();
      if (event.ctrlKey || event.metaKey) {
        state.setZoom(state.zoom * Math.exp(-event.deltaY * 0.0015));
      } else if (event.shiftKey) {
        state.setPan({ x: state.pan.x - event.deltaY, y: state.pan.y });
      } else {
        state.setPan({ x: state.pan.x - event.deltaX, y: state.pan.y - event.deltaY });
      }
    };
    canvas.addEventListener('wheel', handleWheel, { passive: false });
    return () => canvas.removeEventListener('wheel', handleWheel);
  }, []);

  return (
    <div ref={hostRef} className="canvas-host">
      <canvas
        ref={canvasRef}
        className="artboard-canvas"
        aria-label="Spectrum artwork canvas"
        style={{ cursor: tool === 'hand' ? 'grab' : tool === 'move' ? 'move' : 'crosshair' }}
        onPointerDown={pointerDown}
        onPointerMove={pointerMove}
        onPointerUp={pointerUp}
        onPointerCancel={pointerUp}
        onDoubleClick={editText}
        onContextMenu={(event: { preventDefault: () => void }) => event.preventDefault()}
      />
      <div className="canvas-hint">
        {cursor ? `${Math.round(cursor.x)}, ${Math.round(cursor.y)}` : 'Move pointer onto canvas'}
        {' · '}{Math.round(zoom * 100)}%{' · '}{doc.width} × {doc.height}
      </div>
    </div>
  );
}
