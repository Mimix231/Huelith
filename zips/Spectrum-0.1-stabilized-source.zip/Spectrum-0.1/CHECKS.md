# Spectrum 0.1 — Verification record

This document distinguishes **tests actually run** from checks that require unavailable dependencies or a desktop environment. It does not claim a fully verified application.

## Ran successfully

- TypeScript source syntax parsing: **0 syntax errors** in all checked `.ts`/`.tsx` files.
- Local import path resolution: **passed**.
- Project/package/Tauri JSON parsing: **passed**.
- CSS brace sanity checks: **passed**.
- Browser Canvas2D rendering smoke test in headless Chromium: **5 pixel assertions passed** (transparent pixels, filled vector pixels, canvas background, raster data URL decoding and raster compositing).
- Editor-module strict TypeScript typecheck: **passed** for the model, store, rendering, SVG, recovery and file modules using temporary declarations of unavailable npm APIs. These are **not** a replacement for checking against actual installed library types.
- Additional strict TypeScript pass over **all TS/TSX application sources** using temporary React/MUI/Zustand/Tauri type shims: **passed**. Real npm typings remain unverified.
- `npm test`: **18 tests passed, 0 failed**. Tests cover document validation and limits, no-op history, undo/redo, layer creation/duplicate, ID uniqueness, save revision races, vector offsets, SVG escaping, SVG group handling, embedded image dimensions, source integrity and configuration validity.

## Not possible in this execution environment

- `npm install`: **blocked** because DNS access to `registry.npmjs.org` is unavailable and the npm cache is empty. `npm install --offline` failed with `ENOTCACHED`.
- `npm run check` / `npm run build` using **actual** React, MUI, Zustand, Vite and Tauri packages: **not completed**, because the dependencies could not be installed.
- Tauri Rust compilation: **not completed**, because `rustc` and `cargo` are not installed.
- Hands-on WebView/editor smoke testing: **not completed**, because no functioning frontend bundle could be built without npm dependencies.

## How to finish verification on your machine

```sh
npm install
npm run verify
npm run desktop:dev
```

Manually check: launch, new document, raster brush/eraser on existing artwork, add vector objects, move objects, hide/lock/reorder layers, undo/redo, Ctrl+wheel, `.spectrum` save and reopen, PNG/SVG export, recovery after unsaved changes, and the native file pickers.

**If `npm run verify` reports errors, Spectrum 0.1 still needs fixes; do not treat these checks as proof that all bugs are gone.**
