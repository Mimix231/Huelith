import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import type { RasterLayer } from '../editor/types';
import './CutoutWorkspace.css';

type MaskTool = 'keep' | 'remove' | 'eraser' | 'line' | 'lasso' | 'polygon' | 'rectangle' | 'ellipse' | 'hand';
type MaskView = 'original' | 'mask' | 'preview';
type P = { x: number; y: number };
const TOOLS: ReadonlyArray<[MaskTool, string, string]> = [
  ['keep','✎','Keep brush'], ['remove','⊖','Remove brush'], ['eraser','⌫','Erase selection'],
  ['line','╱','Line'], ['lasso','〰','Freehand lasso'], ['polygon','⬠','Polygon lasso'],
  ['rectangle','▭','Rectangle'], ['ellipse','◯','Ellipse'], ['hand','✋','Pan'],
];

/** A single alpha-refinement operation shared by preview and Process. */
export function refineCutoutMask(input: HTMLCanvasElement, feather: number, expand: number, smoothing: boolean): HTMLCanvasElement {
  if (feather <= 0 && expand === 0 && !smoothing) return input;
  const output = document.createElement('canvas'); output.width = input.width; output.height = input.height;
  const ctx = output.getContext('2d'); if (!ctx) return input;
  if (expand > 0) {
    const n = Math.abs(expand);
    for (let i = -n; i <= n; i += Math.max(1, Math.round(n / 4)))
      for (let j = -n; j <= n; j += Math.max(1, Math.round(n / 4))) ctx.drawImage(input, i, j);
  } else if (expand < 0) {
    const n = Math.abs(expand);
    ctx.drawImage(input, 0, 0);
    ctx.globalCompositeOperation = 'destination-in';
    for (const [dx, dy] of [[n, 0],[-n, 0],[0, n],[0, -n],[n * .707, n * .707],[-n * .707,-n * .707]])
      ctx.drawImage(input, dx, dy);
    ctx.globalCompositeOperation = 'source-over';
  } else ctx.drawImage(input, 0, 0);
  if (feather > 0 || smoothing) {
    const source = document.createElement('canvas'); source.width = input.width; source.height = input.height;
    source.getContext('2d')?.drawImage(output, 0, 0);
    ctx.clearRect(0, 0, output.width, output.height);
    ctx.filter = `blur(${Math.max(feather, smoothing ? 0.45 : 0)}px)`;
    ctx.drawImage(source, 0, 0); ctx.filter = 'none';
  }
  return output;
}

export default function CutoutWorkspace({ layer, onClose, onProcess }: {
  layer: RasterLayer;
  onClose: () => void;
  onProcess: (data: string, width: number, height: number) => void;
}) {
  const mask = useRef<HTMLCanvasElement | null>(null);
  const preview = useRef<HTMLCanvasElement | null>(null);
  const original = useRef<HTMLImageElement | null>(null);
  const viewport = useRef<HTMLDivElement | null>(null);
  const pointer = useRef<number | null>(null);
  const start = useRef<P | null>(null);
  const previous = useRef<P | null>(null);
  const freehand = useRef<P[]>([]);
  const polygon = useRef<P[]>([]);
  const undo = useRef<Array<{data:string;selected:boolean}>>([]);
  const [redo, setRedo] = useState<Array<{data:string;selected:boolean}>>([]);
  const [undoCount, setUndoCount] = useState(0);
  const [ready, setReady] = useState(false);
  const [hasSelection, setHasSelection] = useState(false);
  const [tool, setTool] = useState<MaskTool>('keep');
  const [view, setView] = useState<MaskView>('original');
  const [size, setSize] = useState(26);
  const [zoom, setZoom] = useState(1);
  const [feather, setFeather] = useState(0);
  const [expand, setExpand] = useState(0);
  const [smoothing, setSmoothing] = useState(false);
  const [operation, setOperation] = useState<'keep' | 'remove'>('keep');
  const [revision, setRevision] = useState(0);
  const [error, setError] = useState('');
  const [dimensions, setDimensions] = useState({ width: 1, height: 1 });

  useEffect(() => {
    let cancelled = false;
    const image = new Image();
    image.onload = () => {
      if (cancelled) return;
      if (!image.naturalWidth || !image.naturalHeight) { setError('The source image has no valid size.'); return; }
      if (image.naturalWidth * image.naturalHeight > 64_000_000) { setError('Images larger than 64 megapixels cannot be masked yet.'); return; }
      original.current = image;
      const native = document.createElement('canvas');
      native.width = image.naturalWidth; native.height = image.naturalHeight;
      mask.current = native;
      const setUp = () => {
        const w = image.naturalWidth, h = image.naturalHeight;
        const display = preview.current;
        if (!display) return;
        const ratio = Math.min(1, 1300 / Math.max(w, h));
        display.width = Math.max(1, Math.round(w * ratio));
        display.height = Math.max(1, Math.round(h * ratio));
        setDimensions({ width: w, height: h });
        setReady(true);
        setRevision(value => value + 1);
      };
      if (layer.cutoutMask?.data) {
        const stored = new Image();
        stored.onload = () => {
          if (cancelled) return;
          native.getContext('2d')?.drawImage(stored, 0, 0, native.width, native.height);
          setHasSelection(true);
          setUp();
        };
        stored.onerror = () => { if (!cancelled) { setError('The saved mask could not be decoded. Starting with an empty selection.'); setUp(); } };
        stored.src = layer.cutoutMask.data;
      } else setUp();
    };
    image.onerror = () => { if (!cancelled) setError('Unable to load the original image.'); };
    image.src = layer.image;
    return () => { cancelled = true; };
  }, [layer.id, layer.image, layer.cutoutMask?.data]);

  const repaint = useCallback(() => setRevision(n => n + 1), []);
  useEffect(() => {
    if (!ready || !mask.current || !original.current || !preview.current) return;
    const target = preview.current;
    const ctx = target.getContext('2d'); if (!ctx) return;
    const w = target.width, h = target.height;
    const matte = view === 'original' ? mask.current : refineCutoutMask(mask.current, feather, expand, smoothing);
    ctx.clearRect(0, 0, w, h);
    if (view === 'original') {
      ctx.drawImage(original.current, 0, 0, w, h);
      // Instruction overlay is visual only and never encoded into the mask.
      const tint = document.createElement('canvas');
      tint.width = w; tint.height = h;
      const overlay = tint.getContext('2d');
      if (overlay) {
        overlay.fillStyle = '#24d98d';overlay.fillRect(0, 0, w, h);
        overlay.globalCompositeOperation = 'destination-in';
        overlay.drawImage(mask.current, 0, 0, w, h);
        ctx.save();ctx.globalAlpha = .48;ctx.drawImage(tint, 0, 0);ctx.restore();
      }
    } else if (view === 'mask') {
      ctx.fillStyle = '#111827'; ctx.fillRect(0, 0, w, h);
      ctx.drawImage(matte, 0, 0, w, h);
    } else {
      ctx.drawImage(original.current, 0, 0, w, h);
      ctx.globalCompositeOperation = 'destination-in';
      ctx.drawImage(matte, 0, 0, w, h);
      ctx.globalCompositeOperation = 'source-over';
    }
    const scaleX = w / dimensions.width, scaleY = h / dimensions.height;
    ctx.save(); ctx.strokeStyle = operation === 'keep' ? '#42f7ab' : '#ff7398';
    ctx.lineWidth = 2;
    if (freehand.current.length > 1) {
      ctx.beginPath(); ctx.moveTo(freehand.current[0].x * scaleX, freehand.current[0].y * scaleY);
      for (const point of freehand.current.slice(1)) ctx.lineTo(point.x * scaleX, point.y * scaleY);
      if (tool === 'lasso') ctx.closePath();
      ctx.stroke();
    }
    if (polygon.current.length > 1) {
      ctx.beginPath(); ctx.moveTo(polygon.current[0].x * scaleX, polygon.current[0].y * scaleY);
      for (const point of polygon.current.slice(1)) ctx.lineTo(point.x * scaleX, point.y * scaleY);
      ctx.stroke();
    }
    ctx.restore();
    void revision;
  }, [ready, revision, view, tool, operation, dimensions, feather, expand, smoothing]);

  const pushHistory = (): void => {
    if (!mask.current) return;
    undo.current = [...undo.current.slice(-11), {data:mask.current.toDataURL('image/png'),selected:hasSelection}];
    setUndoCount(undo.current.length);
    setRedo([]);
  };
  const restore = (item: {data:string;selected:boolean}) => {
    const img = new Image();
    img.onload = () => {
      const ctx = mask.current?.getContext('2d'); if (!ctx || !mask.current) return;
      ctx.clearRect(0, 0, mask.current.width, mask.current.height);
      ctx.drawImage(img, 0, 0, mask.current.width, mask.current.height);
      setHasSelection(item.selected);repaint();
    };
    img.src = item.data;
  };
  const undoStep = () => {
    const item = undo.current.pop(); if (!item || !mask.current) return;
    setRedo(old => [...old, {data:mask.current!.toDataURL('image/png'),selected:hasSelection}]);
    setUndoCount(undo.current.length); restore(item);
  };
  const redoStep = () => {
    const item = redo.at(-1); if (!item || !mask.current) return;
    undo.current.push({data:mask.current.toDataURL('image/png'),selected:hasSelection});
    setUndoCount(undo.current.length);setRedo(old => old.slice(0, -1));restore(item);
  };
  const local = (event: ReactPointerEvent<HTMLCanvasElement>): P => {
    const box = event.currentTarget.getBoundingClientRect();
    return { x: Math.max(0, Math.min(dimensions.width, (event.clientX - box.left) / box.width * dimensions.width)),
      y: Math.max(0, Math.min(dimensions.height, (event.clientY - box.top) / box.height * dimensions.height)) };
  };
  const commitPath = (points: P[], kind: MaskTool) => {
    const ctx = mask.current?.getContext('2d'); if (!ctx || points.length < 1) return;
    ctx.save();
    ctx.globalCompositeOperation = (tool === 'eraser' || tool === 'remove' || operation === 'remove') ? 'destination-out' : 'source-over';
    ctx.strokeStyle = '#ffffff';ctx.fillStyle = '#ffffff';ctx.lineWidth = size;
    ctx.lineCap = 'round';ctx.lineJoin = 'round';
    const first = points[0], last = points[points.length - 1];
    if (kind === 'ellipse') {
      ctx.beginPath();ctx.ellipse((first.x + last.x) / 2, (first.y + last.y) / 2,
        Math.max(.5, Math.abs(last.x - first.x) / 2), Math.max(.5, Math.abs(last.y - first.y) / 2), 0, 0, Math.PI * 2);ctx.fill();
    } else if (kind === 'rectangle') {
      ctx.fillRect(Math.min(first.x, last.x), Math.min(first.y, last.y),Math.abs(last.x - first.x),Math.abs(last.y - first.y));
    } else {
      ctx.beginPath();ctx.moveTo(first.x, first.y);
      for (const p of points.slice(1)) ctx.lineTo(p.x, p.y);
      if (kind === 'polygon' || kind === 'lasso') { ctx.closePath();ctx.fill(); }
      else if (points.length === 1) { ctx.arc(first.x, first.y, size / 2, 0, Math.PI * 2);ctx.fill(); }
      else ctx.stroke();
    }
    ctx.restore();
    if (operation === 'keep' && tool !== 'eraser' && tool !== 'remove') setHasSelection(true);
    repaint();
  };
  const down = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!ready || !mask.current || event.button !== 0) return;
    if (tool === 'hand') {
      pointer.current = event.pointerId;start.current = {x:event.clientX, y:event.clientY};
      event.currentTarget.setPointerCapture(event.pointerId);return;
    }
    const p = local(event);
    if (tool === 'polygon') {
      if (!polygon.current.length) pushHistory();
      polygon.current.push(p);repaint();return;
    }
    pushHistory(); pointer.current = event.pointerId; start.current = previous.current = p; freehand.current = [p];
    event.currentTarget.setPointerCapture(event.pointerId);
    if (['keep','remove','eraser'].includes(tool)) commitPath([p], tool);
  };
  const move = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (pointer.current !== event.pointerId || !start.current) return;
    if (tool === 'hand') {
      const dx = event.clientX - start.current.x, dy = event.clientY - start.current.y;
      if (viewport.current) { viewport.current.scrollLeft -= dx;viewport.current.scrollTop -= dy; }
      start.current = {x:event.clientX,y:event.clientY}; return;
    }
    const p = local(event);
    if (['keep','remove','eraser'].includes(tool)) {
      commitPath([previous.current ?? p, p],tool);
      previous.current = p;
    } else {
      const points = freehand.current;
      if (tool === 'line' || tool === 'rectangle' || tool === 'ellipse') freehand.current = [start.current, p];
      else if (!points.length || Math.hypot(p.x - points[points.length - 1].x, p.y - points[points.length - 1].y) > 1) freehand.current.push(p);
      repaint();
    }
  };
  const finish = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (pointer.current !== event.pointerId) return;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    if (!['keep','remove','eraser','hand'].includes(tool) && freehand.current.length) commitPath(freehand.current, tool);
    pointer.current = null;start.current = null;previous.current = null;freehand.current = [];repaint();
  };
  const finishPolygon = () => {
    if (polygon.current.length >= 3) commitPath(polygon.current, 'polygon');
    polygon.current = []; repaint();
  };
  const clear = () => {
    if (!mask.current) return;
    pushHistory();mask.current.getContext('2d')?.clearRect(0, 0, mask.current.width, mask.current.height);
    setHasSelection(false);repaint();
  };
  const process = () => {
    const input = mask.current; if (!input || !hasSelection) return;
    const output = refineCutoutMask(input, feather, expand, smoothing);
    onProcess(output.toDataURL('image/png'), input.width, input.height);
  };
  return <div className="huelith-cutout-backdrop" role="presentation" onPointerDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className="huelith-cutout-dialog" role="dialog" aria-modal="true" aria-label="Huelith Cutout workspace"
      onKeyDown={event => { if (event.key === 'Escape') { if (polygon.current.length) {polygon.current=[];repaint();} else onClose(); }
        if (event.key === 'Enter' && tool === 'polygon') {finishPolygon();event.preventDefault();}
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { undoStep();event.preventDefault(); } }}>
      <header><strong>✂ Huelith Cutout</strong><span>Paint what you want to keep — no automatic guessing</span><button type="button" onClick={onClose} aria-label="Close Cutout">×</button></header>
      <div className="huelith-cutout-layout">
        <nav aria-label="Selection tools" className="huelith-cutout-tools">
          {TOOLS.map(([id, symbol, label]) => <button key={id} title={label} aria-label={label} type="button" aria-pressed={tool === id}
            onClick={() => {if (polygon.current.length) finishPolygon(); setTool(id); }}>{symbol}<small>{label}</small></button>)}
        </nav>
        <div ref={viewport} className="huelith-cutout-viewport" aria-label="Image and mask editor">
          <canvas ref={preview} className="huelith-cutout-canvas" style={{width:`${Math.round(Math.min(1300,dimensions.width)*zoom)}px`,maxWidth:'none',cursor:tool==='hand'?'grab':'crosshair'}}
            onPointerDown={down} onPointerMove={move} onPointerUp={finish} onPointerCancel={finish}
            onDoubleClick={event => { if (tool==='polygon') {event.preventDefault(); finishPolygon();} }} />
        </div>
        <aside className="huelith-cutout-options">
          <h3>Mask tools</h3>
          <label>Mark as <select value={operation} onChange={event => setOperation(event.target.value as 'keep'|'remove')}>
            <option value="keep">Keep subject</option><option value="remove">Remove region</option></select></label>
          <label>Brush / line size <output>{size}px</output><input aria-label="Selection brush size" type="range" min="1" max="240" value={size} onChange={event => setSize(+event.target.value)}/></label>
          <label>Zoom <output>{Math.round(zoom*100)}%</output><input aria-label="Cutout zoom" type="range" min="0.5" max="4" step="0.25" value={zoom} onChange={event => setZoom(+event.target.value)}/></label>
          <h3>Inspect</h3>
          <div className="huelith-cutout-view-modes">{(['original','mask','preview'] as const).map(option => <button key={option} aria-pressed={view===option} type="button" onClick={() => setView(option)}>{option}</button>)}</div>
          <h3>Refine edges</h3>
          <label>Feather <output>{feather}px</output><input aria-label="Mask feather" type="range" min="0" max="15" value={feather} onChange={event => setFeather(+event.target.value)}/></label>
          <label>Expand / Contract <output>{expand}px</output><input aria-label="Expand or contract mask" type="range" min="-8" max="8" value={expand} onChange={event => setExpand(+event.target.value)}/></label>
          <label className="huelith-cutout-checkbox"><input type="checkbox" checked={smoothing} onChange={event => setSmoothing(event.target.checked)}/> Anti-aliased edges</label>
          <p>Green = keep • Remove subtracts • Eraser clears selections. Double-click to close polygons.</p>
          <div className="huelith-cutout-actions"><button onClick={undoStep} disabled={undoCount===0}>↶ Undo</button><button onClick={redoStep} disabled={!redo.length}>↷ Redo</button><button onClick={clear}>Reset selection</button></div>
        </aside>
      </div>
      {error && <p role="alert" className="huelith-cutout-error">{error}</p>}
      <footer><span>{ready?`${dimensions.width} × ${dimensions.height} • non-destructive mask`:'Loading image…'}</span>
        <button type="button" onClick={onClose}>Cancel</button>
        <button type="button" className="primary" disabled={!ready || !hasSelection} onClick={process}>Process mask</button></footer>
    </section>
  </div>;
}
