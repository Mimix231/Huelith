import { useMemo, useState, type MouseEvent } from 'react';
import { Popover } from '@mui/material';
import { activeLayer, type EditorStore } from '../editor/store';
import { uid, type GradientMode, type GradientStop, type VectorShape } from '../editor/types';
import { GRADIENT_MODES } from '../editor/gradient';
import { GRADIENT_TRANSFORMS, type GradientTransform } from '../editor/gradient-transforms';
import StudioColorPicker from './StudioColorPicker';
import './GradientDesignerToolbar.css';

/** A compact contextual strip; choosing the Gradient tool never opens a blocking modal.
 * All selections remain native, editable vector layers with the exact same export renderer. */
export default function GradientDesignerToolbar({ state }: { state: EditorStore }) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const [tab, setTab] = useState('Radial');
  const [search, setSearch] = useState('');
  const [stopsAnchor, setStopsAnchor] = useState<HTMLElement | null>(null);
  const [saved, setSaved] = useState<Record<string, Partial<VectorShape>>>(() => {
    try { const stored: unknown = JSON.parse(localStorage.getItem('huelith-gradient-presets-v1') ?? '{}');
      return stored && typeof stored === 'object' && !Array.isArray(stored) ? stored as Record<string, Partial<VectorShape>> : {};
    } catch { return {}; }
  });
  const [presetName, setPresetName] = useState('');
  const layer = activeLayer(state);
  const shape = layer?.type === 'vector' ? layer.shapes.find(item => item.id === state.selectedShapeId && item.kind === 'gradient') : undefined;
  const props = shape ?? state.gradientSettings;
  const stops: GradientStop[] = props.gradientStops?.length ? props.gradientStops : [
    { id:'a', position:0, color:state.color, opacity:state.opacity },
    { id:'b', position:1, color:state.backgroundColor, opacity:state.backgroundOpacity },
  ];
  const patch = (changes: Partial<VectorShape>): void => {
    state.setGradientSettings(changes);
    if (shape) state.updateShape(shape.id, target => Object.assign(target, changes));
  };
  const patchStop = (id: string, changes: Partial<GradientStop>) => patch({gradientStops:stops.map(stop => stop.id === id ? {...stop, ...changes} : stop)});
  const selected = props.gradientTransform ?? 'none';
  const current = useMemo(() => GRADIENT_TRANSFORMS.find(item => item.id === selected) ?? GRADIENT_TRANSFORMS[0], [selected]);
  const categories = ['Core', 'Radial', 'Distort', 'Geometry', 'Light', 'Huelith'];
  const currentTab = categories.includes(current.category) ? current.category : 'Core';
  const slider = (key: keyof VectorShape, label: string, min: number, max: number, step: number, fallback: number) => (
    <label className="gd-slider" key={key}><span>{label}</span>
      <input type="range" aria-label={label} min={min} max={max} step={step} value={Number(props[key] ?? fallback)}
        onChange={event => patch({[key]:Number(event.target.value)})}/>
      <output>{Number(props[key] ?? fallback)}</output>
    </label>
  );
  function openTransforms(event: MouseEvent<HTMLButtonElement>) { setTab(currentTab); setAnchor(event.currentTarget); }
  const choose = (transform: GradientTransform) => patch({gradientTransform:transform, gradientTransformAmount:100});
  const activeMode = shape?.gradientMode ?? state.gradientMode;
  return <div className="contextbar huelith-gradient-strip" aria-label="Gradient designer controls">
    <div className="tool-label"><strong>◈ Gradient</strong></div>
    <span className="gd-separator" />
    <label>Type <select aria-label="Gradient type" value={activeMode} onChange={event => {
      const mode = event.target.value as GradientMode;
      state.setGradientMode(mode);
      if (shape) patch({gradientMode:mode});
    }}>{GRADIENT_MODES.map(mode => <option key={mode} value={mode}>{mode[0].toUpperCase()+mode.slice(1)}</option>)}</select></label>
    <StudioColorPicker value={stops[0].color} label="First gradient color" onChange={color => patchStop(stops[0].id, {color})}/>
    <span className="gd-direction">→</span>
    <StudioColorPicker value={stops[stops.length-1].color} label="Last gradient color" onChange={color => patchStop(stops[stops.length-1].id, {color})}/>
    <button className={stopsAnchor?'gd-active':''} onClick={event => setStopsAnchor(event.currentTarget)} aria-expanded={Boolean(stopsAnchor)} aria-label="Gradient color stops">Stops ▾</button>
    <button className={selected!=='none'?'gd-active':''} onClick={openTransforms} aria-label="Transform gradient" aria-expanded={Boolean(anchor)}>✦ Transform: {current.name} ▾</button>
    <button title="Reverse gradient colors" onClick={() => patch({gradientReverse: !props.gradientReverse})}>⇄ Reverse</button>
    <button title="Reset transformation while retaining colors" onClick={() => patch({gradientTransform:'none',gradientPattern:'smooth',gradientTransformAmount:100})}>↺ Reset</button>
    <span className="gd-help">Drag on canvas to draw · Drag endpoints to edit</span>
    <div className="gd-zoom"><button onClick={() => state.setZoom(state.zoom / 1.2)} aria-label="Zoom out">−</button><span>{Math.round(state.zoom*100)}%</span><button aria-label="Zoom in" onClick={() => state.setZoom(state.zoom * 1.2)}>+</button></div>
    <Popover open={Boolean(stopsAnchor)} anchorEl={stopsAnchor} onClose={()=>setStopsAnchor(null)} anchorOrigin={{vertical:'bottom',horizontal:'left'}}>
      <div className="gd-stops-panel" aria-label="Edit gradient stops">
      <div className="gd-panel-heading"><b>Color stops</b><button aria-label="Close gradient stops" onClick={()=>setStopsAnchor(null)}>×</button></div>
      {stops.map(stop => <div key={stop.id} className="gd-stop-row"><StudioColorPicker label="Stop color" value={stop.color} onChange={color=>patchStop(stop.id,{color})}/>
        <input type="range" aria-label="Stop position" min={0} max={100} value={Math.round(stop.position*100)} onChange={event=>patchStop(stop.id,{position:Number(event.target.value)/100})}/>
        <output>{Math.round(stop.position*100)}%</output><button disabled={stops.length<=2} onClick={()=>patch({gradientStops:stops.filter(item=>item.id!==stop.id)})} aria-label="Remove stop">×</button></div>)}
      <button disabled={stops.length>=32} onClick={()=>patch({gradientStops:[...stops,{id:uid(),position:.5,color:state.color,opacity:1}].sort((a,b)=>a.position-b.position)})}>+ Add stop</button>
      <p>Existing gradient layers keep their stops, opacity, and original pixels.</p>
      </div>
    </Popover>
    <Popover open={Boolean(anchor)} anchorEl={anchor} onClose={()=>setAnchor(null)} anchorOrigin={{vertical:'bottom',horizontal:'left'}}
      transformOrigin={{vertical:'top',horizontal:'left'}}>
      <div className="gd-transform-popover" aria-label="Huelith gradient transformations">
        <header><strong>Huelith · Gradient Transform</strong><button onClick={()=>setAnchor(null)} aria-label="Close transformations">×</button></header>
        <p>Shape and distort a live gradient. Each recipe uses its own procedural geometry.</p>
        <input value={search} onChange={event=>setSearch(event.target.value)} placeholder="Search transformations…" aria-label="Find gradient transformation" />
        <nav aria-label="Transformation categories">{categories.map(category=><button key={category} className={tab===category?'gd-active':''} onClick={()=>setTab(category)}>{category}</button>)}</nav>
        <div className="gd-transform-grid">{GRADIENT_TRANSFORMS.filter(item => (tab===item.category || Boolean(search)) && (!search || (item.name+' '+item.description).toLowerCase().includes(search.toLowerCase()))).map(item => <button key={item.id}
          className={selected===item.id?'gd-active':''} title={item.description} onClick={()=>{choose(item.id);setTab(item.category)}}>
          <strong>{item.name}</strong><small>{item.description}</small></button>)}</div>
        <div className="gd-options">
          <strong>{current.name} · Parameters</strong>
          {selected!=='none' && <>
            {slider('gradientTransformAmount','Amount',0,100,1,100)}
            {slider('gradientTransformFrequency','Frequency',.25,16,.25,2)}
            {slider('gradientTransformCount','Elements',2,180,1,14)}
            {slider('gradientTransformPhase','Phase',-100,100,1,0)}
            {slider('gradientTransformSeed','Variation seed',0,999,1,12)}
          </>}
          {slider('gradientCenterX','Center X',0,1,.01,.5)}
          {slider('gradientCenterY','Center Y',0,1,.01,.5)}
          <div className="gd-presets"><input value={presetName} onChange={event=>setPresetName(event.target.value)} placeholder="Name this gradient" maxLength={42} aria-label="Gradient preset name"/>
            <button disabled={!presetName.trim()} onClick={()=>{
              const name=presetName.trim();const next={...saved,[name]:{
                gradientMode:activeMode,gradientTransform:selected,gradientStops:stops.map(stop=>({...stop})),
                gradientTransformAmount:props.gradientTransformAmount,gradientTransformFrequency:props.gradientTransformFrequency,
                gradientTransformCount:props.gradientTransformCount,gradientTransformPhase:props.gradientTransformPhase,
                gradientTransformSeed:props.gradientTransformSeed,gradientCenterX:props.gradientCenterX,gradientCenterY:props.gradientCenterY,
              }};setSaved(next);try{localStorage.setItem('huelith-gradient-presets-v1',JSON.stringify(next));}catch{/* optional */}
            }}>Save</button>
            <select aria-label="Load gradient preset" value="" onChange={event=>{
              const next=saved[event.target.value];if(!next) return;
              if(next.gradientMode)state.setGradientMode(next.gradientMode);
              patch(next);
            }}><option value="">Saved gradients…</option>{Object.keys(saved).map(name=><option key={name} value={name}>{name}</option>)}</select>
          </div>
        </div>
      </div>
    </Popover>
  </div>;
}
