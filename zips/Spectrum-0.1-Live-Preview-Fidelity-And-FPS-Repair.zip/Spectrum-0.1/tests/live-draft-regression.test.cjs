const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const root=path.resolve(__dirname,'..');
const text=rel=>fs.readFileSync(path.join(root,rel),'utf8');
function compile(rel){
  const code=ts.transpileModule(text(rel),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
  const module={exports:{}};
  new Function('module','exports','require',code)(module,module.exports,()=>({}));
  return module.exports;
}
const quality=compile('src/editor/preview-quality.ts');
const draft=compile('src/editor/live-gpu-effects.ts');
const kinds=[...text('src/editor/effect-catalog.ts').matchAll(/kind:\s*'([^']+)'/g)].map(m=>m[1]);
const native=new Set(['brightness','contrast','saturate','hue','grayscale','sepia','invert']);

test('all 87 registered effects have a live draft or exact native color preview',()=>{
  assert.equal(kinds.length,87);
  for(const kind of kinds){
    if(native.has(kind))continue;
    assert.equal(draft.gpuPreviewSupport([{id:'a',kind,amount:50,enabled:true}]),true,kind);
  }
});

test('multiple effects can be represented as a GPU stack, 5+ limit protects frame time',()=>{
  const effects=kinds.slice(7,11).filter(kind=>!native.has(kind)).map((kind,i)=>({id:String(i),kind,amount:50,enabled:true}));
  assert.equal(draft.gpuPreviewSupport(effects),true);
  assert.equal(draft.gpuPreviewSupport(Array.from({length:5},(_,i)=>({id:String(i),kind:'glow',amount:50,enabled:true}))),false);
});

test('editing source is pinned rather than evicted on every live frame',()=>{
  quality.setInteractiveEffectPreview(true,'active');
  assert.equal(quality.previewCacheVictim(['active','layer-a','layer-b']),'layer-a');
  assert.equal(quality.previewCacheVictim(['active']),undefined);
  quality.setInteractiveEffectPreview(false);
  assert.equal(quality.previewCacheVictim(['active','layer-a']),'active');
});

test('Canvas2D drafts follow the *edited* effect in a multi-effect stack',()=>{
  const source={};
  const fx=(a,b)=>[
    {id:'earlier',kind:'glow',amount:a,enabled:true},
    {id:'later',kind:'vignette',amount:b,enabled:true},
  ];
  assert.equal(draft.changedDraftEffect(source,fx(10,20)).id,'later');
  assert.equal(draft.changedDraftEffect(source,fx(70,20)).id,'earlier');
  assert.equal(draft.changedDraftEffect(source,fx(70,65)).id,'later');
});

test('native resolution never decreases due to Studio interaction',()=>{
  assert.equal(quality.effectPreviewScale(3840,2160,'active',true),1);
  assert.equal(quality.effectPreviewScale(1920,1080,'active',true),1);
});

test('render path draws provisional previews only during editing, not exporting',()=>{
  const fx=text('src/editor/fx.ts');
  assert.match(fx,/onReady && isLiveEffectDragging\(layer\.id\)/);
  assert.match(fx,/const processed = processEffects\(source, effects\)/);
  assert.match(fx,/previewCacheVictim\(sourceCache\.keys\(\)\)/);
  assert.match(fx,/previewCacheVictim\(livePreviewHosts\.keys\(\)\)/);
});

test('transparent canvas checkerboard uses a reusable pattern, not 32000 draw calls',()=>{
  const render=text('src/editor/render.ts');
  assert.match(render,/checkerPatterns = new WeakMap/);
  assert.match(render,/ctx\.createPattern\(surface, 'repeat'\)/);
  assert.match(render,/brush\.fillRect\(0, 0, tile, tile\)/);
});
