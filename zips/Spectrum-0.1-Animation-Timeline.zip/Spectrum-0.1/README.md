# Spectrum 0.1 🌈

**Create without limits.** Spectrum is an experimental, GPL-3.0-or-later, **completely free and open-source** raster and vector image editor. The application is built with **Tauri 2**, **React 19**, **TypeScript**, **Material UI 7**, and **Zustand 5**.

There are no subscriptions, accounts, paid features, telemetry, trial limits, or cancellation fees. Supporting the development via optional donations is compatible with this philosophy, but no donation flow is built into the editor.

> **Development status: Spectrum 0.1 — stabilization.** The project is usable source code with tested document and Canvas2D logic. It is **not verified as a finished desktop release** because this environment cannot download npm dependencies or compile the Rust Tauri component. Always run `npm run verify` and test the actual application before shipping it to users.

## Start the editor

Requirements: **Node.js 22+**, npm, and (for desktop builds) a supported Rust toolchain with the [Tauri 2 OS prerequisites](https://v2.tauri.app/start/prerequisites/).

```bash
npm install
npm run verify
npm run dev
```

Open `http://127.0.0.1:1420` in a browser. The editor supports browser downloads for file export and `.spectrum` projects.

For a native desktop window:

```bash
npm run desktop:dev
```

For a native executable/installer:

```bash
npm run desktop:build
```

The source archive does **not** contain a prebuilt Windows executable. Dependency versions are declared in `package.json` but no lockfile could be generated in the build environment because npm registry DNS was unavailable. Generate a lockfile with `npm install` before making reproducible releases.

## Compact workspace and appearance

Spectrum 0.1 uses a space-conscious titlebar, 29px document strip, 34px contextual toolbar, 39px tool rail, resizable inspector, and a 20px status bar. These are compact desktop-oriented controls, not oversized cards. The inspector is split into **Layers, Properties, and History**. The **Spectrum FX** launcher sits directly **below the layers list and above the layer action icons**, matching the location marked in the user-provided screenshot.

The launcher opens a floating, searchable **Spectrum FX Studio** with three tabs:

- **Filters:** Searchable lighting, color, blur, outline, distortion and stylization filters.
- **Customize:** Contextual layer blend mode and opacity; fill, stroke, and width when a vector shape is selected; rectangular-mask actions.
- **FX:** Ten creative effect-stack presets and an editable applied-effects list. Toggle, reorder, change intensity/color and remove effects. Hold **Compare** to bypass layer FX temporarily without modifying saved artwork.

The palette button opens an organized dropdown with an independent **Light / Dark** toggle and **13 themes**. Each theme has its **own CSS file**, including unique backgrounds, panel treatments, corner shapes, and selection behavior; light and dark have separate palettes.

| Theme | CSS file | Distinct design language |
| --- | --- | --- |
| Strawberry | `strawberry.css` | Berry-cream surfaces, petal-shaped selections, gentle glossy highlights |
| Melon | `melon.css` | Cool mint/jade panels, botanical detailing, clean soft outlines |
| Peach | `peach.css` | Warm coral/cream panels and pill-like highlights |
| Lemon | `lemon.css` | Bright citrus details, graphic crispness, light stippling |
| Mango | `mango.css` | Warm golden-orange character with punchier highlights |
| Sakura | `sakura.css` | Soft petal pink, delicate outlines, restrained Japanese-inspired geometry |
| Blossom | `blossom.css` | Lavender botanical surfaces, flowing softer shapes |
| Shadow | `shadow.css` | Graphite and ink, low-glare precision, angular controls |
| Glass | `glass.css` | Translucent panes, backdrop blur and soft lighting |
| Material | `material.css` | Rounded tonal controls, expressive pill-shaped selections |
| Classic Desktop | `classic.css` | Tight square buttons and clear traditional separators |
| Midnight | `midnight.css` | Minimal darkroom chrome, subdued highlights |
| Studio | `studio.css` | Industrial precision, thin outlines and utility grid |

Theme files are in `src/styles/`; `app.css` contains the shared editor geometry and `polish.css` contains shared compact components and FX Studio layout. Themes change **UI chrome only**, never the pixels/colors of your artwork. The selected theme, light/dark mode, shortcut overrides, inspector width and panel visibility persist locally.

Document tabs can be reordered by dragging or **Alt+Left/Right** when focused. Double-click a document tab to rename it; right-click for Rename, Duplicate and Close Others. A dot denotes unsaved changes. The inspector is resizable and can be hidden in Focus Mode.

## Features in Spectrum 0.1

### Documents

- Create, switch, close and save multiple documents; support transparent backgrounds.
- Import PNG, JPEG, WebP, GIF and BMP; export PNG, JPEG, WebP and SVG.
- Open/save `.spectrum` projects, preserving editable raster/vector layers, masks and transforms.
- Dirty-document warnings, undo/redo, and recovery snapshots via IndexedDB where supported.

### Raster editing

- Brush and eraser with adjustable size, hardness, opacity and smoothing.
- Pointer-pressure response from compatible pen devices; mouse uses constant pressure.
- Non-destructive rectangular marquee selection restricts painting/erasing.
- Raster layers can be moved, resized, rotated, masked, hidden, locked and blended.
- For now, **painting onto a rotated/scaled raster layer is disabled** to avoid silently damaging data. Paint onto a new raster layer instead.

### Vector editing

- Rectangles, ellipses, lines, editable text and freehand vector paths.
- Freehand vector strokes become cubic Bézier paths with anchor and control points.
- Node editing via **A**: select an existing vector path, then drag anchors or either curve handle.
- Move, resize and rotate selected objects; property inspector edits coordinates and transforms.
- Export SVG with actual cubic path commands, editable text, layered groups, and embedded raster images.
- Text creation/changes use an inline editor on the canvas rather than blocking browser prompt dialogs.

### Layers and panels

- Add raster/vector layers, rename inline, duplicate, reorder, hide, lock and delete.
- Six layer compositing modes: Normal, Multiply, Screen, Overlay, Darken and Lighten.
- Adjustable opacity and non-destructive **rectangular** clipping masks made from marquee selections.
- Resizable layer/properties/history inspector and compact left tool rail.
- Editing history caps the **past** to 40 snapshots and approximately 48 MiB; recent history may be shorter on large projects.

## Keyboard shortcuts

| Action | Key |
| --- | --- |
| New / Open / Save / Save As | Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+Shift+S |
| Undo / Redo | Ctrl+Z / Ctrl+Shift+Z or Ctrl+Y |
| Duplicate current layer | Ctrl+D |
| Select all / deselect | Ctrl+A / Ctrl+Shift+A or Escape |
| Move / Bezier nodes / Marquee | V / A / M |
| Pan / Brush / Eraser / Eyedropper | H / B / E / I |
| Rectangle / Ellipse / Line / Precision Pen / Freehand path | R / O / L / P / F |
| Editable text | T |
| Delete selected vector object | Delete |
| Pan / Zoom | Mouse wheel / Ctrl+Mouse wheel |
| Middle mouse pan | Middle-click drag |
| Focus Mode | Tab when canvas is focused; exit using on-canvas button |

On macOS, Command works for Ctrl-based shortcuts. Enter inserts a newline in text; Ctrl+Enter commits the text editor and Escape cancels it. For the Precision Pen, Enter commits the path, Backspace removes the last node, and Escape cancels.

## Running checks

The project includes both logic-level regression tests and an **optional Chromium pixel test**:

```bash
npm run check         # Strict TypeScript using your installed dependencies
npm test              # Node source and editor behavior tests
npm run build         # TypeScript + Vite production build
npm run verify        # All three above
npm run test:browser  # Chromium Canvas2D assertions (optional; requires Python Playwright + Chromium)
```

`npm run test:browser` requires Python with `playwright` and Chromium. It uses `/usr/bin/chromium` when available, otherwise the Chromium installed with Playwright; `CHROMIUM_PATH` can override the executable. Its checks cover actual Canvas2D pixels **and computed CSS for all 13 theme families, including new light/dark variations**. GitHub Actions also defines dedicated frontend, Chromium, and Windows Rust checks (these run when the project is pushed to a repository).

**Read [`CHECKS.md`](CHECKS.md) for the exact commands and results from this source build.** `ACCEPTANCE.md` contains the end-to-end manual checklist to complete in a full Tauri build.

## Architecture

```text
src/
  App.tsx                Workspace shell, contextual tools, layers and panels
  main.tsx               React entry point
  styles/
    app.css              Shared geometry and accessibility
    glass.css            Frosted glass interface
    material.css         Material You-style light interface
    classic.css          Traditional dense desktop interface
  components/
    Canvas.tsx           Interactions, live transforms, editable text
    Canvas.css           Canvas overlays
  editor/
    types.ts             Validated document format (version 1)
    geometry.ts          Bézier smoothing and editable path geometry
    operations.ts        Non-mutating drag/transform previews and commits
    brush.ts             Soft/hard dab rendering and alpha erasure
    store.ts             Document tabs, undo/redo, layer actions, workspace state
    render.ts            Canvas2D renderer and image decoding/cache
    svg.ts               SVG exporter and escaping
    files.ts             Tauri/browser file operations
    recovery.ts          IndexedDB emergency recovery
src-tauri/               Rust app shell and native configuration
tests/                   Regression tests and optional Chromium pixel tests
```

## Honest current limits

Spectrum 0.1 is not yet at Photoshop/Affinity/Illustrator feature parity. In particular:

- The renderer is **Canvas2D**, not a GPU/tile-based compositor. Very large canvases may still consume considerable memory or export slowly.
- Selections and masks are currently **rectangular only**; there are no feathered, freeform, gradient or per-pixel alpha masks.
- Bézier paths have editable anchors/handles, but do not yet support full CAD-like path operations, joins, boolean operations, or advanced snapping.
- Moving/transforming a layer works; nested group interaction and multi-object selection are not yet polished.
- Pressure support depends on hardware/browser pointer events; this is not a full brush preset engine.
- Undo retains immutable full-document snapshots under a memory budget, not a true command/tile-delta history.
- Advanced PSD/RAW workflows, ICC/HDR color management, non-destructive adjustment layers and GPU filters are not implemented.
- The native Tauri build and MUI runtime have **not been launched** in this creation environment. The source has passed logic tests and a strict check using temporary dependency stand-ins; a real dependency-based build remains mandatory.

If any desktop build, native file operation or UI interaction fails in real use, **Spectrum remains 0.1** until the defect is fixed and a regression test is added.

---

## October 17: Compact Creative Studio stabilization (still Spectrum 0.1)

This update builds on the previous clipboard/shape/typography implementation, not a new application. Version remains `0.1.0`.

- **Image paste, shape editing and project saving** remain available. Ctrl+V accepts supported screenshot/browser image data; it is pasted as an editable raster layer. Copy/cut/paste internal vector objects is supported where the clipboard interface allows it.
- **Precise freehand finishing:** Pointer coalescing on supported hardware and a final un-smoothed endpoint reduce cursor lag. The Precision Pen remains distinct from smoothing-based freehand paths.
- **Text editing:** Multiline inline canvas editor plus a compact text-content inspector, editable font family, line height and letter spacing. Ctrl+Enter commits inspector text once. Font metrics are measured using Canvas2D; text shaping/complex scripts are not a full publishing engine.
- **Document tabs:** Rename in place, duplicate from menu, close other tabs with unsaved warnings, drag reordering, keyboard reordering, dirty indicators.
- **Spectrum FX Studio:** The former FX inspector tab is replaced by a compact button **between the layer list and layer action row**. The overlay has separate **Filters / Customize / FX** tabs, search, editable stacks and temporary before/after FX comparison.
- **Filters:** Brightness, contrast, saturation, hue, grayscale, sepia, Gaussian blur, shadow, glow, outline, chromatic split, invert, pixelate, posterize, vignette. Effects stay editable in `.spectrum` documents.
- **Signature FX:** Neon Pulse, Shadow Forge, Hyper Outline, Glitch Matrix, Dream Bloom, Comic Pop, Prism Split, Golden Hour, Frostbite, Ember Glow. These are adjustable layer-effect combinations, not independent advanced new raster processors.
- **13 standalone theme stylesheets**, each with light and dark surfaces. Shared compact layout in `polish.css`; application-wide typography and component spacing are deliberately small.

### Verification and remaining work

The included Node regression suite passed **49 tests**, and Chromium Canvas2D/CSS assertions passed **56 checks** in the author's environment. TypeScript source was checked against temporary stand-ins for unavailable packages, with implicit-any diagnostics disabled. This is **not** equivalent to the real `npm run check` or `npm run build`. npm registry DNS was unavailable and Rust was missing, so no genuine React/MUI browser E2E or Tauri Windows build was completed. Read [`CHECKS.md`](CHECKS.md) for the exact scope and reproducible commands; [`ACCEPTANCE.md`](ACCEPTANCE.md) documents desktop acceptance criteria.

**Features not yet professionally complete:** flexible lasso/magic-wand/feathered selections; per-pixel masks; snapping and advanced vector boolean operations; complex typography shaping and text-on-path; true real-time dragging of every FX parameter; tile-based rendering/history; ICC/HDR color management; RAW/PSD import and export; fully validated Windows/Tauri packaging. The current release must still be regarded as an **experimental source build**, not a certified pro editing suite. PNG/WebP exports include rasterized FX; SVG preserves geometry but not proprietary Spectrum FX appearance.

No login, premium edition, paid feature, telemetry, trial or subscription was added.

## Spectrum 0.1: installed fonts and native titlebar (October 19, 2026)

The **Text (T)** tool now places a true editable textarea on top of the canvas. Click the canvas to type immediately; when text already exists, clicking it with Text (T) reopens its editor. Double-click existing text with **Move (V)** for editing. Text is not written into undo history until you commit. **Enter** inserts a newline, **Ctrl+Enter** or **Done** commits, and **Esc** or **Cancel** discards the draft. Font changes while typing do not close the edit session. Typing, selection, and clipboard operations inside the textarea use native input behavior.

The contextual font dropdown appears whenever Text (T) is active or a text object is selected. In a **Tauri desktop window**, a Rust `fontdb` command enumerates standard OS font directories and provides their installed font family names to the frontend. Search by name, use arrows/Enter, or refresh after installing fonts. Note that fontdb does not query every third-party font manager or nonstandard directory, so unusual font installations may require moving fonts into standard system locations. In the **browser preview**, installed font enumeration is not available; the dropdown is explicitly labeled as a list of common fonts.

The editor uses a compact **32 px custom window titlebar** with Minimize, Maximize/Restore and Close buttons connected to native Tauri window APIs; these buttons are disabled in browser-only preview. The titlebar and brand area can be dragged in desktop mode. Tauri window decorations are disabled in `src-tauri/tauri.conf.json`. Close prompts if documents have unsaved changes.

### Verification and prerequisites

Run `npm install`, `npm run check`, `npm test`, `npm run test:browser`, `npm run test:ui`, `npm run build` and `npm run desktop:dev` with Node.js and the Windows Tauri prerequisites installed. The final desktop check must use actual Tauri because browser preview cannot enumerate installed fonts or control the host window. The source ZIP contains no compiled Windows executable.

Advanced rich text runs, fully persistent wrap-to-box geometry, OpenType variation-axis controls, bidirectional layout, and font embedding are not yet part of the 0.1 typography editor. A saved project references installed font families and may look different on a system without the same fonts.

---

## Spectrum 0.1 — Animation timeline and onion skins (2026-10-19)

**Spectrum now opens directly into the editing workspace.** The old full-screen frosted welcome overlay is no longer shown. If recoverable unsaved documents are found before you begin editing, Spectrum restores them without blocking the workspace.

### Starting an animation

Open **File → New animation**, or select **Animate** in the top bar to convert the current static artwork into the first frame of an animation. The timeline occupies a compact strip beneath the canvas **only for animation projects**, and automatically disappears when working on static projects. The native `.spectrum` format remains `0.1.0` / document version `1`; animation data is optional, preserving static project compatibility.

### Timeline controls

- **Drag the playhead** (the downward marker on the ruler) to scrub between frames. Click a thumbnail to jump directly to it, or use the **previous/next** buttons or arrow keys while a frame is focused.
- **+ Frame** creates a blank new cel, keeping the layer structure but not the artwork. The previous frame becomes a translucent reference when onion skins are enabled.
- **Duplicate** creates a full editable copy of the active frame; **Delete** removes the selected frame without allowing you to delete the only remaining frame.
- **Drag thumbnails** to change frame order without losing the identity of the selected frame.
- **FPS** changes the animation's playback rate by proportionally adjusting frame durations; individual frames can have a custom duration in milliseconds.
- **🧅 Onion** switches translucent reference frames on/off; **Prev**, **Next** and **Ghost** control the number of adjacent references and transparency. Ghosts never become part of the artwork, project frame content or exported files.
- **Play/Pause** loops through the frames using their saved durations.
- **Collapse the timeline** using its Frames title to reclaim space. This doesn't delete any animation data.

### Animation export

Use the **File** menu to export **APNG** (animated PNG, supports transparency), a **PNG sprite sheet**, or **PNG sequence ZIP**. Sprite sheets are automatically laid out in a near-square grid; frames in a sequence are labeled `frame-0001.png`, etc. APNG and sequence exports respect per-frame timing where that format can represent it. Sprite sheets contain one image per frame without timing metadata; ZIP contains individual PNG frames.

To protect memory usage, an animation export is limited to 300 frames and 120 million total source pixels, and sprite sheets have their own 64-million-pixel canvas limit. For extremely large projects, export in smaller batches. There is no GIF, MP4, WebM or animated WebP encoder in this milestone.

### Effects and motion improvements

The FX Studio now animates both **opening and closing** rather than disappearing immediately, with reduced-motion accessibility support. Shadow and Glow effects expose **softness, X/Y offset and opacity** controls in addition to their color and intensity; Chromatic Split exposes vertical displacement. Effects remain non-destructive and serialized in `.spectrum` documents.

### Obsolete-source cleanup

The supplied previous project did **not** contain an obsolete-cleanup script. This update introduces `scripts/remove-obsolete.mjs` with an explicit list of known legacy file names and recognition of backup/reject files (`.bak`, `.old`, `.orig`, `.rej`, `.tmp`, `~`) under source/test directories. It never removes folders or unrecognized source files. Run a preview first:

```bash
npm run clean:obsolete:dry
```

To remove only the listed/recognized obsolete files:

```bash
npm run clean:obsolete
```

The default script is a dry-run; only `--apply` actually deletes files. This cleanup was smoke-tested using a temporary `.old` file; the delivered ZIP does not include that test file.

### Implementation limits

The editor still stores a complete working layer list in the current animation cel and retains bounded full-document history snapshots. Scrubbing uses structurally shared frame objects to avoid cloning an entire animation every time the playhead moves. The full native build, large-document stress testing, GUI accessibility validation and MUI/React integration checks remain necessary before treating this as a production-ready editor.
