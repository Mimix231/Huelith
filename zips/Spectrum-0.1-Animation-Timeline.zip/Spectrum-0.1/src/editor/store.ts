import { create } from 'zustand';
import { syncActiveCel, enableAnimation, insertFrame, deleteFrame, reorderFrame, changeFps, changeOnion, changeFrameDuration } from './animation';
import { DEFAULT_TEXT_FORMAT, normalizeTextFormat, reflowTextShape, type TextDraft, type TextFormat } from './typography';
import {
  createDocument, layerById, makeRaster, makeVector, uid,
  type Document, type Layer, type Tool, type VectorShape, type Workspace, type Point, type SelectionRect, type BlendMode, type Effect, type EffectKind, type AppearanceMode, type OnionSkinSettings,
} from './types';

const HISTORY_LIMIT = 40;
const HISTORY_BUDGET = 48 * 1024 * 1024;
const historySizes = new WeakMap<Document, number>();

function historySize(doc: Document): number {
  const cached = historySizes.get(doc);
  if (cached !== undefined) return cached;
  const bytes = JSON.stringify(doc).length * 2;
  historySizes.set(doc, bytes);
  return bytes;
}

export function trimHistory(history: Document[]): Document[] {
  let size = 0;
  const retained: Document[] = [];
  for (let index = history.length - 1; index >= 0 && retained.length < HISTORY_LIMIT; index--) {
    const bytes = historySize(history[index]);
    if (retained.length && size + bytes > HISTORY_BUDGET) break;
    size += bytes;
    retained.unshift(history[index]);
  }
  return retained;
}

interface WorkspaceSettings {
  theme: Workspace;
  appearanceMode: AppearanceMode;
  inspectorOpen: boolean;
  toolsOpen: boolean;
  inspectorWidth: number;
}

function savedWorkspace(): WorkspaceSettings {
  const defaults: WorkspaceSettings = {
    theme: 'glass',
    appearanceMode: 'dark',
    inspectorOpen: true,
    toolsOpen: true,
    inspectorWidth: 236,
  };
  try {
    const theme = localStorage.getItem('spectrum-theme');
    const raw = localStorage.getItem('spectrum-layout');
    const layout = raw ? JSON.parse(raw) as Partial<WorkspaceSettings> : {};
    return {
      theme: ['glass', 'material', 'classic', 'midnight', 'studio', 'strawberry', 'melon', 'peach', 'lemon', 'mango', 'sakura', 'blossom', 'shadow'].includes(theme ?? '') ? theme as Workspace : defaults.theme,
      appearanceMode: layout.appearanceMode === 'light' || layout.appearanceMode === 'dark' ? layout.appearanceMode : defaults.appearanceMode,
      inspectorOpen: typeof layout.inspectorOpen === 'boolean' ? layout.inspectorOpen : defaults.inspectorOpen,
      toolsOpen: typeof layout.toolsOpen === 'boolean' ? layout.toolsOpen : defaults.toolsOpen,
      inspectorWidth: Number.isFinite(layout.inspectorWidth) ? Math.max(200, Math.min(420, layout.inspectorWidth!)) : defaults.inspectorWidth,
    };
  } catch {
    return defaults;
  }
}

function persistLayout(settings: Partial<WorkspaceSettings>): void {
  try {
    const previous = savedWorkspace();
    localStorage.setItem('spectrum-layout', JSON.stringify({ ...previous, ...settings }));
  } catch { /* Offline and private mode remain usable. */ }
}

const clone = <T,>(value: T): T => structuredClone(value);

export interface EditorTab {
  doc: Document;
  past: Document[];
  future: Document[];
  dirty: boolean;
  path?: string;
  revision: number;
  savedRevision: number;
  savedDoc: Document;
}

export interface EditorStore {
  tabs: EditorTab[];
  activeId: string;
  tool: Tool;
  color: string;
  fill: string;
  strokeWidth: number;
  opacity: number;
  hardness: number;
  smoothing: number;
  zoom: number;
  pan: Point;
  workspace: Workspace;
  appearanceMode: AppearanceMode;
  grid: boolean;
  selectedShapeId: string | null;
  textDefaults: TextFormat;
  textDraft: TextDraft | null;
  startTextDraft: (draft: TextDraft) => void;
  changeTextDraft: (patch: Partial<TextDraft>) => void;
  setTextFormat: (patch: Partial<TextFormat>) => void;
  commitTextDraft: () => void;
  cancelTextDraft: () => void;
  fxBypassLayerId: string | null;
  selectedNodeIndex: number | null;
  selection: SelectionRect | null;
  focusMode: boolean;
  inspectorOpen: boolean;
  toolsOpen: boolean;
  inspectorWidth: number;
  setHardness: (value: number) => void;
  setSmoothing: (value: number) => void;
  setSelection: (selection: SelectionRect | null) => void;
  selectNode: (index: number | null) => void;
  setFxBypassLayer: (id: string | null) => void;
  setFocusMode: (enabled: boolean) => void;
  setInspectorOpen: (open: boolean) => void;
  setToolsOpen: (open: boolean) => void;
  setInspectorWidth: (width: number) => void;
  saveInspectorWidth: () => void;
  setLayerBlend: (id: string, blend: BlendMode) => void;
  applySelectionMask: (id: string) => void;
  clearLayerMask: (id: string) => void;
  setTool: (tool: Tool) => void;
  setColor: (color: string) => void;
  setFill: (fill: string) => void;
  setStrokeWidth: (width: number) => void;
  setOpacity: (opacity: number) => void;
  setZoom: (zoom: number) => void;
  setPan: (pan: Point) => void;
  setWorkspace: (workspace: Workspace) => void;
  setAppearanceMode: (mode: AppearanceMode) => void;
  reorderTabs: (sourceId: string, targetId: string) => void;
  renameDoc: (docId: string, name: string) => void;
  duplicateDoc: (docId: string) => void;
  setGrid: (grid: boolean) => void;
  selectShape: (id: string | null) => void;
  newDoc: (name?: string, width?: number, height?: number, background?: string, animation?: boolean) => void;
  makeAnimation: () => void;
  setActiveFrame: (index: number) => void;
  appendFrame: (duplicate?: boolean) => void;
  deleteActiveFrame: () => void;
  reorderAnimationFrames: (from: number, to: number) => void;
  setAnimationFps: (fps: number) => void;
  setOnion: (value: Partial<OnionSkinSettings>) => void;
  setFrameDuration: (index: number, ms: number) => void;
  openDoc: (doc: Document, path?: string) => void;
  closeDoc: (id: string) => void;
  activate: (id: string) => void;
  mutate: (edit: (doc: Document) => void) => void;
  undo: () => void;
  redo: () => void;
  markSaved: (id: string, revision: number, path?: string) => void;
  addLayer: (type: 'raster' | 'vector') => void;
  duplicateLayer: () => void;
  removeLayer: () => void;
  selectLayer: (id: string) => void;
  moveLayer: (id: string, step: number) => void;
  toggleLayer: (id: string, field: 'visible' | 'locked') => void;
  renameLayer: (id: string, name: string) => void;
  setLayerOpacity: (id: string, opacity: number) => void;
  addEffect: (id: string, kind: EffectKind) => void;
  appendEffects: (id: string, effects: Effect[]) => void;
  updateEffect: (layerId: string, effectId: string, changes: Partial<Effect>) => void;
  removeEffect: (layerId: string, effectId: string) => void;
  moveEffect: (layerId: string, effectId: string, direction: number) => void;
  addShape: (shape: VectorShape) => void;
  updateShape: (id: string, edit: (shape: VectorShape) => void) => void;
  removeShape: (id: string) => void;
}

function regenerateLayerIds(layer: Layer): void {
  layer.id = uid();
  if (layer.type === 'vector') {
    for (const shape of layer.shapes) shape.id = uid();
  }
  if (layer.type === 'group') {
    for (const child of layer.children) regenerateLayerIds(child);
  }
}

function tabFor(doc: Document, path?: string): EditorTab {
  return { doc, past: [], future: [], dirty: false, path, revision: 0, savedRevision: 0, savedDoc: doc };
}

const first = createDocument('Welcome canvas');
const layout = savedWorkspace();

export const useEditor = create<EditorStore>((set, get) => ({
  tabs: [tabFor(first)],
  activeId: first.id,
  tool: 'brush',
  color: '#8e83ff',
  fill: '#8e83ff',
  strokeWidth: 12,
  opacity: 1,
  hardness: 0.85,
  smoothing: 0.55,
  zoom: 0.8,
  pan: { x: 0, y: 0 },
  workspace: layout.theme,
  appearanceMode: layout.appearanceMode,
  grid: false,
  selectedShapeId: null,
  textDefaults: DEFAULT_TEXT_FORMAT,
  textDraft: null,
  fxBypassLayerId: null,
  selectedNodeIndex: null,
  selection: null,
  focusMode: false,
  inspectorOpen: layout.inspectorOpen,
  toolsOpen: layout.toolsOpen,
  inspectorWidth: layout.inspectorWidth,

  setHardness: hardness => set({ hardness: Math.max(0.02, Math.min(1, hardness)) }),
  setSmoothing: smoothing => set({ smoothing: Math.max(0, Math.min(0.95, smoothing)) }),
  setSelection: selection => set({ selection }),
  selectNode: selectedNodeIndex => set({ selectedNodeIndex }),
  setFxBypassLayer: fxBypassLayerId => set({ fxBypassLayerId }),
  setFocusMode: focusMode => set({ focusMode }),
  setInspectorOpen: inspectorOpen => {
    persistLayout({ inspectorOpen });
    set({ inspectorOpen });
  },
  setToolsOpen: toolsOpen => {
    persistLayout({ toolsOpen });
    set({ toolsOpen });
  },
  setInspectorWidth: inspectorWidth => {
    const clamped = Math.max(200, Math.min(420, inspectorWidth));
    // Width is persisted at the end of a resize gesture, not during each pointer move.
    set({ inspectorWidth: clamped });
  },

  saveInspectorWidth: () => persistLayout({ inspectorWidth: get().inspectorWidth }),

  startTextDraft: textDraft => set({ textDraft, selectedShapeId: textDraft.id }),
  changeTextDraft: patch => set(state => ({
    textDraft: state.textDraft ? { ...state.textDraft, ...patch } : null,
  })),
  cancelTextDraft: () => set({ textDraft: null }),
  setTextFormat: patch => {
    const state = get();
    const active = activeLayer(state);
    const selected = active?.type === 'vector'
      ? active.shapes.find(item => item.id === state.selectedShapeId && item.kind === 'text') : undefined;
    const base = state.textDraft ?? (selected ? {
      ...state.textDefaults, fontFamily: selected.fontFamily ?? 'Arial',
      fontSize: selected.fontSize ?? 48, fontWeight: selected.fontWeight ?? '400',
      fontStyle: selected.fontStyle ?? 'normal', lineHeight: selected.lineHeight ?? 1.25,
      letterSpacing: selected.letterSpacing ?? 0,
      textAlign: selected.textAlign ?? 'left', color: selected.fill,
    } : state.textDefaults);
    const next = normalizeTextFormat({ ...base, ...patch });
    set({ textDefaults: next });
    if (state.textDraft) {
      set({ textDraft: { ...state.textDraft, ...next } });
      return;
    }
    const shape = selected;
    if (!shape) return;
    get().updateShape(shape.id, target => {
      if (patch.color !== undefined) target.fill = next.color;
      if (patch.fontFamily !== undefined) target.fontFamily = next.fontFamily;
      if (patch.fontSize !== undefined) target.fontSize = next.fontSize;
      if (patch.fontWeight !== undefined) target.fontWeight = next.fontWeight;
      if (patch.fontStyle !== undefined) target.fontStyle = next.fontStyle;
      if (patch.lineHeight !== undefined) target.lineHeight = next.lineHeight;
      if (patch.letterSpacing !== undefined) target.letterSpacing = next.letterSpacing;
      if (patch.textAlign !== undefined) target.textAlign = next.textAlign;
      reflowTextShape(target);
    });
  },
  commitTextDraft: () => {
    const draft = get().textDraft;
    if (!draft) return;
    const format = normalizeTextFormat(draft);
    const text = draft.value;
    const shapeId = draft.id ?? uid();
    set(state => ({
      textDraft: null,
      selectedShapeId: state.activeId === draft.documentId && text.trim()
        ? shapeId : state.activeId === draft.documentId ? null : state.selectedShapeId,
      tabs: state.tabs.map(tab => {
        if (tab.doc.id !== draft.documentId) return tab;
        if (!text.trim() && !draft.id) return tab;
        const doc = clone(tab.doc);
        let layer = doc.layers.find(item => item.id === draft.layerId);
        if (draft.id) {
          if (layer?.type !== 'vector' || layer.locked) return tab;
          const shape = layer.shapes.find(item => item.id === draft.id && item.kind === 'text');
          if (!shape) return tab;
          if (!text.trim()) layer.shapes = layer.shapes.filter(item => item.id !== draft.id);
          else {
            Object.assign(shape, {
              text, fontFamily: format.fontFamily, fontSize: format.fontSize,
              fontWeight: format.fontWeight, fontStyle: format.fontStyle, lineHeight: format.lineHeight,
              letterSpacing: format.letterSpacing, textAlign: format.textAlign, fill: format.color,
            });
            reflowTextShape(shape);
          }
        } else {
          if (layer?.type !== 'vector' || layer.locked || !layer.visible) {
            layer = makeVector('Text layer');
            doc.layers.push(layer);
          }
          doc.activeLayerId = layer.id;
          const shape: VectorShape = {
            id: shapeId, kind: 'text', x: draft.x - layer.x, y: draft.y - layer.y,
            width: 0, height: 0, fill: format.color, stroke: 'none', strokeWidth: 0,
            text, fontFamily: format.fontFamily, fontSize: format.fontSize,
            fontWeight: format.fontWeight, fontStyle: format.fontStyle, textAlign: format.textAlign,
            lineHeight: format.lineHeight, letterSpacing: format.letterSpacing,
          };
          reflowTextShape(shape);
          layer.shapes.push(shape);
        }
        if (JSON.stringify(doc) === JSON.stringify(tab.doc)) return tab;
        syncActiveCel(doc);
        doc.updatedAt = new Date().toISOString();
        return {
          ...tab, doc, past: trimHistory([...tab.past, tab.doc]), future: [],
          dirty: true, revision: tab.revision + 1,
        };
      }),
    }));
  },
  setTool: tool => {
    if (get().textDraft) get().commitTextDraft();
    set({ tool });
  },
  setColor: color => set({ color }),
  setFill: fill => set({ fill }),
  setStrokeWidth: strokeWidth => set({ strokeWidth: Math.max(1, Math.min(120, strokeWidth)) }),
  setOpacity: opacity => set({ opacity: Math.max(0, Math.min(1, opacity)) }),
  setZoom: zoom => set({ zoom: Math.max(0.05, Math.min(32, zoom)) }),
  setPan: pan => set({ pan }),
  setAppearanceMode: appearanceMode => {
    persistLayout({ appearanceMode });
    set({ appearanceMode });
  },
  reorderTabs: (sourceId, targetId) => set(state => {
    if (sourceId === targetId) return state;
    const source = state.tabs.findIndex(tab => tab.doc.id === sourceId);
    const target = state.tabs.findIndex(tab => tab.doc.id === targetId);
    if (source < 0 || target < 0) return state;
    const tabs = [...state.tabs];
    const [moving] = tabs.splice(source, 1);
    tabs.splice(target, 0, moving);
    return { tabs };
  }),
  renameDoc: (docId, name) => set(state => ({
    tabs: state.tabs.map(tab => {
      if (tab.doc.id !== docId || !name.trim() || tab.doc.name === name.trim()) return tab;
      const doc = clone(tab.doc);
      doc.name = name.trim();
      doc.updatedAt = new Date().toISOString();
      return {
        ...tab, doc, past: trimHistory([...tab.past, tab.doc]), future: [],
        dirty: true, revision: tab.revision + 1,
      };
    }),
  })),
  duplicateDoc: docId => {
    if (get().textDraft) get().commitTextDraft();
    set(state => {
      const source = state.tabs.find(tab => tab.doc.id === docId);
      if (!source) return state;
      const duplicated = clone(source.doc);
      duplicated.id = uid();
      duplicated.name = `${duplicated.name} copy`;
      const position = state.tabs.indexOf(source);
      const tabs = [...state.tabs];
      tabs.splice(position + 1, 0, tabFor(duplicated));
      return { tabs, activeId: duplicated.id, selectedShapeId: null };
    });
  },

  setWorkspace: workspace => {
    try { localStorage.setItem('spectrum-theme', workspace); } catch { /* Keep working offline. */ }
    set({ workspace });
  },
  setGrid: grid => set({ grid }),
  selectShape: selectedShapeId => set({ selectedShapeId, selectedNodeIndex: null }),

  newDoc: (name, width, height, background, animation = false) => {
    if (get().textDraft) get().commitTextDraft();
    const doc = createDocument(name, width, height, background);
    if (animation) enableAnimation(doc);
    set(state => ({
      tabs: [...state.tabs, tabFor(doc)], activeId: doc.id,
      pan: { x: 0, y: 0 }, selectedShapeId: null, selection: null,
    }));
  },

  openDoc: (doc, path) => {
    if (get().textDraft) get().commitTextDraft();
    const opened = clone(doc);
    // An already open copy must never share a tab identity with another document.
    opened.id = uid();
    set(state => ({
      tabs: [...state.tabs, tabFor(opened, path)], activeId: opened.id,
      pan: { x: 0, y: 0 }, selectedShapeId: null, selection: null,
    }));
  },

  closeDoc: id => {
    if (get().textDraft) get().commitTextDraft();
    set(state => {
      const tabs = state.tabs.filter(tab => tab.doc.id !== id);
      if (tabs.length === 0) {
        const doc = createDocument();
        return {
          tabs: [tabFor(doc)], activeId: doc.id,
          selectedShapeId: null,
        };
      }
      return {
        tabs,
        activeId: state.activeId === id ? tabs[tabs.length - 1].doc.id : state.activeId,
        selectedShapeId: null,
      };
    });
  },

  activate: activeId => {
    if (get().textDraft) get().commitTextDraft();
    set({ activeId, selectedShapeId: null });
  },

  mutate: edit => set(state => ({
    tabs: state.tabs.map(tab => {
      if (tab.doc.id !== state.activeId) return tab;
      const doc = clone(tab.doc);
      edit(doc);
      syncActiveCel(doc);
      // Do not fill undo history with no-op clicks or edits to locked layers.
      if (JSON.stringify(doc) === JSON.stringify(tab.doc)) return tab;
      doc.updatedAt = new Date().toISOString();
      return {
        ...tab, doc, past: trimHistory([...tab.past, tab.doc]), future: [],
        dirty: true, revision: tab.revision + 1,
      };
    }),
  })),

  undo: () => {
    if (get().textDraft) get().commitTextDraft();
    set(state => ({
      tabs: state.tabs.map(tab => {
        if (tab.doc.id !== state.activeId || tab.past.length === 0) return tab;
        const doc = tab.past[tab.past.length - 1];
        return {
          ...tab, doc, past: tab.past.slice(0, -1), future: [tab.doc, ...tab.future],
          revision: tab.revision + 1, dirty: doc !== tab.savedDoc,
        };
      }),
      selectedShapeId: null,
    }));
  },

  redo: () => {
    if (get().textDraft) get().commitTextDraft();
    set(state => ({
      tabs: state.tabs.map(tab => {
        if (tab.doc.id !== state.activeId || tab.future.length === 0) return tab;
        const [doc, ...future] = tab.future;
        return {
          ...tab, doc, past: trimHistory([...tab.past, tab.doc]), future,
          revision: tab.revision + 1, dirty: doc !== tab.savedDoc,
        };
      }),
      selectedShapeId: null,
    }));
  },

  markSaved: (id, revision, path) => set(state => ({
    tabs: state.tabs.map(tab => tab.doc.id === id ? {
      ...tab, path: path ?? tab.path, savedRevision: revision,
      savedDoc: tab.revision === revision ? tab.doc : tab.savedDoc,
      dirty: tab.revision !== revision,
    } : tab),
  })),

  makeAnimation: () => get().mutate(doc => enableAnimation(doc)),
  setActiveFrame: index => {
    if (get().textDraft) get().commitTextDraft();
    set(state => ({
      tabs: state.tabs.map(tab => {
        if (tab.doc.id !== state.activeId || !tab.doc.animation) return tab;
        if (tab.doc.animation.currentFrame === index) return tab;
        const track = tab.doc.animation;
        if (!Number.isInteger(index) || index < 0 || index >= track.frames.length) return tab;
        // Structural sharing is crucial: avoid cloning every cel on each playback tick.
        // Snapshot only the outgoing working cel and preserve all other frame identities.
        const frames = [...track.frames];
        frames[track.currentFrame] = {
          ...frames[track.currentFrame], layers: tab.doc.layers, activeLayerId: tab.doc.activeLayerId,
        };
        const selected = frames[index];
        const doc: Document = {
          ...tab.doc, layers: selected.layers, activeLayerId: selected.activeLayerId,
          animation: { ...track, frames, currentFrame: index },
        };
        // Scrubbing changes the visible cel but does not pollute undo history.
        return { ...tab, doc };
      }),
      selectedShapeId: null,
      selectedNodeIndex: null,
      selection: null,
    }));
  },
  appendFrame: duplicate => {
    if (get().textDraft) get().commitTextDraft();
    get().mutate(doc => { insertFrame(doc, duplicate); });
    set({ selectedShapeId: null, selectedNodeIndex: null, selection: null });
  },
  deleteActiveFrame: () => {
    if (get().textDraft) get().commitTextDraft();
    get().mutate(doc => { deleteFrame(doc); });
    set({ selectedShapeId: null, selectedNodeIndex: null, selection: null });
  },
  reorderAnimationFrames: (from, to) => get().mutate(doc => { reorderFrame(doc, from, to); }),
  setAnimationFps: fps => get().mutate(doc => { changeFps(doc, fps); }),
  setOnion: value => get().mutate(doc => { changeOnion(doc, value); }),
  setFrameDuration: (index, ms) => get().mutate(doc => { changeFrameDuration(doc, index, ms); }),

  addLayer: type => get().mutate(doc => {
    const layer = type === 'raster' ? makeRaster() : makeVector();
    doc.layers.push(layer);
    doc.activeLayerId = layer.id;
  }),

  duplicateLayer: () => get().mutate(doc => {
    const index = doc.layers.findIndex(layer => layer.id === doc.activeLayerId);
    if (index < 0) return;
    const duplicated = clone(doc.layers[index]);
    regenerateLayerIds(duplicated);
    duplicated.name += ' copy';
    doc.layers.splice(index + 1, 0, duplicated);
    doc.activeLayerId = duplicated.id;
  }),

  removeLayer: () => get().mutate(doc => {
    if (doc.layers.length <= 1) return;
    doc.layers = doc.layers.filter(layer => layer.id !== doc.activeLayerId);
    doc.activeLayerId = doc.layers.at(-1)?.id ?? null;
  }),

  selectLayer: id => set(state => ({
    tabs: state.tabs.map(tab => tab.doc.id === state.activeId ? {
      ...tab, doc: (() => {
        const doc = { ...tab.doc, activeLayerId: id };
        syncActiveCel(doc);
        return doc;
      })(),
    } : tab),
    selectedShapeId: null,
  })),

  moveLayer: (id, step) => get().mutate(doc => {
    const index = doc.layers.findIndex(layer => layer.id === id);
    const target = index + step;
    if (index < 0 || target < 0 || target >= doc.layers.length) return;
    [doc.layers[index], doc.layers[target]] = [doc.layers[target], doc.layers[index]];
  }),

  toggleLayer: (id, field) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer) layer[field] = !layer[field];
  }),

  renameLayer: (id, name) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer && name.trim()) layer.name = name.trim();
  }),

  setLayerOpacity: (id, opacity) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer) layer.opacity = Math.max(0, Math.min(1, opacity));
  }),

  setLayerBlend: (id, blend) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer && !layer.locked) layer.blend = blend;
  }),

  applySelectionMask: id => {
    const selection = get().selection;
    if (!selection || selection.width <= 0 || selection.height <= 0) return;
    get().mutate(doc => {
      const layer = layerById(doc, id);
      if (layer && !layer.locked) layer.mask = { ...selection };
    });
  },

  clearLayerMask: id => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer && !layer.locked) delete layer.mask;
  }),

  addEffect: (id, kind) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer && !layer.locked) {
      const defaults: Partial<Record<EffectKind, number>> = {
        brightness: 115, contrast: 120, saturate: 140, hue: 30,
        grayscale: 100, sepia: 80, blur: 5, shadow: 12,
        glow: 16, outline: 5, chromatic: 7, invert: 100, pixelate: 10, posterize: 6, vignette: 75,
      };
      layer.effects = [...(layer.effects ?? []), { id: uid(), enabled: true, kind, amount: defaults[kind] ?? 100 }];
    }
  }),

  appendEffects: (id, effects) => get().mutate(doc => {
    const layer = layerById(doc, id);
    if (layer && !layer.locked) {
      layer.effects = [...(layer.effects ?? []), ...effects.map(effect => ({ ...effect, id: uid() }))].slice(0, 64);
    }
  }),

  updateEffect: (layerId, effectId, changes) => get().mutate(doc => {
    const layer = layerById(doc, layerId);
    if (!layer || layer.locked) return;
    const effect = layer.effects?.find(item => item.id === effectId);
    if (!effect) return;
    if (changes.enabled !== undefined) effect.enabled = changes.enabled;
    if (Number.isFinite(changes.amount)) effect.amount = Math.min(200, Math.max(0, changes.amount!));
    if (typeof changes.color === 'string') effect.color = changes.color;
    if (changes.parameters) {
      const parameters = { ...(effect.parameters ?? {}) };
      for (const [key, value] of Object.entries(changes.parameters)) {
        if (typeof value === 'number' && Number.isFinite(value) && ['blur', 'opacity', 'offsetX', 'offsetY', 'shiftY'].includes(key)) {
          const bounded = key === 'opacity' ? Math.max(0, Math.min(100, value)) : Math.max(-200, Math.min(200, value));
          Object.assign(parameters, { [key]: bounded });
        }
      }
      effect.parameters = parameters;
    }
  }),

  removeEffect: (layerId, effectId) => get().mutate(doc => {
    const layer = layerById(doc, layerId);
    if (layer && !layer.locked) layer.effects = layer.effects?.filter(effect => effect.id !== effectId);
  }),

  moveEffect: (layerId, effectId, direction) => get().mutate(doc => {
    const layer = layerById(doc, layerId);
    if (!layer || layer.locked || !layer.effects) return;
    const index = layer.effects.findIndex(effect => effect.id === effectId);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= layer.effects.length) return;
    [layer.effects[index], layer.effects[target]] = [layer.effects[target], layer.effects[index]];
  }),

  addShape: shape => get().mutate(doc => {
    let layer = layerById(doc, doc.activeLayerId);
    if (layer?.type !== 'vector' || layer.locked || !layer.visible) {
      const fresh = makeVector();
      doc.layers.push(fresh);
      doc.activeLayerId = fresh.id;
      layer = fresh;
    }
    if (layer.type === 'vector') {
      const movePoint = (point: Point): Point => ({ x: point.x - layer.x, y: point.y - layer.y });
      layer.shapes.push({
        ...shape,
        x: shape.x - layer.x,
        y: shape.y - layer.y,
        points: shape.points?.map(movePoint),
        controls: shape.controls?.map(movePoint) as [Point, Point] | undefined,
        nodes: shape.nodes?.map(node => ({
          ...movePoint(node),
          in: node.in ? movePoint(node.in) : undefined,
          out: node.out ? movePoint(node.out) : undefined,
        })),
      });
    }
  }),

  updateShape: (id, edit) => get().mutate(doc => {
    for (const layer of doc.layers) {
      if (layer.type !== 'vector' || layer.locked) continue;
      const shape = layer.shapes.find(item => item.id === id);
      if (shape) {
        edit(shape);
        break;
      }
    }
  }),

  removeShape: id => get().mutate(doc => {
    for (const layer of doc.layers) {
      if (layer.type === 'vector' && !layer.locked) {
        layer.shapes = layer.shapes.filter(shape => shape.id !== id);
      }
    }
  }),
}));

export function activeTab(state: EditorStore): EditorTab {
  return state.tabs.find(tab => tab.doc.id === state.activeId) ?? state.tabs[0];
}

export function activeLayer(state: EditorStore): Layer | undefined {
  const doc = activeTab(state).doc;
  return layerById(doc, doc.activeLayerId);
}
