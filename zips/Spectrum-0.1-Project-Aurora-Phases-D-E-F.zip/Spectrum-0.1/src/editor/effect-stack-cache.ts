import { applyEffect } from './effect-ops';
import type { Effect } from './types';

interface CachedStage { signature: string; image: HTMLCanvasElement }
interface CachedStack { width: number; height: number; stages: CachedStage[] }

/**
 * The native-resolution worker holds only a bounded set of intermediate
 * *prefixes*. Editing a late-stage glow, for example, must not recalculate
 * earlier watercolor/denoise/color operations on every pointer move.
 *
 * Keys include the immutable source id; callers must change that id whenever
 * a source canvas's pixels or geometry change. This cache is a preview-only
 * optimization: deterministic synchronous exports use processEffects().
 */
export class EffectStackCache {
  private readonly stacks = new Map<number, CachedStack>();
  constructor(private readonly byteBudget = 128 * 1024 * 1024) {}

  clearSource(sourceId: number): void { this.stacks.delete(sourceId); }
  clear(): void { this.stacks.clear(); }

  render(sourceId: number, source: HTMLCanvasElement, effects: readonly Effect[]): HTMLCanvasElement {
    const existing = this.stacks.get(sourceId);
    const previous = existing && existing.width === source.width && existing.height === source.height
      ? existing.stages : [];
    let current = source;
    let reuse = true;
    const stages: CachedStage[] = [];
    for (const effect of effects) {
      if (!effect.enabled || !Number.isFinite(effect.amount) ||
        (['outline', 'cutout'].includes(effect.kind) && effect.amount === 0)) continue;
      // JSON is appropriate here: effect settings are small validated POJOs,
      // and every numeric parameter / gradient stop must affect invalidation.
      const signature = JSON.stringify(effect);
      const index = stages.length;
      if (reuse && previous[index]?.signature === signature) {
        current = previous[index].image;
      } else {
        reuse = false;
        current = applyEffect(current, effect);
      }
      stages.push({ signature, image: current });
    }
    this.stacks.delete(sourceId);
    this.stacks.set(sourceId, { width: source.width, height: source.height, stages });
    this.trim();
    return current;
  }

  private trim(): void {
    const cost = (): number => {
      const surfaces = new Set<HTMLCanvasElement>();
      for (const stack of this.stacks.values()) for (const stage of stack.stages) surfaces.add(stage.image);
      let bytes = 0;
      for (const image of surfaces) bytes += image.width * image.height * 4;
      return bytes;
    };
    let bytes = cost();
    while (bytes > this.byteBudget && this.stacks.size > 0) {
      // Keep the latest rendered stage even when the single canvas exceeds
      // the budget; drop the final stages, retaining reusable initial prefixes.
      const oldestId = this.stacks.keys().next().value as number;
      const stack = this.stacks.get(oldestId)!;
      if (this.stacks.size === 1 && stack.stages.length > 1) {
        stack.stages.pop();
      } else if (this.stacks.size === 1 && stack.stages.length <= 1) break;
      else this.stacks.delete(oldestId);
      bytes = cost();
    }
  }
}
