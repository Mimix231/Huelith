# Spectrum 0.1 — Compact Creative Studio verification report

**Date:** 2026-10-17 · **Version:** `0.1.0` (intentionally unchanged).

## Results from the source-package environment

| Check | Result | Interpretation |
| --- | --- | --- |
| `npm test` | **49 / 49 pass** | Document validation, edits/history, curve control points, saved FX, brushes, tab reorder, appearance, source parsing |
| `npm run test:browser` | **56 / 56 pass** | Actual Chromium Canvas2D pixel/clipboard checks and computed styles for themes in both appearance modes |
| Stand-in-based source TypeScript check | **Pass** | Temporary library declarations, `noImplicitAny: false`; **not** the real dependency-aware check |
| Python E2E test script syntax | **Pass** | `python -m py_compile tests/ui-e2e.py`; the E2E test itself was **not** run |
| CSS parsing | **Pass** | Parsed all 16 stylesheets with tinycss2; no CSS parser errors |
| JSON/TOML configuration | **Pass** | Package and Tauri configuration are parseable |
| Real `npm run check` and `npm run build` | **Blocked** | Registry DNS failed; dependencies could not be installed, so true MUI/React typings and Vite bundles were not checked |
| React/MUI interactive E2E | **Not run** | Requires working `npm install`, Vite and browser session |
| Windows desktop launch and Tauri build | **Not run** | No Rust cargo toolchain or Windows desktop in this environment |

The temporary TypeScript dependency declarations are **not included in the ZIP**; they exist only in the local build-check workspace to catch source-level errors. Passing them does not establish a fully compiling project.

### Automated coverage added or expanded in this pass

- Document tabs: reorder and document identity, dirty changes and save-revision integrity.
- Themes: **Strawberry, Melon, Peach, Lemon, Mango, Sakura, Blossom and Shadow**, with actual browser checks for their separate light and dark styles; earlier themes remain available.
- Pixel FX: invert, pixelate, posterize and vignette in actual Canvas2D, as well as existing blur/glow/outline/brightness and SVG/clipboard checks.
- Serialized effects: effect enum validation, non-destructive stacks and undo handling.
- Canvas brush: exact endpoint at zero smoothing, stabilized endpoint after stroke completion, and pointer coalescing.
- Transient before/after compare state does not enter document history or serialize to projects.
- New `tests/ui-e2e.py` scenarios for theme picker, tabs, FX launcher and editor behavior are **included for manual or CI execution**, not claimed as passing here.

### Commands to run after extracting on a Windows machine

```powershell
npm install
npm run check
npm test
npm run test:browser
npm run test:ui
npm run build
npm run desktop:dev
npm run desktop:build
```

`npm run test:browser` and `npm run test:ui` require Python Playwright with Chromium; the Tauri commands require the Rust toolchain and Tauri's Windows OS prerequisites. Fix any errors in the real build **before distributing an installer**. Run the interactive acceptance scenarios in `ACCEPTANCE.md` on Windows; source tests alone cannot demonstrate that the complete GUI works.

## Remaining engineering limitations

1. **Not an installed application**: This ZIP contains source code, not a working Windows executable.
2. **The UI has not been visually inspected in a fully bundled React/MUI/Tauri runtime**, because the required dependencies could not be installed here. Pixel and CSS component tests are narrower than full UI E2E tests.
3. **Advanced professional editing remains incomplete:** elliptical/lasso/magic wand selections, alpha and feathered masks, full vector path operations, multi-run rich typography, RAW/PSD, color profiles, GPU tile rendering and tile-delta history are not present.
4. **FX sliders** commit to project history on release, rather than updating the full document live for every intermediate drag frame; the stack is editable and togglable.
5. **SVG** preserves geometry but will not reproduce Spectrum-specific raster FX. Use PNG/WebP for effects-heavy output.
6. Very large artwork may still stress CPU, memory and Canvas2D; performance is not guaranteed by synthetic smoke tests.

Keep the application at **Spectrum 0.1** until the complete build, UI tests, and desktop acceptance checklist actually pass.
