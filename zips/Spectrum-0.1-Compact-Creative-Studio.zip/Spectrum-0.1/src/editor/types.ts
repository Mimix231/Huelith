/** Spectrum 0.1's on-disk document model. Keep serialized fields stable. */
export type BlendMode = 'source-over' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten';

export interface Point {
  x: number;
  y: number;
}

export interface LayerBase {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  opacity: number;
  blend: BlendMode;
  x: number;
  y: number;
  /** Non-destructive rectangular layer mask, in document coordinates. */
  mask?: SelectionRect;
  /** Non-destructive effects, evaluated in order. */
  effects?: Effect[];
}

export type EffectKind =
  | 'brightness' | 'contrast' | 'saturate' | 'hue' | 'grayscale' | 'sepia'
  | 'blur' | 'shadow' | 'glow' | 'outline' | 'chromatic'
  | 'invert' | 'pixelate' | 'posterize' | 'vignette';

export interface Effect {
  id: string;
  kind: EffectKind;
  enabled: boolean;
  amount: number;
  color?: string;
}

export interface RasterLayer extends LayerBase {
  type: 'raster';
  image: string;
  imageWidth?: number;
  imageHeight?: number;
  scaleX?: number;
  scaleY?: number;
  rotation?: number;
}

export type ShapeKind = 'rect' | 'ellipse' | 'line' | 'path' | 'text';

/** Anchor points and editable cubic Bézier handles, in layer-local coordinates. */
export interface BezierNode extends Point {
  in?: Point;
  out?: Point;
}

export interface SelectionRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface VectorShape {
  id: string;
  kind: ShapeKind;
  x: number;
  y: number;
  width: number;
  height: number;
  fill: string;
  stroke: string;
  strokeWidth: number;
  points?: Point[];
  nodes?: BezierNode[];
  /** Four-point cubic control geometry for the line tool (local to layer). */
  controls?: [Point, Point];
  fontWeight?: string;
  textAlign?: 'left' | 'center' | 'right';
  lineHeight?: number;
  letterSpacing?: number;
  rotation?: number;
  text?: string;
  fontSize?: number;
  fontFamily?: string;
}

export interface VectorLayer extends LayerBase {
  type: 'vector';
  shapes: VectorShape[];
}

export interface GroupLayer extends LayerBase {
  type: 'group';
  children: Layer[];
}

export type Layer = RasterLayer | VectorLayer | GroupLayer;

export interface Document {
  format: 'spectrum';
  version: 1;
  id: string;
  name: string;
  width: number;
  height: number;
  background: string;
  layers: Layer[];
  activeLayerId: string | null;
  createdAt: string;
  updatedAt: string;
}

export type Tool = 'freehand' | 'move' | 'node' | 'marquee' | 'hand' | 'brush' | 'eraser' | 'eyedropper' | 'rectangle' | 'ellipse' | 'line' | 'pen' | 'text';
export type Workspace = 'glass' | 'material' | 'classic' | 'midnight' | 'studio'
  | 'strawberry' | 'melon' | 'peach' | 'lemon' | 'mango' | 'sakura' | 'blossom' | 'shadow';
export type AppearanceMode = 'light' | 'dark';

const blendModes: ReadonlySet<string> = new Set(['source-over', 'multiply', 'screen', 'overlay', 'darken', 'lighten']);
const effectKinds = new Set<string>([
  'brightness', 'contrast', 'saturate', 'hue', 'grayscale', 'sepia',
  'blur', 'shadow', 'glow', 'outline', 'chromatic', 'invert', 'pixelate', 'posterize', 'vignette',
]);
const kinds: ReadonlySet<string> = new Set(['rect', 'ellipse', 'line', 'path', 'text']);
const MAX_PIXELS = 64_000_000;

export function uid(): string {
  return globalThis.crypto?.randomUUID?.() ?? `s-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export function validSize(width: number, height: number): boolean {
  return Number.isInteger(width) && Number.isInteger(height) && width >= 1 && height >= 1
    && width <= 16384 && height <= 16384 && width * height <= MAX_PIXELS;
}

function base(name: string): LayerBase {
  return {
    id: uid(), name, visible: true, locked: false, opacity: 1, blend: 'source-over', x: 0, y: 0,
  };
}

export function makeRaster(name = 'Paint layer'): RasterLayer {
  return { ...base(name), type: 'raster', image: '' };
}

export function makeVector(name = 'Vector layer'): VectorLayer {
  return { ...base(name), type: 'vector', shapes: [] };
}

export function createDocument(name = 'Untitled', width = 1280, height = 800, background = '#ffffff'): Document {
  if (!validSize(width, height)) {
    throw new Error('Canvas must be 1–16384 pixels per side and no more than 64 million pixels.');
  }

  const layer = makeRaster();
  const now = new Date().toISOString();
  return {
    format: 'spectrum', version: 1, id: uid(), name: name.trim() || 'Untitled', width, height,
    background, layers: [layer], activeLayerId: layer.id, createdAt: now, updatedAt: now,
  };
}

function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function finite(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function point(value: unknown): value is Point {
  return record(value) && finite(value.x) && finite(value.y);
}

function rect(value: unknown): value is SelectionRect {
  return record(value) && finite(value.x) && finite(value.y)
    && finite(value.width) && finite(value.height)
    && value.width >= 0 && value.height >= 0;
}

function node(value: unknown): value is BezierNode {
  return record(value) && finite(value.x) && finite(value.y)
    && (value.in === undefined || point(value.in))
    && (value.out === undefined || point(value.out));
}

function shape(value: unknown): value is VectorShape {
  if (!record(value) || typeof value.id !== 'string' || !kinds.has(String(value.kind))) return false;
  if (![value.x, value.y, value.width, value.height, value.strokeWidth].every(finite)) return false;
  if (typeof value.fill !== 'string' || typeof value.stroke !== 'string') return false;
  if (!finite(value.strokeWidth) || value.strokeWidth < 0) return false;
  if (value.kind === 'path' && !(
    (Array.isArray(value.points) && value.points.every(point))
    || (Array.isArray(value.nodes) && value.nodes.every(node))
  )) return false;
  if (value.nodes !== undefined && (!Array.isArray(value.nodes) || value.nodes.length > 100000 || !value.nodes.every(node))) return false;
  if (value.controls !== undefined && (!Array.isArray(value.controls) || value.controls.length !== 2 || !value.controls.every(point))) return false;
  if (value.rotation !== undefined && !finite(value.rotation)) return false;
  if (value.fontWeight !== undefined && typeof value.fontWeight !== 'string') return false;
  if (value.textAlign !== undefined && !['left', 'center', 'right'].includes(String(value.textAlign))) return false;
  if (value.lineHeight !== undefined && (!finite(value.lineHeight) || value.lineHeight < 0.5 || value.lineHeight > 5)) return false;
  if (value.letterSpacing !== undefined && (!finite(value.letterSpacing) || Math.abs(value.letterSpacing) > 100)) return false;
  if (value.kind === 'text' && typeof value.text !== 'string') return false;
  if (value.fontSize !== undefined && (!finite(value.fontSize) || value.fontSize <= 0)) return false;
  return value.fontFamily === undefined || typeof value.fontFamily === 'string';
}

function validEffects(value: unknown): boolean {
  return value === undefined || (Array.isArray(value) && value.length <= 64 && value.every(item =>
    record(item) && typeof item.id === 'string' && effectKinds.has(String(item.kind))
    && typeof item.enabled === 'boolean' && finite(item.amount) && item.amount >= 0 && item.amount <= 200
    && (item.color === undefined || typeof item.color === 'string')));
}

function isLayer(value: unknown, depth: number): value is Layer {
  if (!record(value) || depth > 12) return false;
  if (typeof value.id !== 'string' || typeof value.name !== 'string') return false;
  if (typeof value.visible !== 'boolean' || typeof value.locked !== 'boolean') return false;
  if (!finite(value.opacity) || value.opacity < 0 || value.opacity > 1) return false;
  if (!blendModes.has(String(value.blend)) || !finite(value.x) || !finite(value.y)) return false;
  if (value.mask !== undefined && !rect(value.mask)) return false;
  if (!validEffects(value.effects)) return false;
  if (value.type === 'raster') {
    return typeof value.image === 'string'
      && (value.image === '' || /^data:image\/(png|jpeg|webp);base64,/.test(value.image))
      && (value.imageWidth === undefined || (finite(value.imageWidth) && value.imageWidth > 0))
      && (value.imageHeight === undefined || (finite(value.imageHeight) && value.imageHeight > 0))
      && (value.scaleX === undefined || (finite(value.scaleX) && value.scaleX > 0))
      && (value.scaleY === undefined || (finite(value.scaleY) && value.scaleY > 0))
      && (value.rotation === undefined || finite(value.rotation));
  }
  if (value.type === 'vector') return Array.isArray(value.shapes) && value.shapes.length <= 100_000 && value.shapes.every(shape);
  if (value.type === 'group') return Array.isArray(value.children) && value.children.every(child => isLayer(child, depth + 1));
  return false;
}

/** Deep validation: never trust parsed JSON based on its top-level fields alone. */
export function isDocument(value: unknown): value is Document {
  if (!record(value) || value.format !== 'spectrum' || value.version !== 1) return false;
  if (!finite(value.width) || !finite(value.height) || !validSize(value.width, value.height)) return false;
  if (typeof value.id !== 'string' || typeof value.name !== 'string' || typeof value.background !== 'string') return false;
  if (typeof value.createdAt !== 'string' || typeof value.updatedAt !== 'string') return false;
  if (value.activeLayerId !== null && typeof value.activeLayerId !== 'string') return false;
  if (!Array.isArray(value.layers) || value.layers.length > 4096 || !value.layers.every(layer => isLayer(layer, 0))) return false;
  const flattened = flattenLayers(value.layers);
  const ids = flattened.map(layer => layer.id);
  const shapeIds = flattened.flatMap(layer => layer.type === 'vector'
    ? layer.shapes.map(shape => shape.id) : []);
  return new Set(ids).size === ids.length && new Set(shapeIds).size === shapeIds.length
    && (value.activeLayerId === null || ids.includes(value.activeLayerId));
}

export function flattenLayers(layers: Layer[]): Layer[] {
  return layers.flatMap(layer => layer.type === 'group' ? [layer, ...flattenLayers(layer.children)] : [layer]);
}

export function layerById(doc: Document, id: string | null): Layer | undefined {
  if (!id) return undefined;
  return flattenLayers(doc.layers).find(layer => layer.id === id);
}

export function forEachLayer(layers: Layer[], visit: (layer: Layer) => void): void {
  for (const layer of layers) {
    visit(layer);
    if (layer.type === 'group') forEachLayer(layer.children, visit);
  }
}
