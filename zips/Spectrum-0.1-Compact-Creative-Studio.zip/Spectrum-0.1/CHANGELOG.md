# Spectrum changelog

## 0.1.0 — Compact Creative Studio source update (2026-10-17)

- Reworked workspace density and layering of inspector, contextbar, titlebar and document tabs.
- Added eight individual fruit/floral/shadow theme CSS files, giving thirteen themes with independent light and dark palettes and unique controls.
- Moved FX to a dedicated launcher below the layer list, opening a searchable three-tab overlay (Filters / Customize / FX).
- Extended editable per-layer FX with invert, pixelate, posterize and vignette and added four new preset combinations.
- Added temporarily bypassed FX for before/after preview without dirtying the document.
- Added drag/keyboard document tab reordering, renaming and tab context actions.
- Expanded multiline text inspector, font editing, letter spacing and stroke endpoint handling.
- Expanded automated checks to 49 Node tests and 56 Chromium assertions.
- Maintained native `.spectrum` document version; no breaking format migration intended.

**Build note:** Full dependency-aware TypeScript/Vite checks, full React E2E and Windows Tauri build were not possible in the packaging environment. Source remains experimental until these gates pass.
