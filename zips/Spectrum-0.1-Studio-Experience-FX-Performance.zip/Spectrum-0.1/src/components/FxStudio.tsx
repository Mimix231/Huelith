import { useEffect, useRef, useState } from 'react';
import { Button, Slider } from '@mui/material';
import { AutoAwesome, Close, Search, Tune, Palette } from '@mui/icons-material';
import EffectAdvancedEditors, { PreviewColorInput } from './EffectAdvancedEditors';
import EffectIcon from './EffectIcon';
import EffectPreview from './EffectPreview';
import BufferedColorPicker from './BufferedColorPicker';
import { EFFECT_CONTROLS, EFFECT_PARAMETERS, FILTERS, FX_PRESETS, newEffect } from '../editor/fx';
import type { ScalarControl } from '../editor/effect-schema';
import type { EditorStore } from '../editor/store';
import type { BlendMode, Effect, Layer, VectorShape } from '../editor/types';
import { EffectPreviewScheduler } from '../editor/effect-preview-scheduler';
import { useEditor } from '../editor/store';

type StudioTab = 'filters' | 'customization' | 'fx';

interface FxStudioProps {
  state: EditorStore;
  active?: Layer;
  activeShape?: VectorShape;
  onClose: () => void;
}

const groups = ['Color & light', 'Detail & texture', 'Stylize'].map(label => ({
  label,
  kinds: FILTERS.filter(filter => filter.group === label).map(filter => filter.kind),
}));

const blends: { id: BlendMode; label: string }[] = [
  { id: 'source-over', label: 'Normal' },
  { id: 'multiply', label: 'Multiply' },
  { id: 'screen', label: 'Screen' },
  { id: 'overlay', label: 'Overlay' },
  { id: 'darken', label: 'Darken' },
  { id: 'lighten', label: 'Lighten' },
];

function EffectAmount({ effect, onPreview, onCommit }: {
  effect: Effect;
  onPreview: (amount: number) => void;
  onCommit: () => void;
}) {
  const descriptor = EFFECT_CONTROLS[effect.kind];
  const [draft, setDraft] = useState(effect.amount);
  const sliding = useRef(false);
  useEffect(() => {
    if (!sliding.current) setDraft(effect.amount);
  }, [effect.amount]);
  return (
    <label className="fx-level">
      <span>{descriptor.label} <output>{draft}{descriptor.unit}</output></span>
      <Slider aria-label={`${effect.kind} ${descriptor.label}`} value={draft} size="small"
        min={descriptor.min} max={descriptor.max} step={descriptor.step}
        onChange={(_, value) => {
          sliding.current = true;
          const amount = value as number;
          setDraft(amount);
          onPreview(amount);
        }}
        onChangeCommitted={(_, value) => {
          sliding.current = false;
          onPreview(value as number);
          onCommit();
        }} />
    </label>
  );
}

function EffectScalarControl({ effect, control, permitted, preview, commit }: {
  effect: Effect;
  control: ScalarControl;
  permitted: boolean;
  preview: (changes: Partial<Effect>) => void;
  commit: () => void;
}) {
  const candidate = (effect.parameters as unknown as Record<string, number | undefined> | undefined)?.[control.key];
  const value = typeof candidate === 'number' ? candidate : control.initial;
  const [draft, setDraft] = useState(value);
  const sliding = useRef(false);
  useEffect(() => {
    if (!sliding.current) setDraft(value);
  }, [value]);
  const update = (next: number): void => {
    if (!Number.isFinite(next)) return;
    const bounded = Math.max(control.min, Math.min(control.max, next));
    setDraft(bounded);
    preview({ parameters: { [control.key]: bounded } });
  };
  return (
    <label className="fx-level fx-parameter-row">
      <span>{control.label} <output>{Math.round(draft)}{control.unit ?? ''}</output></span>
      <div className="fx-parameter-controls">
        <Slider size="small" min={control.min} max={control.max} step={control.step ?? 1}
          value={draft} disabled={!permitted} aria-label={`${effect.kind} ${control.label}`}
          onChange={(_, next) => { sliding.current = true; update(next as number); }}
          onChangeCommitted={(_, next) => { sliding.current = false; update(next as number); commit(); }} />
        <input type="number" aria-label={`${effect.kind} ${control.label} number`}
          min={control.min} max={control.max} step={control.step ?? 1} disabled={!permitted}
          value={Number(draft.toFixed(2))} onChange={event => update(Number(event.target.value))}
          onBlur={commit} onKeyDown={event => { if (event.key === 'Enter') commit(); }} />
      </div>
    </label>
  );
}

export default function FxStudio({ state, active, activeShape, onClose }: FxStudioProps) {
  const [tab, setTab] = useState<StudioTab>('filters');
  const [query, setQuery] = useState('');
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const permitted = Boolean(active && !active.locked);
  const scheduler = useRef<EffectPreviewScheduler | null>(null);
  if (!scheduler.current) {
    scheduler.current = new EffectPreviewScheduler(
      (layerId, effectId, changes) => useEditor.getState().previewEffect(layerId, effectId, changes),
      () => useEditor.getState().finishEffectPreview(),
    );
  }
  const preview = (effectId: string, changes: Partial<Effect>): void => {
    if (active) scheduler.current?.preview(active.id, effectId, changes);
  };
  const commit = (): void => scheduler.current?.commit();
  const normalizedQuery = query.trim().toLowerCase();

  useEffect(() => {
    const dismiss = (event: PointerEvent): void => {
      if (event.target instanceof Element
        && !event.target.closest('.fx-overlay, .fx-launcher, .MuiPopover-root')) closeRef.current();
    };
    const escape = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        closeRef.current();
      }
    };
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', escape, true);
    panelRef.current?.focus();
    return () => {
      document.removeEventListener('pointerdown', dismiss);
      document.removeEventListener('keydown', escape, true);
      scheduler.current?.commit();
      scheduler.current?.dispose();
      state.setFxBypassLayer(null);
    };
  }, []);

  const effects = active?.effects ?? [];
  const matches = (label: string): boolean => label.toLowerCase().includes(normalizedQuery);

  return (
    <div className="fx-overlay" id="spectrum-fx-studio" role="dialog"
      aria-modal="false" aria-labelledby="fx-title" tabIndex={-1} ref={panelRef}>
      <div className="fx-overlay-header">
        <div className="fx-overlay-title">
          <span className="fx-overlay-symbol"><AutoAwesome fontSize="small" /></span>
          <div><strong id="fx-title">Spectrum Studio</strong><small>Creative effects · non-destructive layers</small></div>
        </div>
        <button type="button" aria-label="Close FX studio" className="fx-close" onClick={onClose}><Close fontSize="small" /></button>
      </div>
      <div className="fx-studio-tabs" role="tablist" aria-label="Effect library">
        {(['filters', 'customization', 'fx'] as const).map(option => (
          <button type="button" role="tab" aria-selected={tab === option}
            className={tab === option ? 'active' : ''} key={option}
            onClick={() => { setTab(option); setQuery(''); }}>
            {option === 'filters' ? <Tune fontSize="small" /> : option === 'customization' ? <Palette fontSize="small" /> : <AutoAwesome fontSize="small" />}
            <span>{option === 'fx' ? 'FX' : option === 'customization' ? 'Customize' : 'Filters'}</span>
          </button>
        ))}
      </div>
      {tab !== 'customization' && (
        <label className="fx-search">
          <Search fontSize="small" />
          <input type="search" placeholder={tab === 'fx' ? 'Find a creative preset…' : 'Find a filter…'}
            aria-label="Search FX library" value={query} onChange={event => setQuery(event.target.value)} />
        </label>
      )}
      <div className="fx-overlay-body">
        {!active && <div className="fx-notice">Select a layer to apply effects.</div>}
        {active?.locked && <div className="fx-notice">Unlock this layer to edit its appearance.</div>}
        {tab === 'filters' && (
          <div className="fx-filter-groups">
            {groups.map(group => {
              const visible = group.kinds.map(kind => FILTERS.find(item => item.kind === kind))
                .filter((filter): filter is typeof FILTERS[number] => Boolean(filter && matches(filter.label)));
              if (!visible.length) return null;
              return (
                <section key={group.label}>
                  <h3>{group.label}</h3>
                  <div className="fx-filter-grid">
                    {visible.map(filter => (
                      <button key={filter.kind} type="button" className="fx-filter-card"
                        disabled={!permitted} title={`Add ${filter.label} to the effect stack`}
                        onClick={() => active && state.addEffect(active.id, filter.kind)}>
                        <EffectIcon kind={filter.kind} className="fx-filter-mark" />
                        <EffectPreview kind={filter.kind} className="fx-filter-live-preview" />
                        <span>{filter.label}</span>
                        <b aria-hidden="true">＋</b>
                      </button>
                    ))}
                  </div>
                </section>
              );
            })}
            {!groups.some(group => group.kinds.some(kind => {
              const definition = FILTERS.find(item => item.kind === kind);
              return definition && matches(definition.label);
            })) && <p className="fx-empty">No matching filters.</p>}
          </div>
        )}
        {tab === 'customization' && (
          <div className="fx-customize">
            <h3>{activeShape ? 'Vector style' : 'Layer styling'}</h3>
            {activeShape && (
              <>
                <label className="fx-customize-row">
                  <span>Fill</span>
                  <BufferedColorPicker label="Object fill" value={activeShape.fill !== 'none' ? activeShape.fill : '#ffffff'}
                    onCommit={color => state.updateShape(activeShape.id, shape => { shape.fill = color; })} />
                </label>
                <label className="fx-customize-row">
                  <span>Stroke</span>
                  <BufferedColorPicker label="Object stroke" value={activeShape.stroke !== 'none' ? activeShape.stroke : '#000000'}
                    onCommit={color => state.updateShape(activeShape.id, shape => { shape.stroke = color; })} />
                </label>
                <label className="fx-customize-row"><span>Stroke width</span>
                  <input aria-label="Object stroke width" type="number" min={0} max={250}
                    value={activeShape.strokeWidth}
                    onChange={event => state.updateShape(activeShape.id, shape => {
                      shape.strokeWidth = Math.max(0, Math.min(250, Number(event.target.value) || 0));
                    })} />
                </label>
              </>
            )}
            {active && (
              <>
                <label className="fx-customize-row"><span>Blend mode</span>
                  <select aria-label="Layer blending" disabled={!permitted} value={active.blend}
                    onChange={event => state.setLayerBlend(active.id, event.target.value as BlendMode)}>
                    {blends.map(blend => <option key={blend.id} value={blend.id}>{blend.label}</option>)}
                  </select>
                </label>
                <label className="fx-customize-row"><span>Opacity</span>
                  <output>{Math.round(active.opacity * 100)}%</output>
                </label>
                <Slider size="small" disabled={!permitted} aria-label="Layer opacity"
                  min={0} max={100} value={Math.round(active.opacity * 100)}
                  onChangeCommitted={(_, value) => state.setLayerOpacity(active.id, (value as number) / 100)} />
                <div className="fx-quick-actions">
                  <Button size="small" disabled={!state.selection || !permitted}
                    onClick={() => state.applySelectionMask(active.id)}>Mask selection</Button>
                  <Button size="small" disabled={!active.mask || !permitted}
                    onClick={() => state.clearLayerMask(active.id)}>Clear mask</Button>
                </div>
              </>
            )}
            <p className="fx-subtle">These adjustments stay editable in your .spectrum project.</p>
          </div>
        )}
        {tab === 'fx' && (
          <div className="fx-presets">
            <h3>Signature effects</h3>
            <div className="fx-preset-grid">
              {Object.entries(FX_PRESETS).filter(([name]) => matches(name)).map(([name, preset]) => (
                <button type="button" className="fx-preset-card" disabled={!permitted} key={name}
                  onClick={() => active && state.appendEffects(active.id,
                    preset.map(effect => newEffect(effect.kind, effect.amount, effect.color, effect.parameters)))}>
                  <div className="fx-preset-visual"><EffectIcon kind={name} className="fx-preset-art" />
                    <EffectPreview preset={name} className="fx-preset-live-preview" /></div>
                  <strong>{name}</strong>
                  <small>{preset.length} adjustable effects</small>
                </button>
              ))}
            </div>
            {!Object.keys(FX_PRESETS).some(matches) && <p className="fx-empty">No matching FX presets.</p>}
          </div>
        )}
        <section className="fx-applied">
          <div className="fx-applied-heading"><h3>Applied effects</h3><span>{effects.length}</span></div>
          {effects.map((effect, index) => (
            <div className="fx-effect" key={effect.id}>
              <div className="fx-effect-title">
                <label>
                  <input aria-label={`Enable ${effect.kind}`} type="checkbox" checked={effect.enabled}
                    disabled={!permitted}
                    onChange={event => active && state.updateEffect(active.id, effect.id, { enabled: event.target.checked })} />
                  <strong>{FILTERS.find(item => item.kind === effect.kind)?.label ?? effect.kind}</strong>
                </label>
                <div className="fx-effect-actions">
                  <button type="button" aria-label={`Move ${effect.kind} earlier`} title="Move earlier"
                    disabled={!permitted || index === 0}
                    onClick={() => active && state.moveEffect(active.id, effect.id, -1)}>↑</button>
                  <button type="button" aria-label={`Move ${effect.kind} later`} title="Move later"
                    disabled={!permitted || index === effects.length - 1}
                    onClick={() => active && state.moveEffect(active.id, effect.id, 1)}>↓</button>
                  <button type="button" aria-label={`Remove ${effect.kind}`} title="Remove effect"
                    disabled={!permitted} onClick={() => active && state.removeEffect(active.id, effect.id)}>×</button>
                </div>
              </div>
              <EffectAmount effect={effect}
                onPreview={amount => preview(effect.id, { amount })}
                onCommit={commit} />
              <EffectAdvancedEditors effect={effect}
                preview={parameters => preview(effect.id, { parameters })}
                commit={commit} />
              {Boolean(EFFECT_PARAMETERS[effect.kind]?.length) && (
                <div className="fx-advanced-grid" aria-label={`${effect.kind} parameters`}>
                  {(EFFECT_PARAMETERS[effect.kind] ?? []).filter(control =>
                    !(effect.kind === 'glow' && control.key === 'threshold' && effect.parameters?.glowMode !== 'bloom') &&
                    !(effect.kind === 'backdrop' && control.key === 'angle' && effect.parameters?.backdropMode !== 'gradient')
                  ).map(control => (
                    <EffectScalarControl key={`${effect.id}-${control.key}`} effect={effect}
                      control={control} permitted={permitted}
                      preview={changes => preview(effect.id, changes)} commit={commit} />
                  ))}
                </div>
              )}
              {['glow', 'outline', 'backdrop', 'neonedge'].includes(effect.kind) && (
                <label className="fx-customize-row"><span>Color</span>
                  <PreviewColorInput label={`${effect.kind} color`} value={effect.color ?? '#986dff'}
                    onPreview={color => preview(effect.id, { color })}
                    onCommit={commit} />
                </label>
              )}
            </div>
          ))}
          {!effects.length && <p className="fx-subtle">Choose a filter or FX preset above. Nothing is baked into the original pixels.</p>}
        </section>
      </div>
      <div className="fx-overlay-footer">
        <button className="fx-compare" type="button" disabled={!active || !effects.length}
          title="Hold to see the selected layer without FX"
          onPointerDown={() => active && state.setFxBypassLayer(active.id)}
          onPointerUp={() => state.setFxBypassLayer(null)}
          onPointerCancel={() => state.setFxBypassLayer(null)}
          onPointerLeave={() => state.setFxBypassLayer(null)}
          onKeyDown={event => {
            if (event.key === ' ' || event.key === 'Enter') state.setFxBypassLayer(active?.id ?? null);
          }}
          onKeyUp={() => state.setFxBypassLayer(null)}
          onBlur={() => state.setFxBypassLayer(null)}>
          ◉ Hold to compare
        </button>
        <button type="button" onClick={onClose}>Done</button>
      </div>
    </div>
  );
}
