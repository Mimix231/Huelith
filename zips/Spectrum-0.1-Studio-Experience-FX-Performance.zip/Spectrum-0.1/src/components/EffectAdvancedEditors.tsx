import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import type { Effect, EffectParameters, GradientStop, CurvePoint, ShadowEntry } from '../editor/types';
import { DEFAULT_CURVE_POINTS, DEFAULT_DUOTONE_STOPS, DEFAULT_GRADIENT_STOPS, DEFAULT_SHADOWS } from '../editor/effect-schema';

interface EditorProps {
  effect: Effect;
  preview: (parameters: EffectParameters) => void;
  commit: () => void;
}

const hex = /^#[\da-f]{6}$/i;
const number = (value: number, min: number, max: number): number => Math.max(min, Math.min(max, Number.isFinite(value) ? value : min));

/** Swatches preview on a bounded schedule to keep native color-wheel drags responsive. */
export function PreviewColorInput({ value, label, onPreview, onCommit }: {
  value: string;
  label: string;
  onPreview: (color: string) => void;
  onCommit: () => void;
}) {
  const [draft, setDraft] = useState(value);
  const pending = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const latest = useRef(value);
  useEffect(() => setDraft(value), [value]);
  useEffect(() => () => clearTimeout(pending.current), []);
  const commit = (): void => {
    clearTimeout(pending.current);
    if (latest.current !== value) onPreview(latest.current);
    onCommit();
  };
  return (
    <input aria-label={label} title={label} type="color" value={hex.test(draft) ? draft : '#986dff'}
      onChange={event => {
        const color = event.target.value;
        latest.current = color;
        setDraft(color);
        clearTimeout(pending.current);
        pending.current = setTimeout(() => onPreview(color), 100);
      }}
      onPointerUp={commit} onBlur={commit} />
  );
}

function GradientEditor({ effect, preview, commit }: EditorProps) {
  const fallback = effect.kind === 'duotone' ? DEFAULT_DUOTONE_STOPS : DEFAULT_GRADIENT_STOPS;
  const stops = [...(effect.parameters?.stops ?? fallback)].sort((a, b) => a.position - b.position);
  const update = (updated: GradientStop[]): void => preview({ stops: updated });
  const gradient = `linear-gradient(90deg, ${stops.map(stop => `${stop.color} ${stop.position * 100}%`).join(', ')})`;
  return (
    <div className="fx-complex-editor" aria-label={`${effect.kind} gradient editor`}>
      <div className="fx-complex-header"><strong>Editable color stops</strong>
        <button type="button" disabled={stops.length >= 16} onClick={() => {
          const middle = stops[Math.floor(stops.length / 2)];
          update([...stops, { id: crypto.randomUUID(), position: Math.max(0, middle.position - 0.07), color: middle.color, opacity: 1 }]);
          commit();
        }}>+ Stop</button>
      </div>
      <div className="fx-gradient-preview" style={{ background: gradient }} aria-label="Gradient preview" />
      {stops.map(stop => (
        <div className="fx-gradient-stop" key={stop.id}>
          <PreviewColorInput label={`Stop ${Math.round(stop.position * 100)}% color`} value={stop.color}
            onPreview={color => update(stops.map(item => item.id === stop.id ? { ...item, color } : item))} onCommit={commit} />
          <label><span>Position</span><input type="range" min={0} max={100} step={1} value={stop.position * 100}
            aria-label="Stop position" onChange={event => update(stops.map(item => item.id === stop.id
              ? { ...item, position: number(Number(event.target.value), 0, 100) / 100 } : item))}
            onPointerUp={commit} onKeyUp={commit} /></label>
          <output>{Math.round(stop.position * 100)}%</output>
          <button type="button" disabled={stops.length <= 2} aria-label="Remove gradient stop" onClick={() => {
            update(stops.filter(item => item.id !== stop.id)); commit();
          }}>×</button>
        </div>
      ))}
      <p className="fx-subtle">Dark pixels use the left colors; highlights use the right colors. Image transparency is preserved.</p>
    </div>
  );
}

function CurveEditor({ effect, preview, commit }: EditorProps) {
  const points = [...(effect.parameters?.curvePoints ?? DEFAULT_CURVE_POINTS)].sort((a, b) => a.x - b.x);
  const update = (result: CurvePoint[]): void => preview({ curvePoints: result });
  const svg = useRef<SVGSVGElement>(null);
  const dragging = useRef<number | null>(null);
  const path = points.map(({ x, y }) => `${(x * 180).toFixed(2)},${((1 - y) * 180).toFixed(2)}`).join(' ');
  const pointer = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (dragging.current === null || !svg.current) return;
    const bounds = svg.current.getBoundingClientRect();
    const index = dragging.current;
    const x = number((event.clientX - bounds.left) / bounds.width, 0, 1);
    const y = 1 - number((event.clientY - bounds.top) / bounds.height, 0, 1);
    update(points.map((point, i) => i === index ? {
      x: index === 0 || index === points.length - 1 ? point.x
        : number(x, (points[index - 1]?.x ?? 0) + 0.002, (points[index + 1]?.x ?? 1) - 0.002),
      y,
    } : point));
  };
  return (
    <div className="fx-complex-editor">
      <div className="fx-complex-header"><strong>Tonal curve</strong>
        <button type="button" disabled={points.length >= 12} onClick={() => {
          update([...points, { x: 0.5, y: 0.5 }].sort((a, b) => a.x - b.x)); commit();
        }}>+ Point</button>
      </div>
      <svg ref={svg} className="fx-curve" viewBox="0 0 180 180" role="group" aria-label="Editable tonal curve"
        onPointerMove={pointer} onPointerUp={event => { if (dragging.current !== null) { dragging.current = null; event.currentTarget.releasePointerCapture(event.pointerId); commit(); } }}
        onPointerCancel={() => { dragging.current = null; commit(); }}>
        <path d="M0 45 H180 M0 90 H180 M0 135 H180 M45 0 V180 M90 0 V180 M135 0 V180" fill="none" stroke="currentColor" opacity=".15" />
        <path d="M0 180 L180 0" fill="none" stroke="currentColor" opacity=".23" />
        <polyline points={path} fill="none" stroke="var(--accent, #9875ff)" strokeWidth="2.5" />
        {points.map((point, index) => <circle key={`${index}`} cx={point.x * 180} cy={(1 - point.y) * 180}
          r="5" fill="var(--accent, #9875ff)" stroke="white" strokeWidth="1.5" style={{ cursor: 'move' }}
          onPointerDown={event => {
            dragging.current = index;
            svg.current?.setPointerCapture(event.pointerId);
            event.stopPropagation();
          }} />)}
      </svg>
      {points.map((point, index) => <div className="fx-curve-numeric" key={`${index}`}>
        <span>P{index + 1}</span>
        <label>X <input aria-label={`Curve point ${index + 1} X`} type="number" min={0} max={100}
          value={Math.round(point.x * 100)} disabled={index === 0 || index === points.length - 1}
          onChange={event => update(points.map((item, i) => i === index ? { ...item, x: Number(event.target.value) / 100 } : item))} onBlur={commit} /></label>
        <label>Y <input aria-label={`Curve point ${index + 1} Y`} type="number" min={0} max={100}
          value={Math.round(point.y * 100)}
          onChange={event => update(points.map((item, i) => i === index ? { ...item, y: number(Number(event.target.value) / 100, 0, 1) } : item))} onBlur={commit} /></label>
        <button type="button" disabled={index === 0 || index === points.length - 1 || points.length <= 2}
          aria-label={`Remove curve point ${index + 1}`} onClick={() => { update(points.filter((_, i) => i !== index)); commit(); }}>×</button>
      </div>)}
    </div>
  );
}

function ShadowEditor({ effect, preview, commit }: EditorProps) {
  const shadows = effect.parameters?.shadows ?? DEFAULT_SHADOWS;
  const update = (entries: ShadowEntry[]): void => preview({ shadows: entries });
  return (
    <div className="fx-complex-editor">
      <div className="fx-complex-header"><strong>Shadow stack</strong><button type="button" disabled={shadows.length >= 8}
        onClick={() => { update([...shadows, { ...DEFAULT_SHADOWS[0], id: crypto.randomUUID() }]); commit(); }}>+ Shadow</button></div>
      {shadows.map((entry, index) => <div className="fx-shadow-entry" key={entry.id}>
        <div className="fx-complex-header"><label><input type="checkbox" checked={entry.enabled} onChange={event => {
          update(shadows.map(shadow => shadow.id === entry.id ? { ...shadow, enabled: event.target.checked } : shadow)); commit();
        }} /> Shadow {index + 1}</label><button type="button" aria-label="Remove shadow" onClick={() => {
          update(shadows.filter(item => item.id !== entry.id)); commit();
        }}>×</button></div>
        <label className="fx-customize-row"><span>Shadow style</span>
          <select aria-label={`Shadow ${index + 1} style`} value={entry.style ?? 'drop'}
            onChange={event => {
              update(shadows.map(item => item.id === entry.id ? {
                ...item, style: event.target.value as NonNullable<ShadowEntry['style']>,
              } : item));
              commit();
            }}>
            <option value="drop">Drop shadow</option>
            <option value="inner">Inner shadow</option>
            <option value="contact">Contact shadow</option>
            <option value="long">Long shadow</option>
          </select>
        </label>
        <PreviewColorInput label={`Shadow ${index + 1} color`} value={entry.color} onPreview={color =>
          update(shadows.map(item => item.id === entry.id ? { ...item, color } : item))} onCommit={commit} />
        {(['offsetX', 'offsetY', 'radius', 'spread', 'opacity'] as const).map(key => <label key={key} className="fx-level">
          <span>{key} <output>{key === 'opacity' ? Math.round(entry[key] * 100) : Math.round(entry[key])}</output></span>
          <input type="range" aria-label={`Shadow ${index + 1} ${key}`} min={key === 'offsetX' || key === 'offsetY' ? -250 : 0}
            max={key === 'opacity' ? 100 : 200}
            value={key === 'opacity' ? entry[key] * 100 : entry[key]}
            onChange={event => update(shadows.map(shadow => shadow.id === entry.id ? {
              ...shadow, [key]: key === 'opacity' ? Number(event.target.value) / 100 : Number(event.target.value),
            } : shadow))} onPointerUp={commit} onKeyUp={commit} />
        </label>)}
      </div>)}
    </div>
  );
}

function GlowEditor({ effect, preview, commit }: EditorProps) {
  return <div className="fx-complex-editor">
    <div className="fx-complex-header"><strong>Light behavior</strong><span>Non-destructive</span></div>
    <label className="fx-customize-row"><span>Illumination type</span>
      <select aria-label="Glow mode" value={effect.parameters?.glowMode ?? 'outer'}
        onChange={event => {
          preview({ glowMode: event.target.value as NonNullable<EffectParameters['glowMode']> });
          commit();
        }}>
        <option value="outer">Outer glow — silhouette</option>
        <option value="inner">Inner glow — edge lighting</option>
        <option value="both">Inner + outer glow</option>
        <option value="bloom">Bloom — luminous highlights</option>
      </select>
    </label>
    <p className="fx-subtle">Outer/inner glow follows transparency. Bloom responds to bright pixels.</p>
  </div>;
}

function BackdropEditor(props: EditorProps) {
  const mode = props.effect.parameters?.backdropMode ?? 'solid';
  return <div className="fx-complex-editor">
    <div className="fx-complex-header"><strong>Backdrop fill</strong></div>
    <label className="fx-customize-row"><span>Fill type</span>
      <select aria-label="Backdrop fill mode" value={mode}
        onChange={event => {
          props.preview({ backdropMode: event.target.value as NonNullable<EffectParameters['backdropMode']> });
          props.commit();
        }}>
        <option value="solid">Solid color</option>
        <option value="gradient">Editable gradient</option>
      </select>
    </label>
    {mode === 'gradient' && <GradientEditor {...props} />}
    <p className="fx-subtle">X, Y, scale, angle, opacity and blur are in the controls below. Artwork stays in front.</p>
  </div>;
}

export default function EffectAdvancedEditors(props: EditorProps) {
  if (props.effect.kind === 'gradientmap' || props.effect.kind === 'duotone') return <GradientEditor {...props} />;
  if (props.effect.kind === 'curves') return <CurveEditor {...props} />;
  if (props.effect.kind === 'shadow') return <ShadowEditor {...props} />;
  if (props.effect.kind === 'glow') return <GlowEditor {...props} />;
  if (props.effect.kind === 'backdrop') return <BackdropEditor {...props} />;
  return null;
}
