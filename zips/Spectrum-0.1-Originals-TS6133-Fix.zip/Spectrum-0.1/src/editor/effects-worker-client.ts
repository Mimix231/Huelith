import { setAsyncEffectsProcessor, type AsyncEffectsProcessor } from './fx';
import type { Effect } from './types';

type Job = {
  id: number;
  layer: string;
  canvas: HTMLCanvasElement;
  effects: Effect[];
  complete: (image: ImageBitmap) => void;
};

/** Latest-wins queue: no backlog of obsolete slider values can accumulate. */
export function installEffectsWorker(): () => void {
  if (typeof Worker === 'undefined' || typeof OffscreenCanvas === 'undefined' ||
    typeof createImageBitmap === 'undefined') return () => {};
  let worker: Worker;
  try {
    worker = new Worker(new URL('./effects-worker.ts', import.meta.url), { type: 'module' });
  } catch {
    return () => {};
  }
  let nextId = 1;
  let running: Job | null = null;
  let latest = new Map<string, Job>();
  let disposed = false;

  async function dispatch(): Promise<void> {
    if (disposed || running || !latest.size) return;
    // Process only the latest submission for each layer; cap the queue size.
    const job = latest.values().next().value as Job;
    latest.delete(job.layer);
    running = job;
    try {
      const bitmap = await createImageBitmap(job.canvas);
      if (disposed) { bitmap.close(); running = null; return; }
      worker.postMessage({ id: job.id, bitmap, effects: job.effects }, [bitmap]);
    } catch {
      running = null;
      // A failed worker submission must not create an infinite repaint loop.
      dispatch();
    }
  }

  worker.onmessage = (event: MessageEvent<{ id: number; result?: ImageBitmap; error?: string }>) => {
    const finished = running;
    running = null;
    if (disposed || !finished) { event.data.result?.close(); return; }
    if (event.data.error) {
      // Fall back to the tested synchronous renderer after a worker failure.
      disposed = true;
      latest.clear();
      worker.terminate();
      setAsyncEffectsProcessor(null);
      window.dispatchEvent(new Event('spectrum-worker-fallback'));
      return;
    }
    if (event.data.result) {
      // Only accept a completed preview if no newer parameters are waiting.
      if (latest.has(finished.layer)) event.data.result.close();
      else finished.complete(event.data.result);
    }
    void dispatch();
  };
  worker.onerror = () => {
    disposed = true;
    latest.clear();
    running = null;
    setAsyncEffectsProcessor(null);
    worker.terminate();
    window.dispatchEvent(new Event('spectrum-worker-fallback'));
  };

  const process: AsyncEffectsProcessor = (canvas, effects, layer, complete) => {
    if (disposed) return false;
    latest.set(layer, { id: nextId++, layer, canvas, effects: structuredClone([...effects]), complete });
    // Queue retains at most a handful of layers, regardless of slider cadence.
    if (latest.size > 12) latest.delete(latest.keys().next().value as string);
    void dispatch();
    return true;
  };
  setAsyncEffectsProcessor(process);
  return () => {
    disposed = true;
    latest.clear();
    worker.terminate();
    setAsyncEffectsProcessor(null);
  };
}
