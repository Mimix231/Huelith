import { processEffects } from './fx';
import { createSurface } from './canvas-surface';
import type { Effect } from './types';

/** OffscreenCanvas processing is kept off the React input/event thread. */
const worker = self as unknown as {
  onmessage: ((event: MessageEvent<{
    id: number;
    bitmap: ImageBitmap;
    effects: Effect[];
  }>) => void) | null;
  postMessage: (message: unknown, transfer?: Transferable[]) => void;
};
worker.onmessage = event => {
  const { id, bitmap, effects } = event.data;
  try {
    const canvas = createSurface();
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Worker Canvas2D context could not be created.');
    context.drawImage(bitmap, 0, 0);
    bitmap.close();
    const finished = processEffects(canvas, effects);
    const result = (finished as unknown as OffscreenCanvas).transferToImageBitmap();
    worker.postMessage({ id, result }, [result]);
  } catch (error) {
    bitmap.close();
    worker.postMessage({ id, error: error instanceof Error ? error.message : String(error) });
  }
};
