# Huelith: native Rust conversion — progress package

**29 October 2026**

This folder contains a new **native Rust editor prototype**, plus the **original Huelith 0.2 source archive, unmodified**. It is not a completed one-go conversion of the 589-file source tree. Such a claim would be inaccurate.

- `native/`: Rust project (`huelith-core`, `huelith-effects`, `huelith-app`). Run from here with `cargo run --release -p huelith-native` on a machine with Rust and graphics drivers.
- `Legacy_Huelith_0.2_Source_Unmodified.zip`: previous working TypeScript/Tauri project preserved intact for reference and rollback.
- `Huelith_221_Effects_Rust_Migration_Status_2026-10-29.md`: every effect and its honest migration status.
- `native/README.md`: exact working scope, limitations, build steps, and test constraints.

## Verified in the current environment

- Static audit of the 221-effect catalog and 29 native effect dispatch IDs: **passed**.
- Rust compiler, Cargo tests, eframe Windows launch, PNG exports, performance numbers: **NOT verified**; Rust toolchain is unavailable here.
- Complete effect, animation, gradient, vector, text, masked layers, and Originals feature parity: **NOT implemented**.

**Important:** Edit *copies* of old `.huelith` files with the native prototype until round-trip compatibility is validated on diverse projects. A saved JSON structure can be preserved while its artistic rendering still differs.
