# Huelith Native — Rust migration, initial implementation (29 October 2026)

> **STATUS: INCOMPLETE MIGRATION.** The original 0.2-alpha editor is **not** converted in full. This deliverable is a separate native Rust application and crates, with an exhaustive 221-operation catalog, 29 native effect processors, and basic native editing. **It is not a replacement release.**

## What has actually been implemented

- Native Windows/Linux/macOS app source using **Rust + eframe/egui with a wgpu-rendered UI**, not React, TypeScript, Tauri or a webview. The renderer for the 29 processing operations is **CPU/Rayon**, not GPU compute.
- User-selected raster import, pixel painting/erasing, basic undo snapshots, preview, and PNG export.
- `.huelith`/`.spectrum` version-1 JSON document loading and conservative saving that retains fields the native app does not understand. Existing complex documents may not render correctly; only the selected raster layer is drawn.
- Effects catalog: all **221 names and IDs**, sourced from the supplied audit. Unported effects are **disabled** in the native catalog; legacy effect slots are preserved and explicitly flagged as omitted from preview, never replaced by generic math.
- **29 independently dispatched native CPU operations** (see `crates/huelith-effects/src/lib.rs`); full-resolution preview calculations are performed on a worker, using latest-wins scheduling so slider input isn't gated by filter completion.
- Unit-test source for catalog completeness, document round-trip, zero amount, pixel sorting, and runnable supported kinds.

## Not yet migrated (important)

- 192 of the 221 catalog operations; the 29 ported operations still need artist-reviewed visual certification.
- Full layer-stack compositing, vector editing, gradient Atelier, typography, masks, Cutout, Originals, animation timeline and export, advanced brush styles, the existing theme families, rich effect parameters and presets.
- Native GPU compute for image filters; eframe uses the GPU for *display*, while the effect-processing worker is CPU-based.
- Accurate export of complex legacy documents. PNG export refuses to continue if an active effect is unsupported; it is also limited to the selected raster layer.
- All-platform build testing, end-to-end user interaction testing, package/installers, performance benchmarks, and backward-compatible editability of every historical parameter.

## Build and run on Windows

1. Install the stable Rust toolchain and Microsoft C++ Build Tools (MSVC).
2. Open PowerShell in the `native` directory.
3. `cargo test --workspace`
4. `cargo run --release -p huelith-native`

Dependencies are downloaded by Cargo. `wgpu` needs a functioning graphics backend. For older PCs without dedicated graphics hardware, support depends on whether the system provides a software-capable compatible graphics backend; this build has **no guaranteed fully CPU-only UI fallback yet**.

The environment that prepared this migration had **no `cargo` or `rustc` installed and no external network access**. Consequently, the native application **could not be compiled or executed here**. Source-level and data-consistency checks are included in `tools/validate_migration.py` and were run, but **they do not substitute for `cargo check`, `cargo test`, native smoke tests, or real artwork verification.**

## Architecture

```text
native/
  crates/huelith-core/      # Lossless-ish version-1 JSON model; 221 names/IDs
  crates/huelith-effects/   # Independent Rayon effect functions; NOT expansion-120.ts
  crates/huelith-app/       # Native egui/eframe editor, paint, project IO, effect worker
  tools/                    # Migration data validation
```

The model is intentionally based on `serde_json::Value` to retain unknown project fields. However, the current `set_selected_effects` method can still reorder or discard effects intentionally deleted through the UI, and externally generated resources may remain unresolved. **Always work on copies of original projects.**

## Design rule

**A catalog ID is not an implemented feature.** A listed effect is counted as ported only when a distinct native processing routine is dispatched. Ported also does **not** mean visually complete. There is **no `expansion-120.ts`-equivalent fake-effects switch** in this Rust renderer.
