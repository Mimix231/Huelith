#!/usr/bin/env python3
"""Static schema/coverage checks: NOT a Rust build or behavioral test."""
import json, re, tomllib
from collections import Counter
from pathlib import Path
root = Path(__file__).resolve().parents[1]
manifest = tomllib.loads((root / 'Cargo.toml').read_text())
assert len(manifest['workspace']['members']) == 3
entries = json.loads((root/'crates/huelith-core/assets/effects.json').read_text())
assert len(entries) == 221, f"Expected 221 entries, found {len(entries)}"
ids = [e['id'] for e in entries]
assert len(set(ids)) == 221, 'Duplicate IDs'
assert all(e['name'] and e['category'] and e['intended'] for e in entries)
source = (root/'crates/huelith-effects/src/lib.rs').read_text()
impl_list = re.search(r'pub const PORTED:.*?= &\[(.*?)\];', source, re.S)
assert impl_list, 'PORTED list not found'
ported = re.findall(r'"([\w_]+)"', impl_list.group(1))
assert len(ported) == 29, (len(ported), ported)
assert len(set(ported)) == len(ported)
assert set(ported) <= set(ids), set(ported)-set(ids)
for effect_id in ported:
    assert f'"{effect_id}"' in source.split('pub fn apply(')[1], f'{effect_id} missing from dispatcher'
assert 'if !supported(&fx.kind)' in source
assert 'fn zero_amount_is_identity' in source
print(f'STATIC CHECK PASS: {len(entries)} known effects, {len(ported)} native handlers, {len(entries)-len(ported)} unported')
print('Categories:', dict(Counter(item['category'] for item in entries)))
print('NOT VERIFIED: Rust compilation, runtime functionality, UI fidelity, Windows builds, performance')
