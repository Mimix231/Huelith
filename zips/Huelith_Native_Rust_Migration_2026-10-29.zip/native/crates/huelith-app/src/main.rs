//! Native Rust Huelith proof of migration. This is NOT the feature-parity editor.
//! UI: egui/eframe (wgpu backend); editing, document model, worker and effect
//! algorithms: Rust. Unported operations are always labeled as such.
use eframe::egui::{self, Color32, Context, Pos2, TextureHandle, TextureOptions, Vec2};
use huelith_core::{catalog, CatalogEntry, Document, EffectSlot};
use huelith_effects::{render_stack, supported};
use image::{Rgba, RgbaImage};
use std::{
    path::PathBuf,
    sync::{atomic::{AtomicU64, Ordering}, mpsc::{self, Receiver}, Arc, Condvar, Mutex},
    thread,
};

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        renderer: eframe::Renderer::Wgpu,
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1536.0, 940.0])
            .with_title("Huelith Native — Rust migration prototype"),
        ..Default::default()
    };
    eframe::run_native("Huelith Native", options,
        Box::new(|cc| Ok(Box::new(NativeApp::new(&cc.egui_ctx)))))
}

struct Request { revision: u64, source: Arc<RgbaImage>, effects: Vec<EffectSlot> }
struct FrameOutput { revision: u64, image: RgbaImage, unsupported: Vec<String> }

struct RenderWorker {
    pending: Arc<(Mutex<Option<Request>>, Condvar)>,
    revision: Arc<AtomicU64>,
    completed: Receiver<FrameOutput>,
}
impl RenderWorker {
    fn new(context: Context) -> Self {
        let pending: Arc<(Mutex<Option<Request>>, Condvar)> = Arc::new((Mutex::new(None), Condvar::new()));
        let revision = Arc::new(AtomicU64::new(0));
        let (tx, completed) = mpsc::channel();
        let task=Arc::clone(&pending); let current=Arc::clone(&revision);
        thread::Builder::new().name("huelith-effect-renderer".into()).spawn(move||{
            loop {
                let request = {
                    let (lock, cv)= &*task;
                    let mut slot=lock.lock().unwrap();
                    while slot.is_none() {slot=cv.wait(slot).unwrap();}
                    slot.take().unwrap()
                };
                // Never fake an effect: only pass implemented native algorithms.
                // The UI explicitly lists unported effects excluded from preview.
                let unsupported:Vec<String>=request.effects.iter().filter(|e|e.enabled&&e.amount>0.0&&!supported(&e.kind))
                    .map(|e|e.kind.clone()).collect();
                let active=request.effects.iter().filter(|e|supported(&e.kind)).cloned().collect::<Vec<_>>();
                let outdated=||current.load(Ordering::Acquire)!=request.revision;
                if let Ok(Some(image))=render_stack(&request.source,&active,outdated){
                    if !outdated() && tx.send(FrameOutput {revision:request.revision,image,unsupported}).is_ok() {
                        context.request_repaint();
                    }
                }
            }
        }).expect("Render worker can start");
        Self{pending,revision,completed}
    }
    fn submit(&self,source:Arc<RgbaImage>,effects:Vec<EffectSlot>){
        let revision=self.revision.fetch_add(1,Ordering::AcqRel)+1;
        let (lock,cv)= &*self.pending;
        *lock.lock().unwrap()=Some(Request{revision,source,effects});
        cv.notify_one();
    }
}

#[derive(Clone,Copy,PartialEq,Eq)]
enum PaintTool { Brush, Eraser }

struct NativeApp {
    document: Document,
    source: Arc<RgbaImage>,
    rendered: Option<RgbaImage>,
    texture: Option<TextureHandle>,
    layers: Vec<EffectSlot>,
    worker: RenderWorker,
    catalog: Vec<CatalogEntry>,
    search: String,
    selected_effect: Option<usize>,
    status: String,
    preview_warnings: Vec<String>,
    current_file: Option<PathBuf>,
    dirty: bool,
    selected_tool: PaintTool,
    brush_size: f32,
    brush_color: Color32,
    previous_drag_point: Option<(i32,i32)>,
    snapshots: Vec<Arc<RgbaImage>>,
    layer_load_error: Option<String>,
    frame_count: u64,
}

impl NativeApp {
    fn new(ctx:&Context)->Self{
        let document=Document::new(960,640).expect("valid dimensions");
        let mut background=RgbaImage::new(960,640);
        for p in background.pixels_mut(){*p=Rgba([255,255,255,255]);}
        let source=Arc::new(background);
        let worker=RenderWorker::new(ctx.clone());
        worker.submit(Arc::clone(&source),vec![]);
        let mut visuals=egui::Visuals::dark();
        visuals.panel_fill=Color32::from_rgb(20,20,33);
        visuals.window_fill=Color32::from_rgb(30,29,49);
        ctx.set_visuals(visuals);
        Self {document,source,rendered:None,texture:None,layers:vec![],worker,
            catalog:catalog(),search:String::new(),selected_effect:None,
            status:"Native editor initialized — 221 catalog entries; only explicitly ported ones are functional".into(),
            preview_warnings:vec![],current_file:None,dirty:false,
            selected_tool:PaintTool::Brush,brush_size:12.0,brush_color:Color32::from_rgb(175,135,252),
            previous_drag_point:None,snapshots:vec![],layer_load_error:None,frame_count:0}
    }
    fn queue(&mut self) { self.worker.submit(Arc::clone(&self.source),self.layers.clone()); }

    fn open_document(&mut self){
        let Some(path)=rfd::FileDialog::new().add_filter("Huelith/Spectrum",&["huelith","spectrum","json"]).pick_file() else{return};
        match Document::read(&path) {
            Ok(doc)=> {
                let image=doc.selected_raster();
                self.layers=doc.selected_effects(); self.document=doc;
                self.current_file=Some(path);self.dirty=false;self.snapshots.clear();
                match image {
                    Ok(img)=>{self.source=Arc::new(img);self.layer_load_error=None;self.queue();
                        self.status="Document opened; unsupported document features preserved in JSON".into();},
                    Err(err)=>{self.layer_load_error=Some(err.clone());
                        self.source=Arc::new(RgbaImage::new(self.document.width(),self.document.height()));
                        self.queue();self.status=format!("Layer preview unavailable: {err}");}
                }
            }, Err(err)=>self.status=format!("Could not open project: {err}")
        }
    }
    fn import_image(&mut self){
        let Some(path)=rfd::FileDialog::new().add_filter("Image",&["png","jpg","jpeg","webp","gif"]).pick_file() else{return};
        match image::open(&path){
            Ok(img)=>{
                let rgba=img.to_rgba8();
                match Document::new(rgba.width(),rgba.height()){
                    Ok(mut doc)=>{
                        doc.data["name"]=serde_json::json!(path.file_stem().and_then(|s|s.to_str()).unwrap_or("Untitled"));
                        self.source=Arc::new(rgba);self.document=doc;self.layers.clear();self.current_file=None;
                        self.layer_load_error=None;self.dirty=true;self.snapshots.clear();self.queue();
                        self.status="Image imported into a native raster layer".into();
                    },Err(err)=>self.status=err,
                }
            },Err(err)=>self.status=format!("Cannot open image: {err}")
        }
    }
    fn select_layer(&mut self,id:&str){
        if self.document.selected_id()==id {return;}
        if self.layer_load_error.is_none() {
            if let Err(e)=self.document.set_selected_raster(&self.source)
                .and_then(|_|self.document.set_selected_effects(&self.layers)) {
                self.status=format!("Cannot persist current raster before selection: {e}");
                return;
            }
        }
        self.document.set_selected(id);
        self.layers=self.document.selected_effects();
        match self.document.selected_raster(){
            Ok(img)=>{self.source=Arc::new(img);self.layer_load_error=None;
                self.status="Selected raster layer".into();},
            Err(e)=>{self.layer_load_error=Some(e.clone());
                self.source=Arc::new(RgbaImage::new(self.document.width(),self.document.height()));
                self.status=format!("Layer is not natively renderable: {e}");}
        }
        self.selected_effect=None;
        self.queue();
    }
    fn save_project(&mut self,save_as:bool){
        let path=if save_as || self.current_file.is_none(){
            rfd::FileDialog::new().set_file_name("untitled.huelith").add_filter("Huelith",&["huelith"]).save_file()
        }else{self.current_file.clone()};
        let Some(path)=path else{return};
        let result=(if self.layer_load_error.is_none() {
            self.document.set_selected_raster(&self.source)
                .and_then(|_|self.document.set_selected_effects(&self.layers))
        }else{Ok(())}).and_then(|_|self.document.write(&path));
        match result{Ok(())=>{self.current_file=Some(path);self.dirty=false;self.status="Native project saved; unknown legacy fields retained".into()},
            Err(err)=>self.status=format!("Save failed: {err}")}
    }
    fn export_png(&mut self){
        let Some(path)=rfd::FileDialog::new().set_file_name("huelith-preview.png").add_filter("PNG",&["png"]).save_file() else{return};
        if self.layer_load_error.is_some(){self.status="Export blocked: selected layer is not a native raster".into();return;}
        let unsupported:Vec<_>=self.layers.iter().filter(|e|e.enabled&&e.amount>0.0&&!supported(&e.kind)).collect();
        if !unsupported.is_empty(){self.status=format!("Export BLOCKED: {} unported effects; refusing silent loss of appearance",unsupported.len());return;}
        match render_stack(&self.source,&self.layers,||false){
            Ok(Some(img))=>match img.save(path){Ok(())=>self.status="Native raster preview exported as PNG".into(),
                Err(e)=>self.status=format!("PNG export failed: {e}")},
            Ok(None)=>self.status="Export canceled".into(),Err(e)=>self.status=e,
        }
    }
    fn add_effect(&mut self,kind:&str){
        if !supported(kind){self.status=format!("{} is in the catalog but not ported. No placeholder added.",kind);return;}
        self.layers.push(EffectSlot{kind:kind.to_owned(),amount:50.0,enabled:true,color:None});
        self.selected_effect=Some(self.layers.len()-1);self.dirty=true;self.queue();
    }
    fn record_undo(&mut self){self.snapshots.push(Arc::clone(&self.source));if self.snapshots.len()>12{self.snapshots.remove(0);}}
    fn undo(&mut self){if let Some(before)=self.snapshots.pop(){self.source=before;self.dirty=true;self.queue();}}
    fn paint(&mut self,from:(i32,i32),to:(i32,i32)){
        if self.layer_load_error.is_some() {return;}
        let paint=Arc::make_mut(&mut self.source);
        let distance=((to.0-from.0).pow(2)+(to.1-from.1).pow(2)) as f32;
        let steps=(distance.sqrt()*2.0).ceil().max(1.0) as i32;
        for n in 0..=steps {
            let t=n as f32/steps as f32;
            let x=(from.0 as f32+(to.0-from.0) as f32*t).round() as i32;
            let y=(from.1 as f32+(to.1-from.1) as f32*t).round() as i32;
            let radius=self.brush_size.max(1.0)*.5;
            let r=radius.ceil() as i32;
            for yy in (y-r)..=(y+r){for xx in (x-r)..=(x+r){
                if xx<0||yy<0||xx>=paint.width() as i32||yy>=paint.height() as i32{continue;}
                let dx=xx-x;let dy=yy-y;
                if (dx*dx+dy*dy) as f32 > radius*radius {continue;}
                let color=if self.selected_tool==PaintTool::Eraser {Rgba([0,0,0,0])}
                    else {Rgba([self.brush_color.r(),self.brush_color.g(),self.brush_color.b(),255])};
                paint.put_pixel(xx as u32, yy as u32,color);
            }}
        }
        self.dirty=true;self.queue();
    }
    fn consume_results(&mut self,ctx:&Context){
        let revision=self.worker.revision.load(Ordering::Acquire);
        while let Ok(frame)=self.worker.completed.try_recv(){
            if frame.revision!=revision {continue;}
            self.preview_warnings=frame.unsupported;
            let dimensions=[frame.image.width() as usize,frame.image.height() as usize];
            let color=egui::ColorImage::from_rgba_unmultiplied(dimensions,frame.image.as_raw());
            if let Some(texture)=self.texture.as_mut(){texture.set(color,TextureOptions::LINEAR);}
            else {self.texture=Some(ctx.load_texture("huelith-live-canvas",color,TextureOptions::LINEAR));}
            self.rendered=Some(frame.image);
            self.frame_count+=1;
        }
    }
}

impl eframe::App for NativeApp {
    fn update(&mut self,ctx:&Context,_frame:&mut eframe::Frame){
        self.consume_results(ctx);
        if ctx.input(|i|i.modifiers.command && i.key_pressed(egui::Key::Z)){self.undo();}
        egui::TopBottomPanel::top("main-toolbar").show(ctx,|ui|{
            ui.horizontal_wrapped(|ui|{
                ui.heading(egui::RichText::new("◐ Huelith").color(Color32::from_rgb(189,165,255)));
                ui.label("0.2 · NATIVE RUST MIGRATION");
                ui.separator();
                if ui.button("Open project").clicked(){self.open_document();}
                if ui.button("Import image").clicked(){self.import_image();}
                if ui.button("Save").clicked(){self.save_project(false);}
                if ui.button("Save as…").clicked(){self.save_project(true);}
                if ui.button("Export raster PNG").clicked(){self.export_png();}
                ui.separator();
                if ui.button("Undo").clicked(){self.undo();}
                if self.dirty {ui.colored_label(Color32::YELLOW,"● Unsaved");}
            });
        });
        egui::SidePanel::left("toolbox").resizable(false).default_width(145.0).show(ctx,|ui|{
            ui.heading("TOOLS");
            ui.selectable_value(&mut self.selected_tool,PaintTool::Brush,"✎ Brush");
            ui.selectable_value(&mut self.selected_tool,PaintTool::Eraser,"◻ Eraser");
            ui.add(egui::Slider::new(&mut self.brush_size,1.0..=150.0).text("Size"));
            ui.color_edit_button_srgba(&mut self.brush_color);
            ui.separator();
            ui.label(egui::RichText::new("LAYERS").strong());
            let selections=self.document.layers();
            let mut selected=None;
            egui::ScrollArea::vertical().max_height(250.0).show(ui,|ui|{
                for layer in selections {
                    let highlighted=self.document.selected_id()==layer.id;
                    let title=format!("{} · {}{}",layer.name,layer.kind,if layer.visible{""}else{" (hidden)"});
                    if ui.selectable_label(highlighted,title).clicked(){selected=Some(layer.id.clone());}
                }
            });
            if let Some(id)=selected {self.select_layer(&id);}
            ui.separator();
            ui.label(egui::RichText::new("Native editing").strong());
            ui.small("Continuous pointer strokes, active raster layer, native worker rendering.");
            ui.separator();
            ui.label(egui::RichText::new("Migration notice").color(Color32::LIGHT_YELLOW));
            ui.small("Vector, timeline, gradients, masks, Originals, complex blending and full-layer compositing are not yet ported.");
        });
        egui::SidePanel::right("effects-panel").min_width(310.0).default_width(345.0).show(ctx,|ui|{
            ui.heading("Effect Studio · Rust");
            ui.small(format!("{} / 221 effects have native processors",huelith_effects::PORTED.len()));
            ui.separator();
            ui.label("Applied on selected raster layer");
            let mut refresh=false;
            let mut delete=None;
            for (i,fx) in self.layers.iter_mut().enumerate(){
                ui.horizontal(|ui|{
                    if ui.checkbox(&mut fx.enabled,"").changed(){refresh=true;}
                    let label=self.catalog.iter().find(|x|x.id==fx.kind).map(|e|e.name.as_str()).unwrap_or(fx.kind.as_str());
                    if ui.selectable_label(self.selected_effect==Some(i),label).clicked(){self.selected_effect=Some(i);}
                    if !supported(&fx.kind){ui.colored_label(Color32::LIGHT_RED,"UNPORTED");}
                    if ui.small_button("×").clicked(){delete=Some(i);}
                });
            }
            if let Some(i)=delete{self.layers.remove(i);self.selected_effect=None;refresh=true;self.dirty=true;}
            if let Some(i)=self.selected_effect{
                if let Some(fx)=self.layers.get_mut(i){
                    ui.separator();
                    let change=ui.add(egui::Slider::new(&mut fx.amount,0.0..=100.0)
                        .text("Amount").suffix("%"));
                    if change.changed(){refresh=true;self.dirty=true;}
                    ui.small("Latest-wins preview: slider input never waits for image processing.");
                }
            }
            if refresh{self.queue();}
            ui.separator();ui.heading("Catalog · all 221");
            ui.text_edit_singleline(&mut self.search);
            ui.small("Unavailable effects are searchable but cannot be applied as fake versions.");
            let search=self.search.to_lowercase();
            let matching=self.catalog.iter().filter(|e|e.name.to_lowercase().contains(&search)||e.category.to_lowercase().contains(&search))
                .take(221).map(|e|(e.id.clone(),e.name.clone(),e.category.clone(),e.intended.clone())).collect::<Vec<_>>();
            let mut to_add=None;
            egui::ScrollArea::vertical().max_height(ui.available_height()-14.0).show(ui,|ui|{
                for (id,name,cat,intended) in &matching{
                    let ok=supported(id);
                    ui.horizontal(|ui|{
                        if ui.add_enabled(ok,egui::Button::new(if ok{"＋"} else {"·"})).clicked(){to_add=Some(id.clone());}
                        let name_label=if ok{format!("{name}")} else {format!("{name}  [not ported]")};
                        let label=ui.label(name_label);
                        label.on_hover_text(format!("{cat}\nExpected: {intended}"));
                    });
                }
            });
            if let Some(id)=to_add{self.add_effect(&id);}
        });
        egui::TopBottomPanel::bottom("status-bar").show(ctx,|ui|{
            ui.horizontal_wrapped(|ui|{
                ui.small(format!("{} · {}×{} · {} native preview frames",self.document.name(),self.document.width(),self.document.height(),self.frame_count));
                if !self.preview_warnings.is_empty(){ui.colored_label(Color32::LIGHT_RED,
                    format!("{} UNPORTED effect(s) excluded from preview",self.preview_warnings.len()));}
                ui.separator();ui.small(&self.status);
            });
        });
        egui::CentralPanel::default().show(ctx,|ui|{
            ui.horizontal(|ui|{
                ui.label(egui::RichText::new("CANVAS · selected raster only").strong());
                ui.label("Source artwork retains its original resolution; each completed render is exact for supported effects.");
            });
            let Some(texture)=&self.texture else{
                ui.centered_and_justified(|ui|{ui.spinner();ui.label("Generating native preview …");});return;
            };
            let image_size=Vec2::new(self.source.width() as f32,self.source.height() as f32);
            let available=ui.available_size()-Vec2::new(24.0,24.0);
            let scale=(available.x/image_size.x).min(available.y/image_size.y).min(1.6).max(0.05);
            let response=ui.add(egui::Image::new(texture).fit_to_exact_size(image_size*scale).sense(egui::Sense::click_and_drag()));
            if let Some(err)=&self.layer_load_error{ui.colored_label(Color32::LIGHT_RED,err);}
            if let Some(pointer)=response.interact_pointer_pos(){
                if self.layer_load_error.is_none() && (response.dragged() || response.clicked()){
                    let rect=response.rect;
                    let x=((pointer.x-rect.min.x)/rect.width()*image_size.x).floor() as i32;
                    let y=((pointer.y-rect.min.y)/rect.height()*image_size.y).floor() as i32;
                    if x>=0&&y>=0&&x<image_size.x as i32&&y<image_size.y as i32{
                        if self.previous_drag_point.is_none(){self.record_undo();}
                        let start=self.previous_drag_point.unwrap_or((x,y));
                        self.paint(start,(x,y));self.previous_drag_point=Some((x,y));
                    }
                }
            }
            if !response.dragged(){self.previous_drag_point=None;}
        });
    }
}
