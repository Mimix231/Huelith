//! Individually implemented native effects. Unsupported catalog entries are
//! deliberately NOT rendered with a generic placeholder. Visual fidelity for
//! supported entries is still provisional until artist-reviewed certification.
use huelith_core::EffectSlot;
use image::{Rgba, RgbaImage};
use rayon::prelude::*;

pub const PORTED: &[&str] = &[
    "brightness", "contrast", "saturate", "hue", "grayscale", "sepia", "invert",
    "exposure", "gamma", "vibrance", "temperature", "tint", "solarize", "posterize",
    "blur", "boxblur", "motionblur", "pixelate", "vignette", "grain", "chromatic",
    "halftone", "swirl", "ripple", "wave", "atelier_4_0", "atelier_3_12",
    "atelier_7_0", "atelier_7_1",
];

pub fn supported(kind: &str) -> bool { PORTED.contains(&kind) }

pub fn render_stack(source: &RgbaImage, effects: &[EffectSlot], obsolete: impl Fn() -> bool) -> Result<Option<RgbaImage>, String> {
    let mut output = source.clone();
    for fx in effects {
        if obsolete() { return Ok(None); }
        if !fx.enabled || fx.amount.abs() < 1e-6 { continue; }
        if !supported(&fx.kind) { return Err(format!("{} is not implemented natively; no fake approximation applied", fx.kind)); }
        output = apply(&output, fx)?;
    }
    if obsolete() { return Ok(None); }
    Ok(Some(output))
}

fn mix(a: u8, b: f32, weight: f32) -> u8 {
    ((a as f32)*(1.0-weight)+b.clamp(0.0,255.0)*weight).round().clamp(0.0,255.0) as u8
}
fn lum(p: [u8; 4]) -> f32 { 0.2126*p[0] as f32 + 0.7152*p[1] as f32 + 0.0722*p[2] as f32 }
fn srgb_to_linear(v: f32) -> f32 { let c = v/255.0; if c <= 0.04045 { c/12.92 } else { ((c+0.055)/1.055).powf(2.4) } }
fn linear_to_srgb(v: f32) -> f32 { let c = v.max(0.0); (if c <= 0.0031308 { 12.92*c } else { 1.055*c.powf(1.0/2.4)-0.055 })*255.0 }

fn transform<F>(src: &RgbaImage, f: F) -> RgbaImage where F: FnMut([u8;4], u32, u32) -> [f32;3] + Send + Sync + Clone {
    let (w,h) = src.dimensions();
    let mut out = src.clone();
    out.as_mut().par_chunks_mut((w*4) as usize).enumerate().for_each(|(y,row)| {
        let mut inner = f.clone();
        for x in 0..w as usize {
            let srcp = src.get_pixel(x as u32,y as u32).0;
            let rgb=inner(srcp,x as u32,y as u32);
            let j=x*4;
            row[j] = rgb[0].round().clamp(0.0,255.0) as u8;
            row[j+1] = rgb[1].round().clamp(0.0,255.0) as u8;
            row[j+2] = rgb[2].round().clamp(0.0,255.0) as u8;
            row[j+3] = srcp[3];
        }
    });
    let _ = h;
    out
}
fn sample(src: &RgbaImage,x:i32,y:i32)->[u8;4] {
    src.get_pixel(x.clamp(0,src.width() as i32-1) as u32, y.clamp(0,src.height() as i32-1) as u32).0
}
fn blur(src:&RgbaImage,radius:f32, gaussian:bool)->RgbaImage {
    let r=radius.round().clamp(1.0,80.0) as i32;
    let sigma=(r as f32 / 2.0).max(0.5);
    let mut weights:Vec<f32>=(-r..=r).map(|i| if gaussian { (-0.5*(i as f32/sigma).powi(2)).exp() } else {1.0}).collect();
    let total: f32=weights.iter().sum(); for w in &mut weights {*w/=total;}
    let (w,h)=src.dimensions();
    let mut horizontal=src.clone();
    horizontal.as_mut().par_chunks_mut((w*4) as usize).enumerate().for_each(|(y,row)| {
        for x in 0..w as i32 {
            let mut sum=[0.0f32;4];
            for d in -r..=r {let p=sample(src,x+d,y as i32); let weight=weights[(d+r) as usize]; for c in 0..4 {sum[c]+=p[c] as f32*weight;}}
            let j=x as usize*4; for c in 0..4 {row[j+c]=sum[c].round().clamp(0.0,255.0) as u8;}
        }
    });
    let mut out=horizontal.clone();
    out.as_mut().par_chunks_mut((w*4) as usize).enumerate().for_each(|(y,row)| {
        for x in 0..w as i32 {
            let mut sum=[0.0f32;4];
            for d in -r..=r {let p=sample(&horizontal,x,y as i32+d); let weight=weights[(d+r) as usize]; for c in 0..4 {sum[c]+=p[c] as f32*weight;}}
            let j=x as usize*4; for c in 0..4 {row[j+c]=sum[c].round().clamp(0.0,255.0) as u8;}
        }
    });
    let _ = h; out
}
fn directional_blur(src:&RgbaImage,radius:i32)->RgbaImage {
    let (w,_) = src.dimensions(); let mut out = src.clone();
    let r=radius.clamp(1,150);
    out.as_mut().par_chunks_mut(w as usize * 4).enumerate().for_each(|(y,row)|{
        for x in 0..w as i32 {
            let mut sum=[0u32;4]; let mut count=0;
            for dx in -r..=r { let p=sample(src,x+dx,y as i32); for c in 0..4 {sum[c]+=p[c] as u32;} count+=1; }
            let i=x as usize*4;for c in 0..4 {row[i+c]=(sum[c]/count) as u8;}
        }
    });out
}

pub fn apply(src:&RgbaImage,fx:&EffectSlot)->Result<RgbaImage,String>{
    if !supported(&fx.kind) { return Err(format!("Not ported to native Rust: {}",fx.kind)); }
    let strength=(fx.amount/100.0).clamp(0.0,1.0);
    if strength <=0.0 {return Ok(src.clone());}
    let (w,h)=src.dimensions();
    let out = match fx.kind.as_str(){
        "brightness" => transform(src,|p,_,_| {let k=1.0+strength; [p[0] as f32*k,p[1] as f32*k,p[2] as f32*k]}),
        "contrast" => transform(src,|p,_,_| {let k=1.0+strength*1.8; std::array::from_fn(|c|128.0+(p[c] as f32-128.0)*k)}),
        "saturate" => transform(src,|p,_,_| {let l=lum(p);std::array::from_fn(|c|l+(p[c] as f32-l)*(1.0+1.5*strength))}),
        "hue" => transform(src,|p,_,_| {
            let a= strength*std::f32::consts::TAU;
            let cos=a.cos();let sin=a.sin();
            let r=p[0] as f32;let g=p[1] as f32;let b=p[2] as f32;
            [(.213+cos*.787-sin*.213)*r+(.715-cos*.715-sin*.715)*g+(.072-cos*.072+sin*.928)*b,
             (.213-cos*.213+sin*.143)*r+(.715+cos*.285+sin*.140)*g+(.072-cos*.072-sin*.283)*b,
             (.213-cos*.213-sin*.787)*r+(.715-cos*.715+sin*.715)*g+(.072+cos*.928+sin*.072)*b]
        }),
        "grayscale"=>transform(src,|p,_,_|{let l=lum(p);std::array::from_fn(|c|p[c] as f32*(1.0-strength)+l*strength)}),
        "sepia"=>transform(src,|p,_,_|{let r=p[0] as f32;let g=p[1] as f32;let b=p[2] as f32;
            let values=[.393*r+.769*g+.189*b,.349*r+.686*g+.168*b,.272*r+.534*g+.131*b];
            std::array::from_fn(|c|p[c] as f32*(1.0-strength)+values[c]*strength)}),
        "invert"=>transform(src,|p,_,_|std::array::from_fn(|c|p[c] as f32*(1.0-strength)+(255-p[c]) as f32*strength)),
        "exposure"=>transform(src,|p,_,_|{
            let multiplier=2.0_f32.powf(strength*2.0);
            std::array::from_fn(|c|linear_to_srgb(srgb_to_linear(p[c] as f32)*multiplier))}),
        "gamma"=>transform(src,|p,_,_|{
            let inv=1.0/(1.0+1.6*strength);
            std::array::from_fn(|c|255.0*(p[c] as f32/255.0).powf(inv))}),
        "vibrance"=>transform(src,|p,_,_|{
            let mx=p[0].max(p[1]).max(p[2]) as f32;let mn=p[0].min(p[1]).min(p[2]) as f32;
            let sat=(mx-mn)/255.0;let l=lum(p);
            std::array::from_fn(|c|l+(p[c] as f32-l)*(1.0+strength*(1.0-sat)*1.7))}),
        "temperature"=>transform(src,|p,_,_| [p[0] as f32+35.0*strength,p[1] as f32+5.0*strength,p[2] as f32-40.0*strength]),
        "tint"=>transform(src,|p,_,_| [p[0] as f32+30.0*strength,p[1] as f32-30.0*strength,p[2] as f32+30.0*strength]),
        "solarize"=>transform(src,|p,_,_|std::array::from_fn(|c|if p[c] as f32/255.0 >1.0-strength {255.0-p[c] as f32} else {p[c] as f32})),
        "posterize"=>transform(src,|p,_,_|{
            let levels=(32.0-30.0*strength).round().clamp(2.0,32.0);
            std::array::from_fn(|c|(p[c] as f32/255.0*(levels-1.0)).round()*255.0/(levels-1.0))}),
        "blur"=>blur(src,1.0+strength*20.0,true),
        "boxblur"=>blur(src,1.0+strength*20.0,false),
        "motionblur"=>directional_blur(src, (1.0+strength*45.0) as i32),
        "pixelate"=> {let cell=(1.0+strength*35.0) as u32;
            transform(src,move |_,x,y| {let p=src.get_pixel(((x/cell)*cell).min(w-1),((y/cell)*cell).min(h-1)).0;
                [p[0] as f32,p[1] as f32,p[2] as f32]})},
        "vignette"=>transform(src,move |p,x,y|{
            let dx=(x as f32+.5-w as f32/2.0)/(w as f32/2.0);
            let dy=(y as f32+.5-h as f32/2.0)/(h as f32/2.0);
            let v=1.0-strength*((dx*dx+dy*dy).sqrt()/1.4142).powf(1.7);
            std::array::from_fn(|c|p[c] as f32*v)}),
        "grain"=>transform(src,move |p,x,y|{
            let hash=(x.wrapping_mul(374761393)^y.wrapping_mul(668265263)).wrapping_mul(2246822519);
            let n=((hash^(hash>>13))&255) as f32-127.5;
            std::array::from_fn(|c|p[c] as f32+n*strength*.36)}),
        "chromatic"=>transform(src,move |p,x,y|{
            let s=(strength*12.0).round() as i32;
            [sample(src,x as i32-s,y as i32)[0] as f32,p[1] as f32,
             sample(src,x as i32+s,y as i32)[2] as f32]}),
        "halftone"=>transform(src,move |p,x,y|{
            let cell=7.0;let px=((x as f32%cell)/cell)-0.5;let py=(y as f32%cell)/cell-0.5;
            let radius=(1.0-lum(p)/255.0).sqrt()*.65*strength;
            let ink=if px*px+py*py<radius*radius {0.0} else {255.0};
            std::array::from_fn(|c|p[c] as f32*(1.0-strength)+ink*strength)}),
        "atelier_4_0"=>transform(src,move|p,x,y|{
            let cell=9.0;let dx=((x as f32+.5)%cell)/cell-.5;
            let dy=((y as f32+.5)%cell)/cell-.5;
            let radius=((255.0-lum(p))/255.0).sqrt()*.64;
            let ink=if dx*dx+dy*dy<radius*radius { 8.0 } else { 255.0 };
            std::array::from_fn(|c|p[c] as f32*(1.0-strength)+ink*strength)}),
        "swirl"=>transform(src,move|p,x,y|{
            let cx=w as f32/2.0;let cy=h as f32/2.0;
            let dx=(x as f32-cx);let dy=y as f32-cy;
            let r=(dx*dx+dy*dy).sqrt();let maxr=cx.min(cy).max(1.0);
            let angle=strength*4.0*(1.0-r/maxr).max(0.0);
            let (s,c)=angle.sin_cos();let q=sample(src,(cx+dx*c-dy*s) as i32,(cy+dx*s+dy*c) as i32);
            [q[0] as f32,q[1] as f32,q[2] as f32]}),
        "ripple"=>transform(src,move|_,x,y|{
            let dx=x as f32-w as f32*.5;let dy=y as f32-h as f32*.5;
            let r=(dx*dx+dy*dy).sqrt().max(1.0);
            let displacement=(r*.12).sin()*strength*16.0;
            let q=sample(src,(x as f32+dx/r*displacement) as i32,(y as f32+dy/r*displacement) as i32);
            [q[0] as f32,q[1] as f32,q[2] as f32]}),
        "wave"=>transform(src,move|_,x,y|{
            let q=sample(src,(x as f32+(y as f32*.045).sin()*strength*23.0) as i32,y as i32);
            [q[0] as f32,q[1] as f32,q[2] as f32]}),
        "atelier_3_12"=>{
            // Brightness-based pixel sorting within contiguous horizontal bands.
            // Alpha is reordered together with RGB to avoid creating invalid colors.
            let mut img=src.clone();let block=(4.0+strength*90.0).round() as usize;
            img.as_mut().par_chunks_mut((w*4) as usize).for_each(|row|{
                for segment in row.chunks_mut(block*4){
                    let mut pixels:Vec<[u8;4]>=segment.chunks_exact(4).map(|p|[p[0],p[1],p[2],p[3]]).collect();
                    pixels.sort_by(|a,b|lum(*a).total_cmp(&lum(*b)));
                    for (target,p) in segment.chunks_exact_mut(4).zip(pixels) {target.copy_from_slice(&p);}
                }
            });img
        },
        "atelier_7_0"=>{
            // Film halation: spatial, warm highlight diffusion, not global red tint.
            let threshold=180.0;
            let light=transform(src,move |p,_,_|{
                let gate=((lum(p)-threshold)/(255.0-threshold)).clamp(0.0,1.0);
                [p[0] as f32*gate,p[1] as f32*gate,p[2] as f32*gate]
            });
            let bloom=blur(&light,2.0+strength*18.0,true);
            transform(src,move |p,x,y|{
                let b=bloom.get_pixel(x,y).0;
                [p[0] as f32+b[0] as f32*strength*.95,
                 p[1] as f32+b[0] as f32*strength*.28,
                 p[2] as f32+b[0] as f32*strength*.05]
            })
        },
        "atelier_7_1"=>{
            // Horizontal light source streak, glow spread from bright regions.
            let light=transform(src,move|p,_,_|{
                let v=((lum(p)-200.0)/55.0).clamp(0.0,1.0);
                std::array::from_fn(|c|p[c] as f32*v)
            });
            let streak=directional_blur(&light,(strength*120.0).round() as i32);
            transform(src,move|p,x,y|{
                let gl=streak.get_pixel(x,y).0;
                [p[0] as f32+gl[0] as f32*strength*.55,
                 p[1] as f32+gl[1] as f32*strength*.75,
                 p[2] as f32+gl[2] as f32*strength*1.2]
            })
        },
        _=>return Err(format!("No native implementation: {}",fx.kind))
    };
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fx(kind:&str,amount:f32)->EffectSlot {EffectSlot{kind:kind.into(),amount,enabled:true,color:None}}
    fn test_image()->RgbaImage {RgbaImage::from_fn(32,32,|x,y|Rgba([(x*8) as u8,(y*8) as u8,110,255]))}
    #[test] fn every_supported_kind_is_executable(){for &kind in PORTED {
        let res=apply(&test_image(),&fx(kind,75.0));assert!(res.is_ok(),"{kind}: {:?}",res.err());
    }}
    #[test] fn zero_amount_is_identity(){for &kind in PORTED {
        let src=test_image();assert_eq!(apply(&src,&fx(kind,0.0)).unwrap(),src,"{kind}");
    }}
    #[test] fn unsupported_effect_is_not_faked(){assert!(apply(&test_image(),&fx("atelier_2_2",70.0)).is_err());}
    #[test] fn pixel_sort_reorders_without_changing_pixel_multiset(){
        let src=test_image();let out=apply(&src,&fx("atelier_3_12",100.0)).unwrap();
        let mut before=src.into_raw().chunks_exact(4).map(|p|p.to_vec()).collect::<Vec<_>>();
        let mut after=out.into_raw().chunks_exact(4).map(|p|p.to_vec()).collect::<Vec<_>>();
        before.sort();after.sort(); assert_eq!(before,after);
    }
    #[test] fn native_catalog_subset_is_declared() {let entries=huelith_core::catalog();
        for kind in PORTED {assert!(entries.iter().any(|e| e.id==*kind),"unknown kind {kind}");}
    }
}
