//! Huelith native document and effect-catalog layer.
//! The JSON document remains an open map so the native migration NEVER silently
//! drops foreign, old, or not-yet-ported Huelith properties on round-trip.
use base64::{engine::general_purpose::STANDARD, Engine as _};
use image::{DynamicImage, ImageFormat, RgbaImage};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{io::Cursor, path::Path};

const MAX_PIXELS: u64 = 64_000_000;

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct CatalogEntry {
    pub id: String,
    pub name: String,
    pub category: String,
    pub intended: String,
    pub legacy_behavior: String,
    pub legacy_assessment: String,
}

pub fn catalog() -> Vec<CatalogEntry> {
    serde_json::from_str(include_str!("../assets/effects.json"))
        .expect("Bundled Huelith 221-effect catalog is valid JSON")
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct EffectSlot {
    pub kind: String,
    pub amount: f32,
    pub enabled: bool,
    #[serde(default)]
    pub color: Option<String>,
}

#[derive(Debug, Clone)]
pub struct LayerSummary {
    pub id: String,
    pub name: String,
    pub kind: String,
    pub visible: bool,
    pub locked: bool,
}

#[derive(Debug, Clone)]
pub struct Document {
    pub data: Value,
}

impl Document {
    pub fn new(width: u32, height: u32) -> Result<Self, String> {
        check_size(width, height)?;
        Ok(Self { data: json!({
            "format":"huelith", "version":1,
            "id":"native-huelith-document", "name":"Untitled",
            "width":width, "height":height,
            "background":"#ffffff", "activeLayerId":"native-raster-1",
            "createdAt":"", "updatedAt":"",
            "layers":[{"id":"native-raster-1","name":"Paint layer","type":"raster",
              "visible":true,"locked":false,"opacity":1.0,"blend":"source-over",
              "x":0,"y":0,"image":"","effects":[]}]
        }) })
    }

    pub fn from_json(bytes: &[u8]) -> Result<Self, String> {
        let data: Value = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
        let format = data.get("format").and_then(Value::as_str).unwrap_or("");
        if format != "huelith" && format != "spectrum" {
            return Err(format!("Unsupported document format: {format}"));
        }
        if data.get("version").and_then(Value::as_u64) != Some(1) {
            return Err("Only version-1 documents are currently understood; no conversion performed".into());
        }
        let w = data.get("width").and_then(Value::as_u64).unwrap_or(0);
        let h = data.get("height").and_then(Value::as_u64).unwrap_or(0);
        check_size(w.min(u32::MAX as u64) as u32, h.min(u32::MAX as u64) as u32)?;
        if w > u32::MAX as u64 || h > u32::MAX as u64 { return Err("Invalid canvas dimensions".into()); }
        if !data.get("layers").is_some_and(Value::is_array) { return Err("Missing layers array".into()); }
        Ok(Self { data })
    }

    pub fn read(path: &Path) -> Result<Self, String> {
        let bytes = std::fs::read(path).map_err(|e| e.to_string())?;
        Self::from_json(&bytes)
    }

    pub fn write(&self, path: &Path) -> Result<(), String> {
        let bytes = serde_json::to_vec_pretty(&self.data).map_err(|e| e.to_string())?;
        // Only replace destination after the temporary file is written.
        let temp = path.with_extension("huelith.tmp");
        std::fs::write(&temp, bytes).map_err(|e| e.to_string())?;
        std::fs::rename(&temp, path).map_err(|e| e.to_string())
    }

    pub fn width(&self) -> u32 { self.data["width"].as_u64().unwrap_or(0) as u32 }
    pub fn height(&self) -> u32 { self.data["height"].as_u64().unwrap_or(0) as u32 }
    pub fn name(&self) -> &str { self.data["name"].as_str().unwrap_or("Untitled") }
    pub fn selected_id(&self) -> &str { self.data["activeLayerId"].as_str().unwrap_or("") }

    pub fn set_selected(&mut self, id: &str) {
        if self.layers().iter().any(|l| l.id == id) { self.data["activeLayerId"] = json!(id); }
    }
    pub fn layers(&self) -> Vec<LayerSummary> {
        fn walk(layers: &Value, summaries: &mut Vec<LayerSummary>) {
            if let Some(items) = layers.as_array() { for layer in items {
                summaries.push(LayerSummary {
                    id: layer["id"].as_str().unwrap_or("").to_owned(),
                    name: layer["name"].as_str().unwrap_or("Unnamed").to_owned(),
                    kind: layer["type"].as_str().unwrap_or("unknown").to_owned(),
                    visible: layer["visible"].as_bool().unwrap_or(true),
                    locked: layer["locked"].as_bool().unwrap_or(false),
                });
                walk(&layer["children"], summaries);
            }}
        }
        let mut list = Vec::new(); walk(&self.data["layers"], &mut list); list
    }

    fn find_layer<'a>(value: &'a Value, id: &str) -> Option<&'a Value> {
        for item in value.as_array()? {
            if item["id"].as_str() == Some(id) { return Some(item); }
            if let Some(found) = Self::find_layer(&item["children"], id) { return Some(found); }
        }
        None
    }

    fn find_layer_mut<'a>(value: &'a mut Value, id: &str) -> Option<&'a mut Value> {
        for item in value.as_array_mut()? {
            if item["id"].as_str() == Some(id) { return Some(item); }
            if let Some(found) = Self::find_layer_mut(&mut item["children"], id) { return Some(found); }
        }
        None
    }

    pub fn selected_raster(&self) -> Result<RgbaImage, String> {
        let selected = Self::find_layer(&self.data["layers"], self.selected_id())
            .ok_or("Selected layer not found")?;
        if selected["type"] != "raster" { return Err("Selected layer is not raster (not yet ported)".into()); }
        let encoded = selected["image"].as_str().unwrap_or("");
        if encoded.is_empty() { return Ok(RgbaImage::new(self.width(), self.height())); }
        let data = encoded.split_once(',').map_or(encoded, |(_, payload)| payload);
        let binary = STANDARD.decode(data).map_err(|e| e.to_string())?;
        let img = image::load_from_memory(&binary).map_err(|e| e.to_string())?.to_rgba8();
        Ok(img)
    }

    pub fn set_selected_raster(&mut self, img: &RgbaImage) -> Result<(), String> {
        let mut bytes = Vec::new();
        DynamicImage::ImageRgba8(img.clone()).write_to(&mut Cursor::new(&mut bytes), ImageFormat::Png)
            .map_err(|e| e.to_string())?;
        let image = format!("data:image/png;base64,{}", STANDARD.encode(bytes));
        let id = self.selected_id().to_owned();
        let layer = Self::find_layer_mut(&mut self.data["layers"], &id)
            .ok_or("Selected layer not found")?;
        if layer["type"] != "raster" { return Err("Cannot paint on non-raster layers".into()); }
        layer["image"] = json!(image);
        layer["imageWidth"] = json!(img.width());
        layer["imageHeight"] = json!(img.height());
        Ok(())
    }

    pub fn selected_effects(&self) -> Vec<EffectSlot> {
        let Some(layer) = Self::find_layer(&self.data["layers"], self.selected_id()) else { return vec![] };
        layer["effects"].as_array().into_iter().flatten().map(|effect| EffectSlot {
            kind: effect["kind"].as_str().unwrap_or("").to_owned(),
            amount: effect["amount"].as_f64().unwrap_or(50.0) as f32,
            enabled: effect["enabled"].as_bool().unwrap_or(true),
            color: effect["color"].as_str().map(ToOwned::to_owned),
        }).collect()
    }

    pub fn set_selected_effects(&mut self, new_effects: &[EffectSlot]) -> Result<(), String> {
        // Preserve all old effect fields (parameters, presets, editor category, etc.)
        // when they are not explicitly changed by the native editor.
        let id = self.selected_id().to_owned();
        let layer = Self::find_layer_mut(&mut self.data["layers"], &id)
            .ok_or("Selected layer not found")?;
        let previous = layer["effects"].as_array().cloned().unwrap_or_default();
        let mut used = vec![false; previous.len()];
        let mut merged = Vec::new();
        for effect in new_effects {
            let old_index = previous.iter().enumerate().find(|(i, old)|
                !used[*i] && old["kind"].as_str() == Some(effect.kind.as_str())).map(|(i,_)| i);
            let mut entry = if let Some(i) = old_index {
                used[i] = true;
                previous[i].clone()
            } else {
                json!({"id": format!("native-{}-{}", merged.len(), effect.kind),
                    "kind":effect.kind, "studioCategory":"creativity"})
            };
            entry["amount"] = json!(effect.amount);
            entry["enabled"] = json!(effect.enabled);
            if let Some(c) = &effect.color { entry["color"] = json!(c); }
            merged.push(entry);
        }
        layer["effects"] = Value::Array(merged);
        Ok(())
    }
}

fn check_size(w: u32, h: u32) -> Result<(), String> {
    if w == 0 || h == 0 || w > 16_384 || h > 16_384 || w as u64 * h as u64 > MAX_PIXELS {
        return Err("Canvas must be 1..16384 per dimension and at most 64MP".into());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn full_catalog_is_unique() {
        let items = catalog();
        let kinds: std::collections::HashSet<_> = items.iter().map(|x| &x.id).collect();
        assert_eq!(items.len(), 221);
        assert_eq!(kinds.len(), 221);
    }
    #[test]
    fn roundtrip_keeps_unknown_fields() {
        let mut doc = Document::new(32, 24).unwrap();
        doc.data["futureNativeFeature"] = json!({"other":"preserve"});
        doc.data["layers"][0]["effects"] = json!([{"id":"e1","kind":"brightness","enabled":true,"amount":42,"parameters":{"foo":8}}]);
        let effects = doc.selected_effects();
        doc.set_selected_effects(&effects).unwrap();
        let saved = serde_json::to_vec(&doc.data).unwrap();
        let read = Document::from_json(&saved).unwrap();
        assert_eq!(read.data["futureNativeFeature"], doc.data["futureNativeFeature"]);
        assert_eq!(read.data["layers"][0]["effects"][0]["parameters"]["foo"],8);
    }
    #[test]
    fn refuses_oversized_document() { assert!(Document::new(16_384,16_384).is_err()); }
}
