import { createSurface } from './canvas-surface';
import { drawLiveStrengthPreview } from './live-preview-mixer';
import { paintGpuEffectDraft, paintCanvasEffectDraft } from './live-gpu-effects';
import { uid, type Effect, type EffectKind, type Layer } from './types';
import { FILTER_CATALOG, FILTER_CONTROL_MAP } from './effect-catalog';
import { applyEffect } from './effect-ops';
import { EFFECT_PARAMETER_SCHEMA, defaultParameters } from './effect-schema';
import { effectPreviewScale, isInteractiveEffectPreview, previewCacheVictim } from './preview-quality';

export const EFFECT_CONTROLS = FILTER_CONTROL_MAP;
export const FILTERS: { kind: EffectKind; label: string; initial: number; group: string }[] = FILTER_CATALOG.map(
  ({ kind, label, initial, group }) => ({ kind, label, initial, group }),
);

/** Additional controls are interpreted by the effect processor, never just decoration. */
export const EFFECT_PARAMETERS = EFFECT_PARAMETER_SCHEMA;

export function clampEffectAmount(kind: EffectKind, amount: number): number {
  const descriptor = EFFECT_CONTROLS[kind];
  return Math.max(descriptor.min, Math.min(descriptor.max, Number.isFinite(amount) ? amount : descriptor.min));
}

/** The 15 signature FX are *standalone processors*. Historical .spectrum files
 * containing multiple legacy steps still render unchanged; newly applied FX
 * create only one dedicated sig_N effect, without composing named filters. */
export const SIGNATURE_FX_NAMES = [
  'Hyper Outline',
  'Neon Pulse',
  'Shadow Forge',
  'Dream Bloom',
  'Glitch Matrix',
  'Comic Pop',
  'Frostbite',
  'Ember Glow',
  'Prism Split',
  'Golden Hour',
  'Aurora Flow',
  'Electric Edge',
  'Holographic',
  'Retro Vision',
  'Spectrum Burst',
] as const;

export const SIGNATURE_FX_COLORS = ["#ffffff", "#2feaff", "#17112c", "#ffd6f4", "#52a8ff", "#ffcb45", "#b0ebff", "#ff7837", "#ff59d8", "#ffbb65", "#68ffcb", "#39eaff", "#bb84ff", "#d57bfa", "#a79cff"] as const;

export const FX_PRESETS: Record<string, { kind: EffectKind; amount: number; color?: string; parameters?: Effect['parameters'] }[]> = Object.fromEntries(
  SIGNATURE_FX_NAMES.map((name, index) => [name, [{ kind: `sig_${index}` as EffectKind, amount: 70, color: SIGNATURE_FX_COLORS[index], parameters: defaultParameters(`sig_${index}` as EffectKind) }]]),
);


export function newEffect(kind: EffectKind, amount?: number, color?: string, parameters?: Effect['parameters']): Effect {
  const definition = FILTERS.find(item => item.kind === kind);
  return {
    id: uid(), kind, enabled: true,
    amount: clampEffectAmount(kind, amount ?? definition?.initial ?? 100),
    color,
    parameters: { ...defaultParameters(kind), ...structuredClone(parameters ?? {}) },
  };
}

/** CSS filter representation kept for SVG compatibility and quick previews. */
export function effectFilter(effect: Effect): string {
  const amount = clampEffectAmount(effect.kind, effect.amount);
  if (effect.kind === 'hue') return `hue-rotate(${amount}deg)`;
  if (effect.kind === 'blur') return `blur(${amount}px)`;
  if (['brightness', 'contrast', 'saturate', 'grayscale', 'sepia', 'invert'].includes(effect.kind)) {
    const name = effect.kind === 'saturate' ? 'saturate' : effect.kind;
    return `${name}(${amount}%)`;
  }
  return 'none';
}

/** These seven CSS Canvas2D filters have an exact native renderer and
 * therefore need no worker round-trip during a single-effect live drag.
 * Slow spatial filters deliberately do not take this path. */
const REALTIME_COLOR_KINDS = new Set<EffectKind>([
  'brightness', 'contrast', 'saturate', 'hue', 'grayscale', 'sepia', 'invert',
]);
export function realtimeFilter(effects: readonly Effect[]): string | null {
  const enabled = effects.filter(effect => effect.enabled);
  if (enabled.length !== 1 || !REALTIME_COLOR_KINDS.has(enabled[0].kind)) return null;
  return effectFilter(enabled[0]);
}

/** Non-destructive effect graph shared by editor, frame export, and image export. */
export function processEffects(source: HTMLCanvasElement, effects: readonly Effect[]): HTMLCanvasElement {
  let current = source;
  for (const effect of effects) {
    if (!effect.enabled) continue;
    const controls = EFFECT_CONTROLS[effect.kind];
    // A zero setting is a meaningful state for several effects; never use a universal "amount > 0" guard.
    if (effect.kind === 'outline' && effect.amount === 0) continue;
    if (effect.kind === 'cutout' && effect.amount === 0) continue;
    if (controls && !Number.isFinite(effect.amount)) continue;
    current = applyEffect(current, effect);
  }
  return current;
}

type EffectImage = HTMLCanvasElement | ImageBitmap;
interface EffectResult {
  width: number; height: number; scale: number; image: EffectImage;
  source?: HTMLCanvasElement; signature?: string;
}
const effectCache = new WeakMap<Layer, EffectResult>();
const pendingWorkers = new WeakSet<Layer>();

interface SourceSnapshot {
  layerType: Layer['type'];
  content: string | object;
  x: number;
  y: number;
  imageWidth?: number;
  imageHeight?: number;
  scaleX?: number;
  scaleY?: number;
  rotation?: number;
  width: number;
  height: number;
  canvas: HTMLCanvasElement;
}

// Editing only effect parameters does not change a layer's pixels. Retain its
// full-resolution source instead of repainting/importing a large image for
// every slider preview. Never cache groups, whose descendants can change.
const sourceCache = new Map<string, SourceSnapshot>();
const MAX_SOURCE_BYTES = 192 * 1024 * 1024;
const MAX_SOURCE_LAYERS = 10;

function fullResolutionSource(
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
): HTMLCanvasElement {
  const content = layer.type === 'raster' ? layer.image : layer.type === 'vector' ? layer.shapes : layer.children;
  const current = sourceCache.get(layer.id);
  if (layer.type !== 'group' && current && current.layerType === layer.type &&
    current.content === content && current.width === width && current.height === height &&
    current.x === layer.x && current.y === layer.y &&
    current.imageWidth === (layer.type === 'raster' ? layer.imageWidth : undefined) &&
    current.imageHeight === (layer.type === 'raster' ? layer.imageHeight : undefined) &&
    current.scaleX === (layer.type === 'raster' ? layer.scaleX : undefined) &&
    current.scaleY === (layer.type === 'raster' ? layer.scaleY : undefined) &&
    current.rotation === (layer.type === 'raster' ? layer.rotation : undefined)) {
    sourceCache.delete(layer.id);
    sourceCache.set(layer.id, current);
    return current.canvas;
  }

  const canvas = createSurface();
  canvas.width = Math.max(1, Math.floor(width));
  canvas.height = Math.max(1, Math.floor(height));
  const context = canvas.getContext('2d');
  if (!context) return canvas;
  paint(context, layer);
  if (layer.type !== 'group') {
    sourceCache.delete(layer.id);
    sourceCache.set(layer.id, {
      layerType: layer.type, content, x: layer.x, y: layer.y,
      imageWidth: layer.type === 'raster' ? layer.imageWidth : undefined,
      imageHeight: layer.type === 'raster' ? layer.imageHeight : undefined,
      scaleX: layer.type === 'raster' ? layer.scaleX : undefined,
      scaleY: layer.type === 'raster' ? layer.scaleY : undefined,
      rotation: layer.type === 'raster' ? layer.rotation : undefined,
      width, height, canvas,
    });
    let bytes = 0;
    for (const snapshot of sourceCache.values()) bytes += snapshot.width * snapshot.height * 4;
    while (sourceCache.size > MAX_SOURCE_LAYERS || bytes > MAX_SOURCE_BYTES) {
      // During a drag the source canvas is also the worker's resident-image
      // identity. Evicting it causes a new 8-33 MB source upload each frame,
      // destroying responsiveness in multi-layer or 4K documents. Keep that
      // one source pinned even if its pixels exceed the soft cache budget.
      const oldest = previewCacheVictim(sourceCache.keys());
      if (!oldest) break;
      const dropped = sourceCache.get(oldest)!;
      sourceCache.delete(oldest);
      bytes -= dropped.width * dropped.height * 4;
    }
  }
  return canvas;
}
const lastPreview = new Map<string, EffectResult>();
const MAX_CACHED_PREVIEW_BYTES = 96 * 1024 * 1024;
const MAX_CACHED_LAYERS = 8;
function putLastPreview(layerId: string, value: EffectResult): void {
  const former = lastPreview.get(layerId);
  if (former && former.image !== value.image && typeof ImageBitmap !== 'undefined' && former.image instanceof ImageBitmap) {
    former.image.close();
  }
  lastPreview.delete(layerId);
  lastPreview.set(layerId, value);
  let bytes = 0;
  for (const entry of lastPreview.values()) {
    bytes += Math.max(1, entry.width * entry.height * entry.scale * entry.scale) * 4;
  }
  while (lastPreview.size > MAX_CACHED_LAYERS || bytes > MAX_CACHED_PREVIEW_BYTES) {
    const [oldId, item] = lastPreview.entries().next().value as [string, EffectResult];
    lastPreview.delete(oldId);
    bytes -= Math.max(1, item.width * item.height * item.scale * item.scale) * 4;
    if (typeof ImageBitmap !== 'undefined' && item.image instanceof ImageBitmap) item.image.close();
  }
}

/** Injected only by the Vite desktop/browser entry; exports stay deterministic. */
export type AsyncEffectsProcessor = (
  source: HTMLCanvasElement,
  effects: readonly Effect[],
  layerId: string,
  done: (image: ImageBitmap) => void,
) => boolean;
interface LivePreviewHost {
  source: HTMLCanvasElement;
  width: number;
  height: number;
  onReady: () => void;
}
const livePreviewHosts = new Map<string, LivePreviewHost>();
const previewGeneration = new Map<string, number>();
function activeGeneration(id: string): number { return previewGeneration.get(id) ?? 0; }

/** Submit a Studio preview straight to the worker without redrawing every
 * layer on every slider tick. Only a completed bitmap repaints the viewport.
 * This is intentionally an optional fast path; the first effect, worker
 * failure, or renderer without OffscreenCanvas still takes the normal path.
 */
export function forgetLayerEffectPreview(layerId: string): void {
  livePreviewHosts.delete(layerId);
  previewGeneration.set(layerId, activeGeneration(layerId) + 1);
}

export function queueLayerEffectPreview(layerId: string, effects: readonly Effect[]): boolean {
  const host = livePreviewHosts.get(layerId);
  if (!host || !asyncProcessor || realtimeFilter(effects) !== null) return false;
  const signature = JSON.stringify(effects);
  const generation = activeGeneration(layerId);
  return asyncProcessor(host.source, effects, layerId, image => {
    if (generation !== activeGeneration(layerId)) { image.close(); return; }
    const result: EffectResult = {
      width: host.width, height: host.height, scale: 1,
      image, source: host.source, signature,
    };
    putLastPreview(layerId, result);
    host.onReady();
  });
}

let asyncProcessor: AsyncEffectsProcessor | null = null;
export function setAsyncEffectsProcessor(renderer: AsyncEffectsProcessor | null): void {
  asyncProcessor = renderer;
}


export function renderWithEffects(
  ctx: CanvasRenderingContext2D,
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
  onReady?: () => void,
): void {
  const effects = layer.effects ?? [];
  if (!effects.some(effect => effect.enabled)) {
    paint(ctx, layer);
    return;
  }
  // A single CSS-native color filter is already accelerated by Chromium's
  // Canvas2D compositor. Blur remains on the worker because large full-size
  // Gaussian kernels can block the UI thread. Apply it immediately to the cached native-resolution
  // layer source rather than waiting for a worker request/response at 60 Hz.
  const immediate = onReady ? realtimeFilter(effects) : null;
  if (immediate !== null) {
    const source = fullResolutionSource(layer, paint, width, height);
    ctx.save();
    ctx.filter = immediate;
    ctx.drawImage(source, 0, 0, width, height);
    ctx.restore();
    return;
  }
  const heavy = effects.some(effect => effect.enabled && (
    effect.kind.startsWith('sig_') || ['oilpaint', 'watercolor', 'denoise', 'surfaceblur',
      'outline', 'glow', 'shadow', 'lensblur', 'cutout', 'boxblur'].includes(effect.kind)));
  const scale = effectPreviewScale(width, height, layer.id, heavy);
  const signature = JSON.stringify(effects);
  const stored = effectCache.get(layer);
  const cached = typeof ImageBitmap !== 'undefined' && stored?.image instanceof ImageBitmap && stored.image.width === 0 ? undefined : stored;
  if (stored && !cached) effectCache.delete(layer);
  if (cached && cached.width === width && cached.height === height && cached.scale === scale) {
    ctx.drawImage(cached.image, 0, 0, width, height);
    return;
  }
  // Never downsample the whole layer merely because a slider is being dragged.
  // Both text glyphs and raster photographs must remain as sharp as exports.
  const source = fullResolutionSource(layer, paint, width, height);
  if (onReady && asyncProcessor) {
    // First visit caches a source for later direct effect submissions.
    livePreviewHosts.delete(layer.id);
    livePreviewHosts.set(layer.id, { source, width, height, onReady });
    while (livePreviewHosts.size > 4) {
      const evict = previewCacheVictim(livePreviewHosts.keys());
      if (!evict) break;
      livePreviewHosts.delete(evict);
    }
    const ready = lastPreview.get(layer.id);
    if (ready?.source === source && ready.signature === signature &&
      ready.width === width && ready.height === height &&
      !(typeof ImageBitmap !== 'undefined' && ready.image instanceof ImageBitmap && ready.image.width === 0)) {
      effectCache.set(layer, ready);
      ctx.drawImage(ready.image, 0, 0, width, height);
      return;
    }
  }
  if (onReady && asyncProcessor) {
    const prior = lastPreview.get(layer.id);
    const previous = prior?.source === source ? prior : undefined;
    const generation = activeGeneration(layer.id);
    // The GPU can interpolate the last accurate effect image immediately at
    // the pointer's current value while a CPU-heavy job is still running.
    // This image is provisional; every worker completion replaces it with the
    // exact full-resolution result. Never interpolate export pixels.
    const present = (): void => {
      // Stage I-J worker buffering still meant a 500-1000ms FX yielded ~1 FPS:
      // the compositor had NO new exact image to interpolate from. Draw a
      // native-resolution GPU draft from the cached source immediately.
      // The exact worker result replaces this draft when ready; exports never
      // enter the GPU draft path.
      if (isInteractiveEffectPreview(layer.id) &&
          (paintGpuEffectDraft(ctx, source, effects, width, height) ||
           paintCanvasEffectDraft(ctx, source, effects, width, height))) return;
      if (previous && previous.width === width && previous.height === height) {
        if (previous.signature !== signature && previous.signature) {
          let before: Effect[] | null = null;
          try { before = JSON.parse(previous.signature) as Effect[]; } catch { /* legacy cache */ }
          if (before && drawLiveStrengthPreview(ctx, source, previous.image, before, effects, width, height)) return;
        }
        ctx.drawImage(previous.image, 0, 0, width, height);
      } else ctx.drawImage(source, 0, 0, width, height);
    };
    if (!pendingWorkers.has(layer)) {
      pendingWorkers.add(layer);
      const submitted = asyncProcessor(source, effects, layer.id, image => {
        if (generation !== activeGeneration(layer.id)) { pendingWorkers.delete(layer); image.close(); return; }
        const result: EffectResult = { width, height, scale, image, source, signature };
        effectCache.set(layer, result);
        // Old jobs can complete after the layer has changed. Worker scheduler
        // suppresses their callback, so only current revisions get cached.
        putLastPreview(layer.id, result);
        pendingWorkers.delete(layer);
        onReady();
      });
      if (!submitted) pendingWorkers.delete(layer);
      else {
        present();
        return;
      }
    } else {
      present();
      return;
    }
  }
  // When WebGL2 exists but the worker is unavailable (e.g. blocked by a
  // restrictive WebView), do not run a heavy CPU filter on the UI thread for
  // each intermediate pointer position. Commit/export still run the exact
  // synchronous algorithm.
  if (onReady && isInteractiveEffectPreview(layer.id) &&
      (paintGpuEffectDraft(ctx, source, effects, width, height) ||
       paintCanvasEffectDraft(ctx, source, effects, width, height))) return;
  const processed = processEffects(source, effects);
  if (layer.type === 'vector') effectCache.set(layer, { width, height, scale, image: processed });
  ctx.drawImage(processed, 0, 0, width, height);
}
