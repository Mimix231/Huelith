## 2026-10-20 — Window-close repair verification

- `npm test`: **103/103 passed**, including five new close-related checks.
- `src/components/WindowControls.tsx` isolated strict TypeScript compilation
  against temporary dependency interfaces: **passed**.
- `tsc --noEmit` with unavailable npm dependencies: **not a valid full build check**;
  TypeScript reports missing React/MUI/Tauri packages; the original three TS1308
  diagnostics are absent.
- Tauri Windows runtime and actual close/Alt+F4: **not tested** here.
- New close behavior: Save All, Discard, Cancel; test manually with clean, dirty,
  untitled, multi-tab, and active-text-draft documents.

# Spectrum 0.1 — Effects and desktop stability verification

**Updated:** 20 October 2026 · **Project version:** `0.1.0` · **Status:** source release, not certified Windows release.

| Check | Result | Evidence / limitation |
|---|---|---|
| Node regression/source tests | **98 passed; 0 failed** | `NODE_PATH=$(npm root -g) npm test`: document model, compatibility migrations, structured effect validation, icon completeness, source syntax, animation and undo. |
| Chromium Canvas2D/theme pixel assertions | **193 passed** | `NODE_PATH=$(npm root -g) npm run test:browser`: samples for every one of the 70 filters and all 15 FX presets, plus multi-color gradient, distinct painted textures, shadow stacks, effect parameter sweep, brushes, blending, exports and themes. These are synthetic pixel tests, **not** desktop UI E2E. |
| Chromium timeline and motion assertions | **9 passed** | `npm run test:timeline`: timeline/playhead styles and popup motion/reduced-motion CSS. |
| Strict TS on dependency-free effect core | **Pass** | Actual TypeScript compiler with `--strict --noUnusedLocals --noUnusedParameters`. |
| CSS, JSON, Cargo TOML and SVG syntax | **Pass** | 19 CSS, 4 JSON, 1 TOML, 85 separate SVG assets parse. |
| Obsolete cleanup dry-run | **Pass** | Known legacy paths only, zero removed. |
| Full `npm install`, dependency-aware `npm run check` and Vite build | **Unavailable** | npm registry DNS/network unavailable in this environment; missing real React/MUI/Tauri npm package typings. Do not confuse strict editor-core check with actual full application build. |
| Native Windows build and titlebar close interaction | **Not tested** | Rust/Cargo and Windows native desktop runtime unavailable. New close logic uses a single close-request handler and native dialog, but requires verification on Windows. |
| Real color-wheel FPS under load | **Not benchmarked** | Native color pickers are buffered and complex interactive effects render reduced-resolution previews, but responsiveness requires a Windows performance profile. |
| React interface E2E | **Not executed** | Requires successful dependency installation and running Vite/Tauri desktop. |

## How to verify on Windows

```powershell
npm install
npm run check
npm test
npm run test:browser
npm run test:timeline
npm run test:ui
npm run build
npm run desktop:dev
npm run desktop:build
```

The browser tests require Chromium and Python Playwright as described in `README.md`. The desktop build requires Tauri 2 prerequisites and Rust installed. Do not report a stable 1.0 until these complete and the manual scenarios in `ACCEPTANCE.md` pass.

## High-value manual acceptance

1. With unsaved changes, click the custom titlebar X; verify **Keep editing** leaves the window open and **Discard and close** really exits. Repeat with Alt+F4, a clean document, and multiple dirty tabs.
2. Change a color repeatedly in the native Windows color picker while editing a 1920×1080 document. Verify typing/mouse interactions stay responsive and the final color persists. Record frame times on your actual machine rather than assuming 60 FPS.
3. Apply Gradient Map to a transparent image; add four differently colored stops, drag their positions, save/reopen and export. Verify dark pixels follow the first stop, highlights follow the last, intermediate tones interpolate, and transparency is preserved.
4. Change curve points and the per-tone Color Balance settings; verify they visibly modify preview and export. Check that Cancel and Undo each restore the original image.
5. Add multiple independent colored Shadow Forge entries; change offsets, softness and opacity; save/reopen and export PNG; ensure all remain editable.
6. Browse the 70 filters and 15 signature FX and confirm the correct unique icon and an actual generated sample thumbnail appear for each, without unexpected freezes.
7. Apply Oil Painting and Watercolor to the same photo and confirm they produce distinguishable appearances. Adjust all available sliders to extremes and verify their advertised effects, not merely some pixel changes.
8. Ensure existing `.spectrum` projects using old one-color Gradient Map and old shadows still open without data loss.

**Release caveat:** Automated pixel checks cannot prove visual polish, physical-media simulation fidelity, complete Windows close behavior or stable large-image performance.
