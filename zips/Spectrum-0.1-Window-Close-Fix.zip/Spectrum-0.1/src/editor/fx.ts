import { uid, type Effect, type EffectKind, type Layer } from './types';
import { FILTER_CATALOG, FILTER_CONTROL_MAP } from './effect-catalog';
import { applyEffect } from './effect-ops';
import { EFFECT_PARAMETER_SCHEMA, defaultParameters, DEFAULT_SHADOWS, DEFAULT_GRADIENT_STOPS } from './effect-schema';
import { effectPreviewScale } from './preview-quality';

export const EFFECT_CONTROLS = FILTER_CONTROL_MAP;
export const FILTERS: { kind: EffectKind; label: string; initial: number; group: string }[] = FILTER_CATALOG.map(
  ({ kind, label, initial, group }) => ({ kind, label, initial, group }),
);

/** Additional controls are interpreted by the effect processor, never just decoration. */
export const EFFECT_PARAMETERS = EFFECT_PARAMETER_SCHEMA;

export function clampEffectAmount(kind: EffectKind, amount: number): number {
  const descriptor = EFFECT_CONTROLS[kind];
  return Math.max(descriptor.min, Math.min(descriptor.max, Number.isFinite(amount) ? amount : descriptor.min));
}

export const FX_PRESETS: Record<string, {
  kind: EffectKind; amount: number; color?: string; parameters?: Effect['parameters'];
}[]> = {
  'Hyper Outline': [
    { kind: 'cutout', amount: 38 },
    { kind: 'outline', amount: 14, color: '#ffffff', parameters: { opacity: 100, softness: 0 } },
    { kind: 'glow', amount: 17, color: '#956fff', parameters: { spread: 0, softness: 18, opacity: 75 } },
  ],
  'Neon Pulse': [
    { kind: 'outline', amount: 6, color: '#28eeff' },
    { kind: 'glow', amount: 17, color: '#a44cff', parameters: { spread: 3, softness: 27, opacity: 85 } },
    { kind: 'contrast', amount: 124 },
  ],
  'Shadow Forge': [
    { kind: 'shadow', amount: 30, color: '#11111d', parameters: { shadows: [
      { ...DEFAULT_SHADOWS[0], id: 'fx-shadow-dark', offsetX: 15, offsetY: 17, radius: 11 },
      { ...DEFAULT_SHADOWS[1], id: 'fx-shadow-purple', enabled: true, offsetX: -8, offsetY: 4, radius: 29 },
    ] } },
  ],
  'Dream Bloom': [
    { kind: 'highlights', amount: 27 },
    { kind: 'glow', amount: 12, color: '#ffb9ee', parameters: { spread: 0, softness: 34, opacity: 65 } },
    { kind: 'vibrance', amount: 31 },
  ],
  'Glitch Matrix': [
    { kind: 'glitch', amount: 35, parameters: { density: 70, scanlines: 45, seed: 42, shiftY: 2 } },
    { kind: 'contrast', amount: 145 },
  ],
  'Comic Pop': [
    { kind: 'cartoon', amount: 68 },
    { kind: 'halftone', amount: 4, parameters: { angle: 42, inkOpacity: 35 } },
    { kind: 'comicink', amount: 68 },
    { kind: 'saturate', amount: 150 },
  ],
  'Frostbite': [
    { kind: 'temperature', amount: -50 },
    { kind: 'highpass', amount: 2 },
    { kind: 'outline', amount: 5, color: '#b8efff' },
    { kind: 'glow', amount: 12, color: '#3aa9ff', parameters: { softness: 26, spread: 0 } },
  ],
  'Ember Glow': [
    { kind: 'temperature', amount: 65 },
    { kind: 'wave', amount: 2, parameters: { frequency: 24, angle: 40 } },
    { kind: 'outline', amount: 5, color: '#ffba47' },
    { kind: 'glow', amount: 15, color: '#ff642e', parameters: { softness: 21, sparks: 64 } },
  ],
  'Prism Split': [
    { kind: 'gradientmap', amount: 20 },
    { kind: 'chromatic', amount: 9, parameters: { shiftY: 3, density: 5, seed: 8 } },
    { kind: 'glow', amount: 9, color: '#a66cff', parameters: { spread: 0, softness: 16 } },
  ],
  'Golden Hour': [
    { kind: 'temperature', amount: 48 },
    { kind: 'highlights', amount: 21 },
    { kind: 'shadows', amount: 12 },
    { kind: 'vibrance', amount: 25 },
  ],
  'Aurora Flow': [
    { kind: 'aurora', amount: 66 },
    { kind: 'glow', amount: 13, color: '#ad64f7', parameters: { softness: 20, spread: 0 } },
  ],
  'Electric Edge': [
    { kind: 'neonedge', amount: 92, color: '#42e2ff', parameters: { branching: 65, glowRadius: 12, seed: 42 } },
    { kind: 'glow', amount: 8, color: '#55a7ff', parameters: { softness: 15 } },
  ],
  'Holographic': [
    { kind: 'gradientmap', amount: 72, parameters: { stops: structuredClone(DEFAULT_GRADIENT_STOPS) } },
    { kind: 'aurora', amount: 24, parameters: { bands: 6, angle: 25 } },
    { kind: 'chromatic', amount: 4 },
    { kind: 'vibrance', amount: 58 },
  ],
  'Retro Vision': [
    { kind: 'crt', amount: 65 },
    { kind: 'chromatic', amount: 4, parameters: { scanlines: 30 } },
    { kind: 'vignette', amount: 55 },
  ],
  'Spectrum Burst': [
    { kind: 'burst', amount: 65 },
    { kind: 'glow', amount: 9, color: '#e77dff', parameters: { spread: 2, softness: 15 } },
  ],
};

export function newEffect(kind: EffectKind, amount?: number, color?: string, parameters?: Effect['parameters']): Effect {
  const definition = FILTERS.find(item => item.kind === kind);
  return {
    id: uid(), kind, enabled: true,
    amount: clampEffectAmount(kind, amount ?? definition?.initial ?? 100),
    color,
    parameters: { ...defaultParameters(kind), ...structuredClone(parameters ?? {}) },
  };
}

/** CSS filter representation kept for SVG compatibility and quick previews. */
export function effectFilter(effect: Effect): string {
  const amount = clampEffectAmount(effect.kind, effect.amount);
  if (effect.kind === 'hue') return `hue-rotate(${amount}deg)`;
  if (effect.kind === 'blur') return `blur(${amount}px)`;
  if (['brightness', 'contrast', 'saturate', 'grayscale', 'sepia', 'invert'].includes(effect.kind)) {
    const name = effect.kind === 'saturate' ? 'saturate' : effect.kind;
    return `${name}(${amount}%)`;
  }
  return 'none';
}

/** Non-destructive effect graph shared by editor, frame export, and image export. */
export function processEffects(source: HTMLCanvasElement, effects: readonly Effect[]): HTMLCanvasElement {
  let current = source;
  for (const effect of effects) {
    if (!effect.enabled) continue;
    const controls = EFFECT_CONTROLS[effect.kind];
    // A zero setting is a meaningful state for several effects; never use a universal "amount > 0" guard.
    if (effect.kind === 'outline' && effect.amount === 0) continue;
    if (effect.kind === 'cutout' && effect.amount === 0) continue;
    if (controls && !Number.isFinite(effect.amount)) continue;
    current = applyEffect(current, effect);
  }
  return current;
}

const effectCache = new WeakMap<Layer, { width: number; height: number; scale: number; image: HTMLCanvasElement }>();

export function renderWithEffects(
  ctx: CanvasRenderingContext2D,
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
): void {
  const effects = layer.effects ?? [];
  if (!effects.some(effect => effect.enabled)) {
    paint(ctx, layer);
    return;
  }
  const scale = effectPreviewScale(width, height);
  const cached = layer.type === 'vector' ? effectCache.get(layer) : undefined;
  if (cached && cached.width === width && cached.height === height && cached.scale === scale) {
    ctx.drawImage(cached.image, 0, 0, width, height);
    return;
  }
  const source = document.createElement('canvas');
  source.width = Math.max(1, Math.floor(width * scale));
  source.height = Math.max(1, Math.floor(height * scale));
  const temporary = source.getContext('2d');
  if (!temporary) return;
  temporary.scale(scale, scale);
  paint(temporary, layer);
  const processed = processEffects(source, effects);
  if (layer.type === 'vector') effectCache.set(layer, { width, height, scale, image: processed });
  ctx.drawImage(processed, 0, 0, width, height);
}
