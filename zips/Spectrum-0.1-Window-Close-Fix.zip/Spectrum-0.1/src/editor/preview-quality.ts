/** Interactive FX should prioritize pointer latency. Final rendering and exports use full quality. */
let interactive = false;

export function setInteractiveEffectPreview(active: boolean): void {
  interactive = active;
}

export function effectPreviewScale(width: number, height: number): number {
  const maxPixels = interactive ? 900_000 : 16_000_000;
  return Math.min(1, Math.sqrt(maxPixels / Math.max(1, width * height)));
}
