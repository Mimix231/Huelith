export type BlendMode = 'source-over'|'multiply'|'screen'|'overlay'|'darken'|'lighten';
export type RasterLayer = { id:string;type:'raster';name:string;visible:boolean;locked:boolean;opacity:number;blend:BlendMode; image:string; x:number;y:number;};
export type VectorShape = {id:string;kind:'rect'|'ellipse'|'path'|'line'|'text'; x:number;y:number;width:number;height:number;fill:string;stroke:string;strokeWidth:number;points?:{x:number;y:number}[];text?:string;fontSize?:number;fontFamily?:string;};
export type VectorLayer = {id:string;type:'vector';name:string;visible:boolean;locked:boolean;opacity:number;blend:BlendMode;shapes:VectorShape[];x:number;y:number;};
export type GroupLayer = {id:string;type:'group';name:string;visible:boolean;locked:boolean;opacity:number;blend:BlendMode;children:Layer[];x:number;y:number;};
export type Layer=RasterLayer|VectorLayer|GroupLayer;
export type Document = {format:'spectrum';version:1;id:string;name:string;width:number;height:number;background:string;layers:Layer[];activeLayerId:string|null;createdAt:string;updatedAt:string;};
export type Tool = 'move'|'hand'|'brush'|'eraser'|'eyedropper'|'rectangle'|'ellipse'|'line'|'pen'|'text';
export const uid=()=>globalThis.crypto?.randomUUID?.()??`s-${Date.now()}-${Math.random().toString(36).slice(2)}`;
export const makeRaster=(name='Paint layer'):RasterLayer=>({id:uid(),type:'raster',name,visible:true,locked:false,opacity:1,blend:'source-over',image:'',x:0,y:0});
export const makeVector=(name='Vector layer'):VectorLayer=>({id:uid(),type:'vector',name,visible:true,locked:false,opacity:1,blend:'source-over',shapes:[],x:0,y:0});
export function createDocument(name='Untitled',width=1280,height=800,background='#ffffff'):Document { const layer=makeRaster();return {format:'spectrum',version:1,id:uid(),name,width,height,background,layers:[layer],activeLayerId:layer.id,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}; }
export const isDocument=(d:unknown):d is Document=>{if(!d||typeof d!=='object')return false;const v=d as Record<string,unknown>;return v.format==='spectrum'&&v.version===1&&typeof v.width==='number'&&typeof v.height==='number'&&v.width>=1&&v.width<=16384&&v.height>=1&&v.height<=16384&&Array.isArray(v.layers)&&typeof v.name==='string';};
export function flattenLayers(layers:Layer[]):Layer[]{return layers.flatMap(l=>l.type==='group'?[l,...flattenLayers(l.children)]:[l]);}
export function layerById(doc:Document,id:string|null):Layer|undefined{return flattenLayers(doc.layers).find(l=>l.id===id);}
