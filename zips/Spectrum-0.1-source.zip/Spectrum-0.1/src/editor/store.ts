import {create} from 'zustand';
import {createDocument,makeRaster,makeVector,uid,layerById,type Document,type Layer,type Tool,type VectorShape} from './types';
const clone=<T,>(v:T):T=>structuredClone(v);
type Workspace='glass'|'material'|'classic';
type Tab={doc:Document;past:Document[];future:Document[];dirty:boolean;path?:string};
type Store={tabs:Tab[];activeId:string;tool:Tool;color:string;fill:string;strokeWidth:number;opacity:number;zoom:number;pan:{x:number;y:number};workspace:Workspace;grid:boolean;showWelcome:boolean;selectedShapeId:string|null;
 setTool:(t:Tool)=>void;setColor:(c:string)=>void;setFill:(c:string)=>void;setStrokeWidth:(v:number)=>void;setOpacity:(v:number)=>void;setZoom:(v:number)=>void;setPan:(p:{x:number;y:number})=>void;setWorkspace:(w:Workspace)=>void;setGrid:(v:boolean)=>void;setWelcome:(v:boolean)=>void;selectShape:(id:string|null)=>void;
 newDoc:(name?:string,w?:number,h?:number,bg?:string)=>void;openDoc:(doc:Document,path?:string)=>void;closeDoc:(id:string)=>void;activate:(id:string)=>void;mutate:(fn:(d:Document)=>void)=>void;undo:()=>void;redo:()=>void;markSaved:(path?:string)=>void;addLayer:(type:'raster'|'vector')=>void;duplicateLayer:()=>void;removeLayer:()=>void;selectLayer:(id:string)=>void;moveLayer:(id:string,step:number)=>void;toggleLayer:(id:string,field:'visible'|'locked')=>void;renameLayer:(id:string,name:string)=>void;setLayerOpacity:(id:string,opacity:number)=>void;addShape:(shape:VectorShape)=>void;updateShape:(id:string,fn:(shape:VectorShape)=>void)=>void;};
const first=createDocument('Welcome canvas',1280,800,'#ffffff');
export const useEditor=create<Store>((set,get)=>({
 tabs:[{doc:first,past:[],future:[],dirty:false}],activeId:first.id,tool:'brush',color:'#8e83ff',fill:'#8e83ff',strokeWidth:12,opacity:1,zoom:.8,pan:{x:0,y:0},workspace:'glass',grid:false,showWelcome:true,selectedShapeId:null,
 setTool:tool=>set({tool}),setColor:color=>set({color}),setFill:fill=>set({fill}),setStrokeWidth:strokeWidth=>set({strokeWidth}),setOpacity:opacity=>set({opacity}),setZoom:zoom=>set({zoom:Math.max(.05,Math.min(32,zoom))}),setPan:pan=>set({pan}),setWorkspace:workspace=>set({workspace}),setGrid:grid=>set({grid}),setWelcome:showWelcome=>set({showWelcome}),selectShape:selectedShapeId=>set({selectedShapeId}),
 newDoc:(name,w,h,bg)=>{const doc=createDocument(name,w,h,bg);set(s=>({tabs:[...s.tabs,{doc,past:[],future:[],dirty:false}],activeId:doc.id,showWelcome:false,pan:{x:0,y:0},selectedShapeId:null}));},
 openDoc:(doc,path)=>{const opened=clone({...doc,id:uid()});set(s=>({tabs:[...s.tabs,{doc:opened,past:[],future:[],dirty:false,path}],activeId:opened.id,showWelcome:false,pan:{x:0,y:0}}));},
 closeDoc:id=>set(s=>{const tabs=s.tabs.filter(t=>t.doc.id!==id);if(!tabs.length){const doc=createDocument();return{tabs:[{doc,past:[],future:[],dirty:false}],activeId:doc.id,showWelcome:true};}return{tabs,activeId:s.activeId===id?tabs[tabs.length-1].doc.id:s.activeId};}),
 activate:activeId=>set({activeId,showWelcome:false,selectedShapeId:null}),
 mutate:fn=>set(s=>({tabs:s.tabs.map(t=>{if(t.doc.id!==s.activeId)return t;const next=clone(t.doc);fn(next);next.updatedAt=new Date().toISOString();return {...t,doc:next,past:[...t.past.slice(-39),t.doc],future:[],dirty:true};})})),
 undo:()=>set(s=>({tabs:s.tabs.map(t=>{if(t.doc.id!==s.activeId||!t.past.length)return t;return{...t,doc:t.past[t.past.length-1],past:t.past.slice(0,-1),future:[...t.future,t.doc],dirty:true};})})),
 redo:()=>set(s=>({tabs:s.tabs.map(t=>{if(t.doc.id!==s.activeId||!t.future.length)return t;return{...t,doc:t.future[t.future.length-1],past:[...t.past,t.doc],future:t.future.slice(0,-1),dirty:true};})})),
 markSaved:path=>set(s=>({tabs:s.tabs.map(t=>t.doc.id===s.activeId?{...t,dirty:false,path:path??t.path}:t)})),
 addLayer:type=>get().mutate(d=>{const layer=type==='raster'?makeRaster():makeVector();d.layers.push(layer);d.activeLayerId=layer.id;}),
 duplicateLayer:()=>get().mutate(d=>{const index=d.layers.findIndex(l=>l.id===d.activeLayerId);if(index<0)return;const copied=clone(d.layers[index]);copied.id=uid();copied.name+=' copy';d.layers.splice(index+1,0,copied);d.activeLayerId=copied.id;}),
 removeLayer:()=>get().mutate(d=>{if(d.layers.length===1)return;d.layers=d.layers.filter(l=>l.id!==d.activeLayerId);d.activeLayerId=d.layers[d.layers.length-1]?.id??null;}),
 selectLayer:id=>set(s=>({tabs:s.tabs.map(t=>t.doc.id===s.activeId?{...t,doc:{...t.doc,activeLayerId:id}}:t)})),
 moveLayer:(id,step)=>get().mutate(d=>{const i=d.layers.findIndex(l=>l.id===id);const n=i+step;if(i<0||n<0||n>=d.layers.length)return;[d.layers[i],d.layers[n]]=[d.layers[n],d.layers[i]];}),
 toggleLayer:(id,field)=>get().mutate(d=>{const l=layerById(d,id);if(l)l[field]=!l[field];}),
 renameLayer:(id,name)=>get().mutate(d=>{const l=layerById(d,id);if(l)l.name=name;}),
 setLayerOpacity:(id,opacity)=>get().mutate(d=>{const l=layerById(d,id);if(l)l.opacity=opacity;}),
 addShape:shape=>get().mutate(d=>{let l=layerById(d,d.activeLayerId);if(l?.type!=='vector'){const v=makeVector();d.layers.push(v);d.activeLayerId=v.id;l=v;}if(l.type==='vector')l.shapes.push(shape);}),
 updateShape:(id,fn)=>get().mutate(d=>{for(const l of d.layers){if(l.type==='vector'){const s=l.shapes.find(s=>s.id===id);if(s){fn(s);break;}}}}),
}));
export const activeTab=(s:Store)=>s.tabs.find(t=>t.doc.id===s.activeId)??s.tabs[0];
export const activeLayer=(s:Store):Layer|undefined=>layerById(activeTab(s).doc,activeTab(s).doc.activeLayerId);
