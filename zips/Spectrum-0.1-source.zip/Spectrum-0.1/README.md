# Spectrum 0.1 🌈

**Create without limits.** Spectrum is an experimental, completely free and open-source hybrid raster/vector creative editor using React, TypeScript, Material UI and Tauri 2.

> 0.1 is a first functional milestone, **not yet a Photoshop / Illustrator replacement**. The canvas currently uses Canvas2D rather than a GPU tile renderer, paths are freehand vector polylines rather than editable Bézier curves, and advanced selections, masks, effects, groups UI and PSD support are future work.

## Start using it

Prerequisites: Node.js 20+ and npm. For desktop builds, install a Rust toolchain and Tauri 2's platform prerequisites (Windows: WebView2 and Visual Studio C++ build tools; Linux: WebKitGTK development dependencies; macOS: Xcode Command Line Tools).

```bash
npm install
npm run dev
```

Open `http://127.0.0.1:1420` in a browser. The browser version includes all editor tools and exports files using the browser's download dialog.

For the native desktop window:

```bash
npm run desktop:dev
```

For a native distributable:

```bash
npm run desktop:build
```

## What works

- Multiple documents, new document dialog, transparent or colored background, configurable size.
- Painting on raster layers, erasing, eyedropper; vector rectangles, ellipses, straight lines, freehand paths, and text.
- Vector and raster layers, opacity, visibility, lock, duplicate, rename (double-click), reorder and remove.
- Move tool (drag a vector object or a layer), pan tool, zoom via Ctrl+wheel or toolbar, optional grid.
- Undo/redo (40 whole-document snapshots per document), tab management, shortcuts.
- `.spectrum` editable JSON project save/open, containing embedded raster PNG data URLs.
- Import PNG/JPEG/WebP/GIF/BMP as a layer; export flattened PNG/JPEG/WebP and hybrid SVG.
- Three appearance presets: Glass, Material, Classic.
- Tauri desktop save/open dialogs; works in a browser during development too.

## Keyboard shortcuts

`Ctrl+N` new · `Ctrl+O` open project · `Ctrl+S` save · `Ctrl+Shift+S` save as · `Ctrl+Z` undo · `Ctrl+Shift+Z` / `Ctrl+Y` redo · `Ctrl+D` duplicate layer. Tools: `V` move, `H` hand, `B` brush, `E` eraser, `I` eyedropper, `R` rectangle, `O` ellipse, `L` line, `P` freehand vector, `T` text. Middle-button drag pans the canvas. Mouse wheel pans; Ctrl+wheel zooms.

## Known 0.1 limitations

- The project saves as plain JSON with embedded images, not a compressed archive; big documents can become large.
- Raster editing is a full-layer bitmap update, and undo uses snapshots: RAM usage grows with resolution/history.
- Eraser strokes operate on the active raster layer; raster coordinates are stored in document pixels.
- Selection is simple bounding-box hit testing for vector objects; no Bézier node editing yet.
- SVG export includes raster layers as embedded PNG image tags and editable vector primitives. It is not guaranteed to reproduce every blend mode, and grouped layers are not yet supported in SVG export.
- IndexedDB autosave snapshots and recovery-on-start are available, but recovery capacity depends on browser storage quotas. Masked adjustment layers, color management, PSD, RAW, print-preparation workflows and advanced graphics acceleration are **not yet implemented**.
- Tauri requires a local Rust toolchain for a desktop build; the ZIP contains source, not a compiled installer.

## Architecture

- `src/editor/types.ts`: typed document schema and layer constructors.
- `src/editor/store.ts`: Zustand workspace, history and document operations.
- `src/editor/render.ts`: Canvas2D compositing and raster image cache.
- `src/editor/files.ts`: browser/native project I/O, image import/export and SVG export.
- `src/components/Canvas.tsx`: pointer-tool interactions and display transform.
- `src/App.tsx`: MUI editor shell, menus, controls and panels.
- `src-tauri/`: minimal native Tauri 2 shell with FS and dialog plugins.

## License & sustainability

GPL-3.0-or-later. Official releases are intended to be free, without ads, subscriptions or feature paywalls. Voluntary donations may support the project. No donations infrastructure or telemetry is present in this milestone.

Made as a foundation that can be improved by the open-source community.
