# Huelith — Dedicated Effects Implementation, 30 October 2026

**Base archive:** `Huelith[Dev](1).zip` (freshly extracted; earlier assistant patches not merged).

## Scope and status

This pass replaces **eight** entries of the 120 expansion processors with real production implementations, each in a dedicated TypeScript file under `src/editor/effects/`. They are executed from the existing `createExpansion120Job` path, which is used by the cooperative effect worker **and** the synchronous export pipeline. `expansion-120.ts` retains the remaining 112 older implementations. No source effect is called "finished" by mere registration.

| Catalog entry | Independent file | What was implemented | Remaining limitation |
| --- | --- | --- | --- |
| Manga Screentones (`atelier_4_0`) | `manga-screentones.ts` | Rotated periodic AM-dot halftoning with tonal dot-area coverage, adjustable pitch/angle, scene-adaptive tonal mapping and alpha preservation | Pure monochrome printing style; no region-aware subject masking or separate black-line extraction |
| Pixel Sorting (`atelier_3_12`) | `pixel-sorting.ts` | True, stable luminance sorting of selected contiguous rows or columns with pixel/alpha tuple conservation | No arbitrary-angle line traversal or multiple sort keys |
| Film Halation (`atelier_7_0`) | `film-halation.ts` | Highlight-threshold mask plus tight/wide spatial diffusion with warm RGB spill beyond transparent illuminated subjects | Stylized approximation to film-stock halation; not calibrated to optical film stock |
| Anamorphic Streak (`atelier_7_1`) | `anamorphic-streak.ts` | Row-local bidirectional exponentially decaying light transport originating from bright source pixels, with blue spectral bias | Not a full optical lens diffraction model |
| Rolling Shutter (`atelier_7_10`) | `rolling-shutter.ts` | Coherent scanline displacement with alpha-correct horizontal interpolation and edge extension | Synthetic readout waveform; does not infer real camera/object motion |
| Lens Ghost (`atelier_7_2`) | `lens-ghost.ts` | Four oppositely reflected and differently scaled high-brightness image ghosts around editable optical center | Simplified lens-element optics; no aperture-shape PSF or coatings simulation |
| Stained Glass (`atelier_2_15`) | `stained-glass.ts` | Seeded Voronoi tessellation, opacity-weighted mean pane colors, irregular leading and transparent-region preservation | No 3D refraction, glass thickness or physical light transmission |
| Split Diopter (`atelier_7_11`) | `split-diopter.ts` | User-positioned and rotatable split-focus mask with premultiplied-alpha defocus convolution | Flat images contain no depth map: cannot simulate actual optical dual-plane focus without depth information |

Shared mathematical helpers live in `src/editor/effects/common.ts`; these aren't substitute artist-facing effects. The new index maps **only** those eight IDs. All other entries retain their previous processing behavior.

## Integration

- `src/editor/expansion-120.ts` delegates these eight IDs to dedicated processors. They run in cooperative scanline slices, and the exact same implementation is used for final processing.
- `src/editor/effect-schema.ts` defines only controls those eight implementations actually consume; defaults and documented slider ranges are checked in pixel tests.
- Zero-intensity applied to an expanded effect returns its original source exactly, including hidden RGB.
- Transparent margins are respected. Lighting effects can produce alpha only where highlighted source energy is transported; non-lighting effects preserve or geometrically transform alpha according to their purpose.
- Legacy Node test harnesses were updated to resolve nested TypeScript imports correctly. Assertions were **not** relaxed to conceal regressions.

## Verification actually performed

- `npm test`: **388 passed, 0 failed**. Includes 29 dedicated-effect tests for identity at zero, chunked-vs-synchronous fidelity, controls, pixel sort conservation, transparency, anamorphic falloff and optical ghosts.
- `tsc -p tsconfig.effects.json --noEmit`: **passed** under strict TypeScript checks for changed processing and schema code.
- Visual contact-sheet inspected using the bundled `DrawingArtwork.png` (not an automated similarity certification). Changes made after inspection include improving manga tonal mapping, stronger localized streaks, and edge-extended rolling shutter.
- `npm run check` / full Vite+Tauri build: **not verified**, because the uploaded source contains no complete `node_modules`, and dependency installation timed out in this environment. Full application behavior on Windows was not tested here.
- Rust build: **not attempted**; this pass is connected production **TypeScript/worker** code. No unused new `.rs` files are being passed off as a Rust migration.

### CPU-only reference performance (median of 3, Node 22, 1920×1080; includes effect preparation)

| Effect | ms per exact render |
| --- | ---: |
| Manga Screentones | 166.0 |
| Pixel Sorting | 63.5 |
| Film Halation | 116.9 |
| Anamorphic Streak | 70.4 |
| Rolling Shutter | 57.4 |
| Lens Ghost | 137.1 |
| Stained Glass | 222.6 |
| Split Diopter | 200.3 |

These measurements do **not** establish 60 FPS. Several effects exceed the 16.7ms budget at 1080p. Running on the worker keeps expensive calculations off the UI thread, but the number of accurate image updates per second remains limited by kernel throughput. GPU compute and cached/retained frame buffers are still necessary for substantially better responsiveness.

## Open work

1. Artist acceptance tests for each new look (automatic pixel tests are necessary but not sufficient).
2. Verified Windows app build and desktop integration; performance with multiple effect layers, animation and exports.
3. GPU implementations and benchmarking for effects that must update at high FPS. Avoid approximating away features.
4. Migration and reconstruction of the remaining 112 expanded entries plus unfinished legacy Creativity/Effects/FX entries.
5. Renderer cancellation within expensive kernel preparation; currently large preparatory computations can block an individual worker event-loop turn.

**Claims:** Eight meaningful replacements implemented and tested as described. **Not claimed:** complete 221-effect library, complete native Rust port, flawless artistic fidelity, or 60 FPS on arbitrary artwork.
