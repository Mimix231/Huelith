import {blurRgba,clamp,mix,smooth,type EffectFactory} from './common';
/** Single-image split-diopter approximation: focus separation across a
 * rotatable split field, with a narrow optical transition seam. A still image
 * has no scene-depth information; this does not claim true depth refocusing.
 */
export const splitDiopter:EffectFactory=({source,width:w,height:h,amount,parameters:p})=>{
  const cx=w*(p.centerX??50)/100,cy=h*(p.centerY??50)/100;
  const angle=(p.angle??20)*Math.PI/180,cs=Math.cos(angle),sn=Math.sin(angle);
  const scale=Math.min(w,h),radius=Math.max(1,Math.min(48,Math.round(1+scale*.01+12*clamp((p.frequency??50)/150))));
  const blurred=blurRgba(source,w,h,radius);
  return {renderRows(y0,y1,out){for(let y=y0;y<y1;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4;
    const distance=(x-cx)*cs+(y-cy)*sn;
    // Distinct focal zones separated by a visible but softened split line.
    const mixBlur=smooth(-2,2,distance)*amount;
    const a=source[i+3]/255,b=blurred[i+3]/255;
    const combined=mix(a,b,mixBlur);
    if(combined<=1e-6){out.set(source.subarray(i,i+4),i);continue;}
    for(let c=0;c<3;c++)out[i+c]=((source[i+c]*a*(1-mixBlur))+(blurred[i+c]*b*mixBlur))/combined;
    out[i+3]=combined*255;
  }}};
};
