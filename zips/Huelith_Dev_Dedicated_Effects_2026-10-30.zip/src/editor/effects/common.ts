/** Pixel-only primitives shared by individually authored, non-destructive effects.
 * All source buffers are immutable. No browser globals: usable from the WebWorker,
 * synchronous export, and deterministic Node regression tests.
 */
import type { EffectParameters } from '../types';
export interface EffectInput {
  readonly source: Uint8ClampedArray;
  readonly width: number;
  readonly height: number;
  readonly amount: number;
  readonly parameters: Readonly<EffectParameters>;
}
export interface EffectKernel { renderRows(first: number, last: number, destination: Uint8ClampedArray): void }
export type EffectFactory = (input: EffectInput) => EffectKernel;
export const clamp = (v: number, min = 0, max = 1): number => Math.min(max, Math.max(min, Number.isFinite(v) ? v : min));
export const mix = (a: number, b: number, t: number): number => a + (b-a)*clamp(t);
export const luminance = (r:number,g:number,b:number):number => .2126*r+.7152*g+.0722*b;
export const smooth = (a:number,b:number,v:number):number => {const t=clamp((v-a)/(b-a||1));return t*t*(3-2*t);};
export function hash(x:number,y:number,seed:number):number {
  let n=Math.imul(x+139,374761393)^Math.imul(y+53,668265263)^Math.imul(seed+11,1274126177);
  n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295;
}
/** RGBA bilinear interpolation in premultiplied-alpha space. Outside source = transparent.
 * Avoids the familiar dark/colored fringe created by sampling RGB independently of alpha.
 */
export function samplePremultiplied(source: Uint8ClampedArray, w:number,h:number,x:number,y:number):[number,number,number,number]{
  const ix=Math.floor(x),iy=Math.floor(y),tx=x-ix,ty=y-iy;
  let pr=0,pg=0,pb=0,pa=0;
  for(let yy=0;yy<=1;yy++)for(let xx=0;xx<=1;xx++){
    const sx=ix+xx,sy=iy+yy;
    if(sx<0||sx>=w||sy<0||sy>=h)continue;
    const f=(xx?tx:1-tx)*(yy?ty:1-ty),i=(sy*w+sx)*4,a=source[i+3]/255;
    pa+=f*a;pr+=f*a*source[i];pg+=f*a*source[i+1];pb+=f*a*source[i+2];
  }
  return pa>1e-8?[pr/pa,pg/pa,pb/pa,pa*255]:[0,0,0,0];
}
/** A normalized, separable square blur of arbitrary scalar masks, O(width*height).
 * Padding is zero, so a highlight can radiate outside the original alpha silhouette.
 */
export function blurScalar(src:Float32Array,w:number,h:number,radius:number):Float32Array{
  const r=Math.max(0,Math.min(512,Math.round(radius)));
  if(!r)return new Float32Array(src);
  const tmp=new Float32Array(src.length),dst=new Float32Array(src.length),size=2*r+1;
  for(let y=0;y<h;y++){
    let sum=0;const row=y*w;
    for(let x=-r;x<=r;x++)if(x>=0&&x<w)sum+=src[row+x];
    for(let x=0;x<w;x++){
      tmp[row+x]=sum/size;
      if(x-r>=0)sum-=src[row+x-r];if(x+r+1<w)sum+=src[row+x+r+1];
    }
  }
  for(let x=0;x<w;x++){
    let sum=0;for(let y=-r;y<=r;y++)if(y>=0&&y<h)sum+=tmp[y*w+x];
    for(let y=0;y<h;y++){
      dst[y*w+x]=sum/size;
      if(y-r>=0)sum-=tmp[(y-r)*w+x];if(y+r+1<h)sum+=tmp[(y+r+1)*w+x];
    }
  }
  return dst;
}
/** Blur a source with premultiplied alpha; never borrow RGB from transparent pixels. */
export function blurRgba(source:Uint8ClampedArray,w:number,h:number,radius:number):Uint8ClampedArray {
  const channels=Array.from({length:4},()=>new Float32Array(w*h));
  for(let p=0;p<w*h;p++){
    const i=p*4,a=source[i+3]/255;
    channels[0][p]=source[i]*a;channels[1][p]=source[i+1]*a;channels[2][p]=source[i+2]*a;channels[3][p]=a;
  }
  const [r,g,b,a]=channels.map(ch=>blurScalar(ch,w,h,radius));
  const dst=new Uint8ClampedArray(source.length);
  for(let p=0;p<w*h;p++){
    const i=p*4,alpha=a[p];if(alpha<1e-5)continue;
    dst[i]=r[p]/alpha;dst[i+1]=g[p]/alpha;dst[i+2]=b[p]/alpha;dst[i+3]=alpha*255;
  }
  return dst;
}
export function writeMixed(src:Uint8ClampedArray,out:Uint8ClampedArray,i:number,color:readonly number[],amount:number,alpha=src[i+3]):void {
  const t=clamp(amount);out[i]=mix(src[i],color[0],t);out[i+1]=mix(src[i+1],color[1],t);
  out[i+2]=mix(src[i+2],color[2],t);out[i+3]=mix(src[i+3],alpha,t);
}
export function highlightMask(src:Uint8ClampedArray,w:number,h:number,threshold:number):Float32Array {
  const out=new Float32Array(w*h);const t=clamp(threshold/255,0,.99);
  for(let p=0;p<w*h;p++){
    const i=4*p,a=src[i+3]/255;
    const l=luminance(src[i],src[i+1],src[i+2])/255;
    out[p]=a*smooth(t,Math.min(1,t+.22),l);
  }
  return out;
}
