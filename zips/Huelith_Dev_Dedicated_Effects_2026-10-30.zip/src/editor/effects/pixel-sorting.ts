import {clamp,luminance,mix,type EffectFactory} from './common';
/** Sorts coherent threshold-selected row/column runs, preserving the exact
 * source color/alpha tuples. A real sort, never RGB channel displacement.
 */
export const pixelSorting:EffectFactory=({source,width:w,height:h,amount,parameters:p})=>{
  const threshold=clamp((p.threshold??45)/100)*255;
  const vertical=Math.abs(Math.sin((p.angle??0)*Math.PI/180))>.707;
  const sorted=new Uint8ClampedArray(source);
  const length=vertical?h:w,lanes=vertical?w:h;
  const point=(lane:number,t:number)=>vertical?(t*w+lane)*4:(lane*w+t)*4;
  for(let lane=0;lane<lanes;lane++){
    let t=0;
    while(t<length){
      const eligible=(k:number)=>{const i=point(lane,k);return source[i+3]>0&&luminance(source[i],source[i+1],source[i+2])>=threshold;};
      if(!eligible(t)){t++;continue;}
      const start=t;while(t<length&&eligible(t))t++;
      if(t-start<2)continue;
      const pixels:Array<{c:[number,number,number,number],l:number}>=[];
      for(let k=start;k<t;k++){
        const i=point(lane,k);pixels.push({c:[source[i],source[i+1],source[i+2],source[i+3]],l:luminance(source[i],source[i+1],source[i+2])});
      }
      pixels.sort((a,b)=>a.l-b.l);
      for(let k=start;k<t;k++)sorted.set(pixels[k-start].c,point(lane,k));
    }
  }
  return {renderRows(y0,y1,out){for(let y=y0;y<y1;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4;for(let c=0;c<4;c++)out[i+c]=mix(source[i+c],sorted[i+c],amount);
  }}};
};
