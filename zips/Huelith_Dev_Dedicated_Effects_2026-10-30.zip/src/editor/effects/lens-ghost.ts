import {blurScalar,clamp,highlightMask,type EffectFactory} from './common';
/** Multi-element optical ghosting. Intense source features reappear as faint,
 * inverted, differently scaled spectral reflections about the optical axis.
 */
export const lensGhost:EffectFactory=({source,width:w,height:h,amount,parameters:p})=>{
  const cx=w*(p.centerX??50)/100,cy=h*(p.centerY??50)/100;
  const scale=Math.min(w,h);const radius=Math.max(1,Math.round(1+scale*.009+8*clamp((p.frequency??50)/150)));
  const blurred=blurScalar(highlightMask(source,w,h,p.threshold??172),w,h,radius);
  // Each ghost is an inverted image with a distinct optical magnification.
  const elements=[{m:-.23,c:[94,153,255],weight:.75},{m:-.48,c:[220,110,170],weight:.50},
    {m:-.82,c:[96,255,179],weight:.38},{m:-1.3,c:[255,184,98],weight:.22}];
  const spectrum=clamp((p.colorMix??50)/100);
  return {renderRows(y0,y1,out){for(let y=y0;y<y1;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4,a=source[i+3]/255;
    let lr=0,lg=0,lb=0,emission=0;
    for(const e of elements){
      const gx=cx+(x-cx)/e.m,gy=cy+(y-cy)/e.m;
      if(gx<0||gy<0||gx>=w-1||gy>=h-1)continue;
      const sx=Math.round(gx),sy=Math.round(gy),energy=blurred[sy*w+sx]*e.weight;
      lr+=energy*e.c[0];lg+=energy*e.c[1];lb+=energy*e.c[2];emission+=energy;
    }
    const intensity=amount*(.45+.55*spectrum);
    if(a>0){out[i]=source[i]+lr*intensity;out[i+1]=source[i+1]+lg*intensity;out[i+2]=source[i+2]+lb*intensity;out[i+3]=source[i+3];}
    else if(emission<1e-7)out.set(source.subarray(i,i+4),i);
    else {out[i]=emission>1e-7?lr/emission:0;out[i+1]=emission>1e-7?lg/emission:0;out[i+2]=emission>1e-7?lb/emission:0;out[i+3]=clamp(emission*intensity*12)*180;}
  }}};
};
