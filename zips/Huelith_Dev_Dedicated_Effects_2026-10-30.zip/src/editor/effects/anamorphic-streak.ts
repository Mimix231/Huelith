import {clamp,highlightMask,type EffectFactory} from './common';
/** Horizontal anamorphic lens flare from individual bright source pixels.
 * Two exponentially decaying row recurrences run in O(pixels), rather than
 * placing a full-width horizontal stripe at every highlight's y coordinate.
 */
export const anamorphicStreak:EffectFactory=({source,width:w,height:h,amount,parameters:p})=>{
  const src=highlightMask(source,w,h,p.threshold??174),streak=new Float32Array(w*h);
  const spread=clamp((p.frequency??50)/150);
  const length=Math.max(2,w*(.015+.14*spread));
  const decay=Math.exp(-1/length);const norm=1-decay;
  for(let y=0;y<h;y++){
    let light=0;
    for(let x=0;x<w;x++){const k=y*w+x;light=src[k]*norm+light*decay;streak[k]+=light;}
    light=0;
    for(let x=w-1;x>=0;x--){const k=y*w+x;light=src[k]*norm+light*decay;streak[k]+=light;}
  }
  const blue=clamp((p.colorMix??50)/100);
  return {renderRows(y0,y1,out){for(let y=y0;y<y1;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4,k=y*w+x,a=source[i+3]/255;
    const light=clamp(Math.max(0,streak[k]-src[k]*norm*2)*15*amount);
    if(a>0){out[i]=source[i]+light*(82-30*blue);out[i+1]=source[i+1]+light*112;out[i+2]=source[i+2]+light*(90+92*blue);out[i+3]=source[i+3];}
    else if(light<1e-6)out.set(source.subarray(i,i+4),i);
    else {out[i]=90-40*blue;out[i+1]=146;out[i+2]=185+55*blue;out[i+3]=light*150;}
  }}};
};
