import {blurScalar,clamp,highlightMask,type EffectFactory} from './common';
/** Silver-halide-inspired red/orange highlight diffusion: independent broad
 * and tight scattering, extending outside illuminated source silhouettes.
 */
export const filmHalation:EffectFactory=({source,width:w,height:h,amount,parameters:p})=>{
  const scale=Math.max(1,Math.min(w,h));const spread=clamp((p.frequency??50)/150);
  const radius=Math.max(1,Math.round(1+scale*.012+12*spread));
  const mask=highlightMask(source,w,h,Math.max(90,Math.min(235,p.threshold??172)));
  const tight=blurScalar(mask,w,h,radius),wide=blurScalar(mask,w,h,radius*3);
  const warmth=clamp((p.colorMix??50)/100);
  return {renderRows(y0,y1,out){for(let y=y0;y<y1;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4,k=y*w+x,a=source[i+3]/255;
    const light=clamp((tight[k]*.8+wide[k]*1.8)*amount);
    const rr=source[i]+light*(96+68*warmth),gg=source[i+1]+light*(19+28*warmth),bb=source[i+2]+light*5;
    if(a>0){out[i]=rr;out[i+1]=gg;out[i+2]=bb;out[i+3]=source[i+3];}
    else if(light<1e-6)out.set(source.subarray(i,i+4),i);
    else {out[i]=225+warmth*30;out[i+1]=66+warmth*30;out[i+2]=19;out[i+3]=light*140;}
  }}};
};
