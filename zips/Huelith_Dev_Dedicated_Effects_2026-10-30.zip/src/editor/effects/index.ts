/** Production expansion-effect implementations. Every entry is an independent
 * processor with shared low-level pixel primitives, not a renamed preset.
 * This registry is consumed by BOTH the cooperative worker and synchronous export.
 */
import type { EffectFactory } from './common';
import { mangaScreentones } from './manga-screentones';
import { pixelSorting } from './pixel-sorting';
import { filmHalation } from './film-halation';
import { anamorphicStreak } from './anamorphic-streak';
import { rollingShutter } from './rolling-shutter';
import { lensGhost } from './lens-ghost';
import { stainedGlass } from './stained-glass';
import { splitDiopter } from './split-diopter';
export const DEDICATED_EFFECTS:ReadonlyMap<string,EffectFactory>=new Map([
  ['atelier_4_0',mangaScreentones], ['atelier_3_12',pixelSorting],
  ['atelier_7_0',filmHalation], ['atelier_7_1',anamorphicStreak],
  ['atelier_7_10',rollingShutter], ['atelier_7_2',lensGhost],
  ['atelier_2_15',stainedGlass], ['atelier_7_11',splitDiopter],
]);
