#!/usr/bin/env node
/** Regenerates a conservative audit from the actual effect registry. Does not execute GUI or imply professional parity. */
import { readFileSync, writeFileSync } from 'node:fs';
const catalog = readFileSync(new URL('../src/editor/effect-catalog.ts', import.meta.url), 'utf8');
const fxSource = readFileSync(new URL('../src/editor/fx.ts', import.meta.url), 'utf8');
const ops = readFileSync(new URL('../src/editor/effect-ops.ts', import.meta.url), 'utf8');
const filters = [...catalog.matchAll(/\{\s*group:\s*'([^']+)',\s*kind:\s*'([^']+)',\s*label:\s*'([^']+)'/g)]
  .map(([, group, kind, label]) => ({ group, kind, label }));
const presets = [...fxSource.matchAll(/^\s{2}'([^']+)': \[/gm)].map(match => match[1]);
if (filters.length !== 70 || presets.length !== 15) {
  throw new Error(`Effect registry changed: expected 70 filters and 15 FX, found ${filters.length} and ${presets.length}. Review the inventory.`);
}
const approximations = new Set([
  'radialblur', 'zoomblur', 'lensblur', 'surfaceblur', 'denoise', 'highpass', 'clarity', 'texture', 'grain',
  'halftone', 'dither', 'aurora', 'cartoon', 'comicink', 'oilpaint', 'watercolor', 'sketch', 'ink',
  'neonedge', 'glitch', 'vhs', 'crt', 'mosaic', 'glass', 'frosted', 'cutout', 'outline', 'glow', 'shadow', 'backdrop',
]);
const issues = {
  zoomblur: 'Current zoom behavior is not the planned anime-inspired Shock Zoom distortion.',
  cutout: 'Only simple connected corner-color removal; no full subject segmentation.',
  oilpaint: 'Procedural approximation; no true stroke-flow or pigment model.',
  watercolor: 'Procedural approximation; no genuine wet-on-wet/pigment diffusion.',
  glow: 'Silhouette illumination still needs full perceptual and export matching review.',
  shadow: 'Layered shadows exist, but procedural miasma is a future Effects/Fx renderer.',
  backdrop: 'Basic solid/gradient backdrop; full image replacement/masking not yet implemented.',
  lensblur: 'Lens-like approximation, not complete depth-aware bokeh.',
  aurora: 'Procedural lights are not photographic aurora correction or physically modeled light.',
};
const title = (value) => value.replaceAll('|', '\\|');
const lines = [
  '# Spectrum 0.1 — Stage A Effects Audit', '',
  'Generated from `src/editor/effect-catalog.ts` and `src/editor/fx.ts`. This is a SOURCE INVENTORY, not a passed visual acceptance test.',
  '', '## Architecture findings', '',
  '- The existing document stores an ordered `Effect[]` per layer. It is essential that Studio category views **never reorder** processing.',
  '- Filter processing remains in `effect-ops.ts` and `advanced-ops.ts`; most FX presets are defined as multi-filter chains in `fx.ts`.',
  '- Stage B adds presentation metadata to group a legacy FX chain into a single editable item without claiming a unique FX renderer.',
  '- Stage C extends whole-object text styles and pointer interactions; mixed character formatting is not yet implemented.',
  '- All image-processing algorithms require parameter, perceptual, alpha, and export equivalence tests in D–H.',
  '', '## Current filter / effect catalog', '',
  '| Original group | Stage B section | Name | Engine status | Notes |', '|---|---|---|---|---|',
];
for (const entry of filters) {
  const special = ['cutout', 'outline', 'glow', 'shadow', 'backdrop'].includes(entry.kind);
  const category = special ? 'Effects' : 'Creativity';
  const label = entry.kind === 'cutout' ? 'Remove background (previously Remove corner background)' : entry.label;
  const status = approximations.has(entry.kind) ? 'Approximation; needs refinement' : 'Implemented baseline; needs quality validation';
  const found = ops.includes(`'${entry.kind}'`) || readFileSync(new URL('../src/editor/advanced-ops.ts', import.meta.url), 'utf8').includes(`'${entry.kind}'`);
  lines.push(`| ${title(entry.group)} | ${category} | ${title(label)} | ${status} | ${title(issues[entry.kind] ?? (found ? 'Processing route found; evaluate against product specification.' : 'No direct case found; verify dispatch chain.'))} |`);
}
lines.push('', '## Signature FX catalog', '',
  'These 15 presets are presently **legacy effect chains**, not independently engineered signature FX. Stage H must design separate processors for each.',
  '', '| Signature FX | Current status | Stage H requirement |', '|---|---|---|');
for (const name of presets) lines.push(`| ${name} | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |`);
lines.push('', '## Stage B/C acceptance criteria', '',
  '1. Filters tab renamed **Creativity**; sibling **Effects** and **FX** are separate.',
  '2. Clicking a tool opens one dedicated editor; Apply commits exactly one undo step, Cancel leaves the original untouched.',
  '3. Applied items appear as clickable rounded icons, individually grouped by section; historical effects still load.',
  '4. One FX icon represents an entire saved preset chain; the original order is preserved.',
  '5. Text can be selected while another tool is active, dragged as a shape, and resized using handles; Ctrl+click bypasses text interception.',
  '6. Focus Text has categorized object-level styling actions, visible selection state, and reliable Apply/Cancel.',
  '7. The real npm build, Tauri runtime, and representative UI E2E must pass before release qualification.', '');
writeFileSync(new URL('../ENGINE_AUDIT.md', import.meta.url), lines.join('\n'));
console.log(`Audit written: ${filters.length} filters/effects, ${presets.length} FX presets.`);
