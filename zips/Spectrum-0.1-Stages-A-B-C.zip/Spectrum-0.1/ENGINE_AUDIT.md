# Spectrum 0.1 — Stage A Effects Audit

Generated from `src/editor/effect-catalog.ts` and `src/editor/fx.ts`. This is a SOURCE INVENTORY, not a passed visual acceptance test.

## Architecture findings

- The existing document stores an ordered `Effect[]` per layer. It is essential that Studio category views **never reorder** processing.
- Filter processing remains in `effect-ops.ts` and `advanced-ops.ts`; most FX presets are defined as multi-filter chains in `fx.ts`.
- Stage B adds presentation metadata to group a legacy FX chain into a single editable item without claiming a unique FX renderer.
- Stage C extends whole-object text styles and pointer interactions; mixed character formatting is not yet implemented.
- All image-processing algorithms require parameter, perceptual, alpha, and export equivalence tests in D–H.

## Current filter / effect catalog

| Original group | Stage B section | Name | Engine status | Notes |
|---|---|---|---|---|
| Color & light | Creativity | Brightness | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Contrast | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Saturation | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Hue rotation | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Grayscale | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Sepia | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Invert | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Exposure | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Highlights | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Shadows | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Whites | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Blacks | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Temperature | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Tint | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Vibrance | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Gamma | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Tonal curves | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Levels | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Color balance | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Selective color | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | RGB channel mixer | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Gradient map | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Duotone | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Color & light | Creativity | Solarize | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Gaussian blur | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Box blur | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Motion blur | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Radial blur | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Zoom blur | Approximation; needs refinement | Current zoom behavior is not the planned anime-inspired Shock Zoom distortion. |
| Detail & texture | Creativity | Lens blur | Approximation; needs refinement | Lens-like approximation, not complete depth-aware bokeh. |
| Detail & texture | Creativity | Surface blur | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Sharpen | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Unsharp mask | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | High pass | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Clarity | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Texture detail | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Noise reduction | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Film grain | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | RGB noise | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Emboss | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Edge detection | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Pixelate | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Halftone | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Dither | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Detail & texture | Creativity | Vignette | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Aurora illumination | Approximation; needs refinement | Procedural lights are not photographic aurora correction or physically modeled light. |
| Stylize | Creativity | Radial energy burst | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Posterize | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Cartoon | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Comic ink | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Oil painting | Approximation; needs refinement | Procedural approximation; no true stroke-flow or pigment model. |
| Stylize | Creativity | Watercolor | Approximation; needs refinement | Procedural approximation; no genuine wet-on-wet/pigment diffusion. |
| Stylize | Creativity | Pencil sketch | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Ink drawing | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Neon edges | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Chromatic split | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Digital glitch | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | VHS | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | CRT monitor | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Mosaic tiles | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Swirl | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Ripple | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Wave | Implemented baseline; needs quality validation | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Glass refraction | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Creativity | Frosted glass | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Effects | Remove background (previously Remove corner background) | Approximation; needs refinement | Only simple connected corner-color removal; no full subject segmentation. |
| Stylize | Effects | Hyper outline | Approximation; needs refinement | Processing route found; evaluate against product specification. |
| Stylize | Effects | Spectrum glow | Approximation; needs refinement | Silhouette illumination still needs full perceptual and export matching review. |
| Stylize | Effects | Shadow forge | Approximation; needs refinement | Layered shadows exist, but procedural miasma is a future Effects/Fx renderer. |
| Stylize | Effects | Backdrop | Approximation; needs refinement | Basic solid/gradient backdrop; full image replacement/masking not yet implemented. |

## Signature FX catalog

These 15 presets are presently **legacy effect chains**, not independently engineered signature FX. Stage H must design separate processors for each.

| Signature FX | Current status | Stage H requirement |
|---|---|---|
| Hyper Outline | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Neon Pulse | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Shadow Forge | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Dream Bloom | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Glitch Matrix | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Comic Pop | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Frostbite | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Ember Glow | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Prism Split | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Golden Hour | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Aurora Flow | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Electric Edge | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Holographic | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Retro Vision | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |
| Spectrum Burst | Legacy multi-effect preset | Dedicated behavior/algorithm + typed parameters and regression images. |

## Stage B/C acceptance criteria

1. Filters tab renamed **Creativity**; sibling **Effects** and **FX** are separate.
2. Clicking a tool opens one dedicated editor; Apply commits exactly one undo step, Cancel leaves the original untouched.
3. Applied items appear as clickable rounded icons, individually grouped by section; historical effects still load.
4. One FX icon represents an entire saved preset chain; the original order is preserved.
5. Text can be selected while another tool is active, dragged as a shape, and resized using handles; Ctrl+click bypasses text interception.
6. Focus Text has categorized object-level styling actions, visible selection state, and reliable Apply/Cancel.
7. The real npm build, Tauri runtime, and representative UI E2E must pass before release qualification.
