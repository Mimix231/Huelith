# Spectrum 0.1 — Creative Tools Verification

**Date:** 2026-10-17 · **Version:** 0.1.0, intentionally unchanged.

## Checks performed in this environment

| Check | Result | Scope |
| --- | --- | --- |
| `npm test` | **44 passed** | Model validation, document history, line controls, FX stacks, theme persistence, code/source checks |
| `npm run test:browser` | **40 passed** | Actual Chromium pixels, typed canvas rendering, outline/filter effects, synthesized real image clipboard event, CSS appearance |
| Application typecheck with temporary dependency declarations | **Passed** | `tsc --noEmit --noImplicitAny false`; detects source errors, **not** a real npm-dependency check |
| TypeScript/TSX parsing | **Passed** | TypeScript parser over source tree (also in npm tests) |
| CSS parsing | **Passed** | All theme, canvas, shared stylesheets via PostCSS |
| JSON/TOML parse | **Passed** | Tauri/package metadata |
| Python E2E test script syntax | **Passed** | `python -m py_compile tests/ui-e2e.py` |
| Real frontend `npm run check` / `npm run build` | **BLOCKED** | npm registry DNS unreachable, React/MUI/Vite/Zustand unavailable |
| React/MUI interactive UI E2E | **NOT RUN** | `tests/ui-e2e.py` included but requires successful npm install + Vite |
| Windows Tauri build + native clipboard | **NOT RUN** | Rust/cargo not installed, no Windows desktop available |

**Do not mistake dependency declaration stand-ins for a successful real TypeScript check.** The declaration file was removed from the deliverable to prevent masking real package typings.

## What the new tests cover

- Cubic line using four movable nodes, curve bounds, node dragging without mutating the original, SVG serialization.
- Per-layer non-destructive FX stack: preset insertion, toggling, reordering, amount clamping, model validation, undo behavior.
- Actual Chromium Canvas2D brightness effect pixels, preservation of source transparency, colored hyper-outline, disabled effects, multiline text rasterization.
- ClipboardEvent carrying an actual PNG File → FileReader → image decode → new undoable raster layer; verify layer dimensions and undo.
- Five distinct theme CSS files tested against real browser computed styles. Three previously existing themes plus new Midnight and Studio.

The added `tests/ui-e2e.py` starts Vite and tests the **real React app**: create a document, draw shapes and lines, type multiline text, choose themes, use FX, and paste an image. CI invokes it, but this environment cannot execute it because npm dependencies are absent. GitHub Actions is configured for Windows Rust checking, frontend build, and browser tests; the pipeline **has not run in this session**.

## Run these checks on your Windows machine

```powershell
npm install
npm run check
npm test
npm run test:browser
python tests/ui-e2e.py
npm run build
npm run desktop:dev
```

For native testing, install Tauri 2 prerequisites, an up-to-date Rust toolchain (clipboard plugin currently requires Rust 1.90+), Python Playwright and Chromium. If any real build/test fails, fix the errors and rerun **all** checks before shipping.

## Known limitations and compatibility notes

- Not a certified desktop release. In particular Windows clipboard image read/write remains unverified locally.
- Spectrum's custom vector format (`.spectrum`) preserves effect stacks, control points and text. **SVG export does not embed Spectrum's proprietary FX renderer**, so SVG effects differ or are absent. Use PNG/WebP for visual-perfect thumbnail export.
- Shape edit sessions use pointer-down preview and pointer-up commit; individual handle drags become undo steps. They do not implement a single transaction across several separate handle drags yet.
- The text tool supports editable multiline text, real canvas text measurement, font family/weight/size/line-height/alignment and Ctrl+Enter commit. Font fallback depends on fonts installed on the system; it is not a full typography engine.
- Freehand paths with smoothing zero preserve raw pointer coordinates; Precision Pen anchors are click/drag generated. Pressure-sensitive brush behavior is limited by the hardware and host platform.
- FX are non-destructive per-layer effects, not full Photoshop-compatible adjustment layers. Outline/glow on huge documents may still be expensive; FX previews cap working-buffer resolution at 16 megapixels.
- Rectangular masks, broad shape hit boxes and history snapshots remain foundations, not production-grade professional editing.
