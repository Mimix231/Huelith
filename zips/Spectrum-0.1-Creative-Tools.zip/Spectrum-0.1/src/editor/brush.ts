import type { Point } from './types';

export interface BrushDab {
  radius: number;
  hardness: number;
  opacity: number;
  color: string;
  erase: boolean;
}

function rgb(color: string): string {
  const hex = /^#([a-f\d]{6})$/i.exec(color)?.[1];
  if (!hex) return '0, 0, 0';
  return [0, 2, 4].map(index => Number.parseInt(hex.slice(index, index + 2), 16)).join(', ');
}

/**
 * Draw one pressure-adjusted soft dab onto the active raster work buffer.
 * This is composited into the layer only on commit; source pixels stay untouched during a stroke.
 */
export function drawBrushDab(
  ctx: CanvasRenderingContext2D,
  position: Point,
  dab: BrushDab,
): void {
  const radius = Math.max(0.5, dab.radius);
  const hardness = Math.max(0, Math.min(1, dab.hardness));
  const opacity = Math.max(0, Math.min(1, dab.opacity));
  if (opacity === 0) return;

  const ink = dab.erase ? '0, 0, 0' : rgb(dab.color);
  ctx.save();
  ctx.globalCompositeOperation = dab.erase ? 'destination-out' : 'source-over';
  if (hardness >= 0.995) {
    // Equal radial-gradient radii can resolve to the transparent stop in Chromium.
    ctx.fillStyle = `rgba(${ink}, ${opacity})`;
  } else {
    const gradient = ctx.createRadialGradient(
      position.x, position.y, radius * hardness,
      position.x, position.y, radius,
    );
    gradient.addColorStop(0, `rgba(${ink}, ${opacity})`);
    gradient.addColorStop(1, `rgba(${ink}, 0)`);
    ctx.fillStyle = gradient;
  }
  ctx.beginPath();
  ctx.arc(position.x, position.y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
