import type { VectorShape } from './types';

/** Measure real font metrics rather than estimating widths from character count. */
export function textMetrics(
  text: string,
  fontSize: number,
  fontFamily: string,
  fontWeight: string,
  lineHeight: number,
  letterSpacing = 0,
): { width: number; height: number } {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const font = Math.max(4, fontSize);
  if (ctx) ctx.font = `${fontWeight} ${font}px ${fontFamily}`;
  const lines = text.split('\n');
  const widths = lines.map(line => {
    const measured = ctx?.measureText(line).width ?? line.length * font * 0.62;
    return measured + Math.max(0, line.length - 1) * letterSpacing;
  });
  return {
    width: Math.max(20, ...widths) + 8,
    height: Math.max(font, lines.length * font * lineHeight),
  };
}

export function reflowTextShape(shape: VectorShape): void {
  if (shape.kind !== 'text') return;
  Object.assign(shape, textMetrics(
    shape.text ?? '',
    shape.fontSize ?? 48,
    shape.fontFamily ?? 'Arial, sans-serif',
    shape.fontWeight ?? '400',
    shape.lineHeight ?? 1.25,
    shape.letterSpacing ?? 0,
  ));
}
