"""Real Chromium Canvas2D smoke test. Requires `pip install playwright` + a Chromium executable."""
import json
import os
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

bundle = sys.stdin.read()
with sync_playwright() as playwright:
    # Prefer a system Chromium locally; CI may use the bundled Playwright browser.
    chromium_path = os.environ.get('CHROMIUM_PATH')
    if not chromium_path and os.path.exists('/usr/bin/chromium'):
        chromium_path = '/usr/bin/chromium'
    launch = {'headless': True, 'args': ['--no-sandbox']}
    if chromium_path:
        launch['executable_path'] = chromium_path
    browser = playwright.chromium.launch(**launch)
    try:
        page = browser.new_page()
        page.goto('about:blank')
        page.add_script_tag(content=bundle)
        checks = page.evaluate(r'''async () => {
          const engine = window.SpectrumTest;
          const results = [];
          function assert(name, condition) {
            if (!condition) throw new Error(`Canvas pixel assertion failed: ${name}`);
            results.push(name);
          }
          function canvas(width = 80, height = 80) {
            const element = document.createElement('canvas');
            element.width = width;
            element.height = height;
            return element;
          }
          function pixel(element, x, y) {
            return [...element.getContext('2d').getImageData(x, y, 1, 1).data];
          }
          function vectorLayer(shape) {
            return {
              id: 'layer', name: 'Vector', visible: true, locked: false,
              opacity: 1, blend: 'source-over', x: 0, y: 0, type: 'vector', shapes: [shape],
            };
          }
          const basic = canvas();
          const rect = {
            kind: 'rect', id: 'rect', x: 10, y: 10, width: 30, height: 30,
            fill: '#ff0000', stroke: 'none', strokeWidth: 0,
          };
          engine.renderLayer(basic.getContext('2d'), vectorLayer(rect));
          assert('rectangle interior red', pixel(basic, 20, 20)[0] > 245);
          assert('transparent rectangle exterior', pixel(basic, 60, 60)[3] === 0);

          const masks = canvas();
          const masked = vectorLayer({ ...rect, x: 0, y: 0, width: 60, height: 60 });
          masked.mask = { x: 10, y: 10, width: 20, height: 20 };
          engine.renderLayer(masks.getContext('2d'), masked);
          assert('mask retains content inside', pixel(masks, 15, 15)[3] === 255);
          assert('mask removes content outside', pixel(masks, 40, 40)[3] === 0);

          const curves = canvas();
          const path = {
            kind: 'path', id: 'curve', x: 0, y: 0, width: 60, height: 0,
            fill: 'none', stroke: '#0000ff', strokeWidth: 8,
            nodes: [{ x: 10, y: 40, out: { x: 20, y: 40 } }, { x: 60, y: 40, in: { x: 50, y: 40 } }],
          };
          engine.renderLayer(curves.getContext('2d'), vectorLayer(path));
          assert('cubic Bézier stroke visible', pixel(curves, 35, 40)[2] > 200);
          assert('cubic Bézier stroke bounded', pixel(curves, 35, 15)[3] === 0);

          const rotated = canvas();
          const rotatedRect = { ...rect, x: 20, y: 30, width: 40, height: 8, rotation: 90 };
          engine.renderLayer(rotated.getContext('2d'), vectorLayer(rotatedRect));
          assert('rotation covers vertical axis', pixel(rotated, 40, 18)[0] > 200);
          assert('rotation does not cover original horizontal corner', pixel(rotated, 25, 34)[3] === 0);

          const base = canvas();
          const imgctx = base.getContext('2d');
          imgctx.fillStyle = '#0000ff';
          imgctx.fillRect(0, 0, 16, 16);
          const raster = {
            id: 'r', name: 'Raster', visible: true, locked: false,
            opacity: 1, blend: 'source-over', x: 20, y: 10,
            image: base.toDataURL('image/png'), imageWidth: 80, imageHeight: 80,
            type: 'raster', scaleX: 0.5, scaleY: 2,
          };
          await engine.prepareImages({ layers: [raster] });
          const composed = canvas();
          engine.renderLayer(composed.getContext('2d'), raster);
          assert('raster data URL is decoded', pixel(composed, 21, 12)[2] > 200);
          assert('raster scale is applied', pixel(composed, 35, 40)[3] === 0);
          const brushed = canvas();
          const brushCtx = brushed.getContext('2d');
          engine.drawBrushDab(brushCtx, { x: 30, y: 30 }, {
            radius: 14, hardness: 0.2, opacity: 1, color: '#00ff00', erase: false,
          });
          assert('soft brush center is opaque', pixel(brushed, 30, 30)[1] > 200);
          assert('soft brush falloff fades at edge', pixel(brushed, 41, 30)[3] < 200);
          assert('brush does not paint outside radius', pixel(brushed, 60, 30)[3] === 0);
          engine.drawBrushDab(brushCtx, { x: 30, y: 30 }, {
            radius: 6, hardness: 1, opacity: 1, color: '#000000', erase: true,
          });
          assert('eraser removes existing alpha', pixel(brushed, 30, 30)[3] === 0);
          const customLine = canvas();
          const curved = {
            kind: 'line', id: 'line', x: 5, y: 55, width: 70, height: 0,
            controls: [{ x: 5, y: 5 }, { x: 75, y: 5 }],
            fill: 'none', stroke: '#ff00ff', strokeWidth: 5,
          };
          engine.renderLayer(customLine.getContext('2d'), vectorLayer(curved));
          assert('four-point cubic line passes through upper arc', pixel(customLine, 40, 18)[0] > 100);
          assert('four-point cubic line keeps lower region transparent', pixel(customLine, 40, 60)[3] === 0);

          const fxSource = canvas();
          const fxCtx = fxSource.getContext('2d');
          fxCtx.fillStyle = '#642800';
          fxCtx.fillRect(25, 25, 20, 20);
          const brighter = engine.processEffects(fxSource, [
            { id: 'e1', kind: 'brightness', amount: 150, enabled: true },
          ]);
          assert('brightness filter increases red component', pixel(brighter, 30, 30)[0] > pixel(fxSource, 30, 30)[0]);
          assert('FX preserves transparent exterior', pixel(brighter, 5, 5)[3] === 0);
          const outlined = engine.processEffects(fxSource, [
            { id: 'e2', kind: 'outline', amount: 6, color: '#00ff00', enabled: true },
          ]);
          assert('hyper outline extends beyond source silhouette', pixel(outlined, 21, 35)[1] > 100);
          assert('original artwork remains intact after outline', pixel(outlined, 30, 35)[0] > 75);
          const noEffect = engine.processEffects(fxSource, [
            { id: 'e3', kind: 'contrast', amount: 150, enabled: false },
          ]);
          assert('disabled effects bypass processing', noEffect === fxSource);

          const textLayer = canvas();
          const text = { kind: 'text', id: 'txt', x: 4, y: 4, width: 75, height: 45,
            fill: '#ffffff', stroke: 'none', strokeWidth: 0,
            fontSize: 20, fontWeight: '700', text: 'Hello\nWorld', lineHeight: 1.25 };
          engine.renderLayer(textLayer.getContext('2d'), vectorLayer(text));
          assert('multiline typography draws text pixels',
            textLayer.getContext('2d').getImageData(0, 0, 80, 80).data.some((value, i) => i % 4 === 3 && value > 0));

          // Clipboard ingestion follows the same real browser FileReader and Image decode path as Ctrl+V.
          engine.useEditor.getState().newDoc('Clipboard', 80, 80, 'transparent');
          const red = canvas(12, 10);
          const redContext = red.getContext('2d');
          redContext.fillStyle = '#e63226';
          redContext.fillRect(0, 0, 12, 10);
          const redBlob = await new Promise(resolve => red.toBlob(resolve, 'image/png'));
          const transfer = new DataTransfer();
          transfer.items.add(new File([redBlob], 'copied.png', { type: 'image/png' }));
          const paste = new ClipboardEvent('paste', { clipboardData: transfer });
          assert('pasted image is recognized from clipboard event', await engine.handlePaste(paste));
          const editor = engine.useEditor.getState();
          const pasted = editor.tabs.find(tab => tab.doc.id === editor.activeId).doc;
          assert('clipboard image creates editable raster layer', pasted.layers.at(-1).type === 'raster');
          assert('clipboard layer preserves image dimensions', pasted.layers.at(-1).imageWidth === 12 && pasted.layers.at(-1).imageHeight === 10);
          assert('clipboard paste is undoable', pasted.layers.length === 2);
          editor.undo();
          const undone = engine.useEditor.getState().tabs.find(tab => tab.doc.id === engine.useEditor.getState().activeId).doc;
          assert('undo removes clipboard layer', undone.layers.length === 1);

          const editState = engine.useEditor.getState();
          editState.addShape({
            id: 'copy-vector', kind: 'rect', x: 3, y: 5, width: 20, height: 18,
            fill: '#bb33ee', stroke: 'none', strokeWidth: 0,
          });
          editState.selectShape('copy-vector');
          const copyTransfer = new DataTransfer();
          const copyEvent = new ClipboardEvent('copy', { clipboardData: copyTransfer });
          assert('vector copy stores editable clipboard geometry', await engine.copySelected(copyEvent));
          editState.newDoc('Vector target', 80, 80, '#ffffff');
          const vectorPaste = new ClipboardEvent('paste', { clipboardData: copyTransfer });
          assert('internal Spectrum vector format can be pasted', await engine.handlePaste(vectorPaste));
          const pastedVector = engine.useEditor.getState().tabs.find(tab => tab.doc.id === engine.useEditor.getState().activeId).doc;
          assert('pasted vector geometry is editable in new document',
            pastedVector.layers.at(-1).type === 'vector' && pastedVector.layers.at(-1).shapes[0].width === 20);

          const doc = engine.createDocument('Smoke', 80, 80, '#ffffff');
          doc.layers = [vectorLayer(rect)];
          const exported = engine.exportCanvas(doc);
          assert('export uses white document background', pixel(exported, 70, 70)[0] === 255);
          assert('export includes vector layers', pixel(exported, 20, 20)[1] === 0);
          const fxDocument = engine.createDocument('Thumbnail FX', 80, 80, 'transparent');
          const flat = vectorLayer({ ...rect, x: 25, y: 25, width: 20, height: 20 });
          flat.effects = [{ id: 'outline', kind: 'outline', amount: 6,
            color: '#00ff00', enabled: true }];
          fxDocument.layers = [flat];
          const fxExported = engine.exportCanvas(fxDocument);
          assert('PNG pipeline renders non-destructive layer FX', pixel(fxExported, 21, 35)[1] > 100);
          assert('source layer geometry survives FX export', flat.shapes[0].x === 25);

          return results;
        }''')
        # Load the *actual* Spectrum stylesheets into Chromium and compare computed
        # visual properties, rather than trusting that theme names merely exist.
        project = Path(__file__).resolve().parents[1]
        styles = '\n'.join((project / 'src' / 'styles' / name).read_text()
                           for name in ('app.css', 'glass.css', 'material.css', 'classic.css', 'midnight.css', 'studio.css'))
        page.set_content(f'<style>{styles}</style><div class="app theme-glass">'
                         '<div class="toolrail"></div><div class="canvas-host"></div></div>')
        appearances = {}
        for name in ('glass', 'material', 'classic', 'midnight', 'studio'):
            page.locator('.app').evaluate('(element, name) => {element.className = `app theme-${name}`}', name)
            appearances[name] = page.evaluate('''() => {
                const rail = getComputedStyle(document.querySelector('.toolrail'));
                const canvas = getComputedStyle(document.querySelector('.canvas-host'));
                return {
                    railRadius: rail.borderTopRightRadius,
                    railBlur: rail.backdropFilter,
                    canvasBackground: canvas.backgroundImage,
                    background: getComputedStyle(document.querySelector('.app')).backgroundColor,
                };
            }''')
        theme_checks = [
            ('glass panes have real backdrop blur', appearances['glass']['railBlur'] != 'none'),
            ('material has expressive curved rail', appearances['material']['railRadius'] == '19px'),
            ('classic does not inherit material rounding', appearances['classic']['railRadius'] != '19px'),
            ('all five themes have unique canvas backgrounds', len({v['canvasBackground'] for v in appearances.values()}) == 5),
            ('midnight remains low-glare without blur', appearances['midnight']['railBlur'] == 'none'),
            ('studio is light without glass blur', appearances['studio']['railBlur'] == 'none'),
        ]
        for name, success in theme_checks:
            if not success:
                raise AssertionError(f'Computed theme regression: {name}: {appearances}')
            checks.append(name)
        for index, name in enumerate(checks, start=1):
            print(f'PASS {index:02d}: {name}')
        print(f'Chromium canvas/theme integration assertions: {len(checks)} passed')
    finally:
        browser.close()
