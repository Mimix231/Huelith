"""Real Spectrum UI interaction test. Requires npm dependencies and Python Playwright + Chromium.

Starts the Vite server automatically. Unlike the renderer smoke suite, this drives React/MUI.
"""
import os
import subprocess
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HOST = 'http://127.0.0.1:1420'


def wait_for_vite(timeout=30):
    start = time.monotonic()
    while time.monotonic() - start < timeout:
        try:
            with urllib.request.urlopen(HOST, timeout=1) as response:
                if response.status == 200:
                    return
        except Exception:
            time.sleep(.2)
    raise RuntimeError('Vite failed to start. Install dependencies and check npm run dev.')


def main():
    vite = subprocess.Popen(
        ['npm', 'run', 'dev'], cwd=ROOT, stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE, shell=os.name == 'nt',
    )
    try:
        wait_for_vite()
        with sync_playwright() as playwright:
            options = {'headless': True, 'args': ['--no-sandbox']}
            executable = os.environ.get('CHROMIUM_PATH')
            if not executable and Path('/usr/bin/chromium').exists():
                executable = '/usr/bin/chromium'
            if executable:
                options['executable_path'] = executable
            browser = playwright.chromium.launch(**options)
            try:
                page = browser.new_page(viewport={'width': 1500, 'height': 940})
                page.on('pageerror', lambda error: print(f'PAGE ERROR: {error}'))
                page.goto(HOST)
                page.locator('.welcome-card').get_by_role('button', name='New document', exact=True).click()
                page.get_by_role('button', name='Create document').click()
                art = page.locator('canvas.artboard-canvas')
                art.wait_for()
                assert page.locator('.welcome-scrim').count() == 0
                print('PASS: new document dialog and canvas')

                box = art.bounding_box()
                x, y = box['x'] + box['width'] / 2, box['y'] + box['height'] / 2
                page.get_by_role('button', name='Rectangle (R)').click()
                page.mouse.move(x - 70, y - 50)
                page.mouse.down()
                page.mouse.move(x + 35, y + 18, steps=8)
                page.mouse.up()
                assert page.locator('.layer-row').count() >= 2
                assert page.get_by_role('button', name='Move & transform (V)').count() == 1
                print('PASS: editable shape creation')

                page.get_by_role('button', name='Line (L)').click()
                page.mouse.move(x - 60, y + 50)
                page.mouse.down()
                page.mouse.move(x + 60, y + 50, steps=8)
                page.mouse.up()
                assert page.get_by_text('Drag anchor points and curve handles').count() > 0
                print('PASS: line enters four-control-point editing mode')

                page.get_by_role('button', name='Text (T)').click()
                page.mouse.click(x - 40, y - 80)
                text = page.locator('textarea.inline-text-editor')
                text.wait_for()
                text.fill('Hello Spectrum\nSecond line')
                text.press('Control+Enter')
                assert text.count() == 0
                print('PASS: multiline text typing and commit')

                page.get_by_role('button', name='Choose appearance').click()
                page.get_by_text('Spectrum Studio', exact=True).click()
                assert 'theme-studio' in page.locator('.app').get_attribute('class')
                page.get_by_role('button', name='Choose appearance').click()
                page.get_by_text('Spectrum Midnight', exact=True).click()
                assert 'theme-midnight' in page.locator('.app').get_attribute('class')
                print('PASS: palette dropdown switches distinct theme stylesheets')

                page.locator('.inspector-tabs button').filter(has_text='fx').click()
                page.get_by_label('Choose effect').select_option('glow')
                page.locator('.fx-add-row').first.get_by_role('button', name='Add').click()
                assert page.get_by_text('Spectrum glow').count() > 0
                print('PASS: non-destructive filter stack can add effects')

                page.locator('.inspector-tabs button').filter(has_text='layers').click()
                before = page.locator('.layer-row').count()
                page.evaluate('''async () => {
                    const canvas = document.createElement('canvas');
                    canvas.width = 13;
                    canvas.height = 11;
                    const ctx = canvas.getContext('2d');
                    ctx.fillStyle = '#ff2255';
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
                    const data = new DataTransfer();
                    data.items.add(new File([blob], 'pasted.png', {type:'image/png'}));
                    window.dispatchEvent(new ClipboardEvent('paste', {clipboardData: data}));
                }''')
                page.wait_for_function('(before) => document.querySelectorAll(".layer-row").length > before', arg=before)
                print('PASS: real paste event inserts a new image layer')
                print('Spectrum 0.1 interactive UI assertions: 7 passed')
            finally:
                browser.close()
    finally:
        vite.terminate()
        try:
            vite.wait(timeout=5)
        except subprocess.TimeoutExpired:
            vite.kill()


if __name__ == '__main__':
    main()
