# Spectrum 0.1 🌈

**Create without limits.** Spectrum is an experimental, GPL-3.0-or-later, **completely free and open-source** raster and vector image editor. The application is built with **Tauri 2**, **React 19**, **TypeScript**, **Material UI 7**, and **Zustand 5**.

There are no subscriptions, accounts, paid features, telemetry, trial limits, or cancellation fees. Supporting the development via optional donations is compatible with this philosophy, but no donation flow is built into the editor.

> **Development status: Spectrum 0.1 — stabilization.** The project is usable source code with tested document and Canvas2D logic. It is **not verified as a finished desktop release** because this environment cannot download npm dependencies or compile the Rust Tauri component. Always run `npm run verify` and test the actual application before shipping it to users.

## Start the editor

Requirements: **Node.js 22+**, npm, and (for desktop builds) a supported Rust toolchain with the [Tauri 2 OS prerequisites](https://v2.tauri.app/start/prerequisites/).

```bash
npm install
npm run verify
npm run dev
```

Open `http://127.0.0.1:1420` in a browser. The editor supports browser downloads for file export and `.spectrum` projects.

For a native desktop window:

```bash
npm run desktop:dev
```

For a native executable/installer:

```bash
npm run desktop:build
```

The source archive does **not** contain a prebuilt Windows executable. Dependency versions are declared in `package.json` but no lockfile could be generated in the build environment because npm registry DNS was unavailable. Generate a lockfile with `npm install` before making reproducible releases.

## Workspace and themes

The **palette icon** in the titlebar opens a theme **dropdown** with five distinct design modes. Each has its own stylesheet; `src/styles/app.css` contains shared layout geometry only.

| Theme | CSS | Identity |
| --- | --- | --- |
| Spectrum Glass | `src/styles/glass.css` | Dark frosted surfaces, background illumination, luminous accents and translucent panels |
| Material You | `src/styles/material.css` | Bright, expressive tonal surfaces, large corner radii, Material-style selected states |
| Classic Desktop | `src/styles/classic.css` | Flat dark desktop chrome, square windows, dense controls, conventional panel dividers |
| Spectrum Midnight | `src/styles/midnight.css` | Low-glare darkroom with restrained, crisp blue accents |
| Spectrum Studio | `src/styles/studio.css` | Bright industrial workspace, flat precision chrome and dotted canvas |

The theme, inspector width, and panel visibility persist in browser local storage. The inspector can be resized at its left edge (or with the arrow keys when its separator is focused). Toggle panels in the upper right of the workspace. Activate **Focus Mode** via the titlebar button or press **Tab with the canvas focused**; exit using the compact on-canvas button.

The upper controls are contextual: brush adjustments appear for painting, fill and stroke controls for vector shapes, and selection or transform instructions for their respective tools.

## Features in Spectrum 0.1

### Documents

- Create, switch, close and save multiple documents; support transparent backgrounds.
- Import PNG, JPEG, WebP, GIF and BMP; export PNG, JPEG, WebP and SVG.
- Open/save `.spectrum` projects, preserving editable raster/vector layers, masks and transforms.
- Dirty-document warnings, undo/redo, and recovery snapshots via IndexedDB where supported.

### Raster editing

- Brush and eraser with adjustable size, hardness, opacity and smoothing.
- Pointer-pressure response from compatible pen devices; mouse uses constant pressure.
- Non-destructive rectangular marquee selection restricts painting/erasing.
- Raster layers can be moved, resized, rotated, masked, hidden, locked and blended.
- For now, **painting onto a rotated/scaled raster layer is disabled** to avoid silently damaging data. Paint onto a new raster layer instead.

### Vector editing

- Rectangles, ellipses, lines, editable text and freehand vector paths.
- Freehand vector strokes become cubic Bézier paths with anchor and control points.
- Node editing via **A**: select an existing vector path, then drag anchors or either curve handle.
- Move, resize and rotate selected objects; property inspector edits coordinates and transforms.
- Export SVG with actual cubic path commands, editable text, layered groups, and embedded raster images.
- Text creation/changes use an inline editor on the canvas rather than blocking browser prompt dialogs.

### Layers and panels

- Add raster/vector layers, rename inline, duplicate, reorder, hide, lock and delete.
- Six layer compositing modes: Normal, Multiply, Screen, Overlay, Darken and Lighten.
- Adjustable opacity and non-destructive **rectangular** clipping masks made from marquee selections.
- Resizable layer/properties/history inspector and compact left tool rail.
- Editing history caps the **past** to 40 snapshots and approximately 48 MiB; recent history may be shorter on large projects.

## Keyboard shortcuts

| Action | Key |
| --- | --- |
| New / Open / Save / Save As | Ctrl+N / Ctrl+O / Ctrl+S / Ctrl+Shift+S |
| Undo / Redo | Ctrl+Z / Ctrl+Shift+Z or Ctrl+Y |
| Duplicate current layer | Ctrl+D |
| Select all / deselect | Ctrl+A / Ctrl+Shift+A or Escape |
| Move / Bezier nodes / Marquee | V / A / M |
| Pan / Brush / Eraser / Eyedropper | H / B / E / I |
| Rectangle / Ellipse / Line / Precision Pen / Freehand path | R / O / L / P / F |
| Editable text | T |
| Delete selected vector object | Delete |
| Pan / Zoom | Mouse wheel / Ctrl+Mouse wheel |
| Middle mouse pan | Middle-click drag |
| Focus Mode | Tab when canvas is focused; exit using on-canvas button |

On macOS, Command works for Ctrl-based shortcuts. Enter inserts a newline in text; Ctrl+Enter commits the text editor and Escape cancels it. For the Precision Pen, Enter commits the path, Backspace removes the last node, and Escape cancels.

## Running checks

The project includes both logic-level regression tests and an **optional Chromium pixel test**:

```bash
npm run check         # Strict TypeScript using your installed dependencies
npm test              # Node source and editor behavior tests
npm run build         # TypeScript + Vite production build
npm run verify        # All three above
npm run test:browser  # Chromium Canvas2D assertions (optional; requires Python Playwright + Chromium)
```

`npm run test:browser` requires Python with `playwright` and Chromium. It uses `/usr/bin/chromium` when available, otherwise the Chromium installed with Playwright; `CHROMIUM_PATH` can override the executable. Its checks cover actual Canvas2D pixels **and computed CSS for all five themes**. GitHub Actions also defines dedicated frontend, Chromium, and Windows Rust checks (these run when the project is pushed to a repository).

**Read [`CHECKS.md`](CHECKS.md) for the exact commands and results from this source build.** `ACCEPTANCE.md` contains the end-to-end manual checklist to complete in a full Tauri build.

## Architecture

```text
src/
  App.tsx                Workspace shell, contextual tools, layers and panels
  main.tsx               React entry point
  styles/
    app.css              Shared geometry and accessibility
    glass.css            Frosted glass interface
    material.css         Material You-style light interface
    classic.css          Traditional dense desktop interface
  components/
    Canvas.tsx           Interactions, live transforms, editable text
    Canvas.css           Canvas overlays
  editor/
    types.ts             Validated document format (version 1)
    geometry.ts          Bézier smoothing and editable path geometry
    operations.ts        Non-mutating drag/transform previews and commits
    brush.ts             Soft/hard dab rendering and alpha erasure
    store.ts             Document tabs, undo/redo, layer actions, workspace state
    render.ts            Canvas2D renderer and image decoding/cache
    svg.ts               SVG exporter and escaping
    files.ts             Tauri/browser file operations
    recovery.ts          IndexedDB emergency recovery
src-tauri/               Rust app shell and native configuration
tests/                   Regression tests and optional Chromium pixel tests
```

## Honest current limits

Spectrum 0.1 is not yet at Photoshop/Affinity/Illustrator feature parity. In particular:

- The renderer is **Canvas2D**, not a GPU/tile-based compositor. Very large canvases may still consume considerable memory or export slowly.
- Selections and masks are currently **rectangular only**; there are no feathered, freeform, gradient or per-pixel alpha masks.
- Bézier paths have editable anchors/handles, but do not yet support full CAD-like path operations, joins, boolean operations, or advanced snapping.
- Moving/transforming a layer works; nested group interaction and multi-object selection are not yet polished.
- Pressure support depends on hardware/browser pointer events; this is not a full brush preset engine.
- Undo retains immutable full-document snapshots under a memory budget, not a true command/tile-delta history.
- Advanced PSD/RAW workflows, ICC/HDR color management, non-destructive adjustment layers and GPU filters are not implemented.
- The native Tauri build and MUI runtime have **not been launched** in this creation environment. The source has passed logic tests and a strict check using temporary dependency stand-ins; a real dependency-based build remains mandatory.

If any desktop build, native file operation or UI interaction fails in real use, **Spectrum remains 0.1** until the defect is fixed and a regression test is added.

---

## October 17: Creative Tools stabilization (still Spectrum 0.1)

This update extends the **same** Tauri/React/MUI codebase and the version stays `0.1.0`.

### Editing tools and clipboard

- **Clipboard**: Paste PNG/JPEG/WebP screenshots and copied browser images with Ctrl+V; the editor creates a new raster layer. Toolbar **Paste** reads the system clipboard (native Tauri clipboard plugin on desktop, Async Clipboard API in supported browsers). Paste from the file browser via drag and drop. Copy/Cut from Spectrum also supports a selected vector object in the application's own clipboard format; copying a raster region creates PNG clipboard data. Availability varies with platform clipboard permissions.
- **Live, editable shapes**: rectangles and ellipses automatically switch to Move on creation, retaining resize and rotation handles. Lines create **four adjustable Bézier controls** (start, two curve handles, end) and automatically switch to Node editing. Press A to edit their points again.
- **Precision Pen (P)**: click to place cubic anchors, drag to set tangent handles, click more anchors, **Enter** (or the Finish path button) to commit, **Backspace** to remove the last anchor, **Escape** to cancel. Double-click finishes. **Freehand path (F)** remains a separate gesture tool: smoothing zero preserves raw pointer samples; higher smoothing generates editable Bézier nodes.
- **Typography (T)**: click to type, Enter for newlines, **Ctrl+Enter** to commit, Escape to discard. Double-click existing text with Move to edit. Text object typography controls are in Properties. Width is measured using actual canvas font metrics, not character-count guesses. Font fallback depends on available system fonts.
- **Edit sessions**: all shape, line, transform and node drags are visually previewed and only added to history at pointer-up. Escape cancels an active gesture. This is not yet a multi-gesture history transaction.

### Spectrum FX, filters and customization

Choose a layer, open the **FX** tab in the right inspector, then add an effect or apply a preset. The following effects are built into the non-destructive stack: brightness, contrast, saturation, hue rotation, grayscale, sepia, Gaussian blur, drop shadow, Spectrum Glow, Hyper Outline and chromatic splitting. Reorder, disable, adjust amount/color or remove individual effects without touching the source layer.

Included creative presets: **Neon Pulse, Shadow Forge, Hyper Outline, Glitch Matrix, Dream Bloom, Comic Pop**. All presets remain fully editable effect stacks.

The palette dropdown now offers **five distinct themes**, each in its own CSS file:

| Theme | File | Visual identity |
| --- | --- | --- |
| Glass | `src/styles/glass.css` | Translucent luminous panes, blur, gradients |
| Material | `src/styles/material.css` | Tonal, playful, pill-shaped, bright |
| Classic Desktop | `src/styles/classic.css` | Tight square controls, flat desktop chrome |
| Midnight | `src/styles/midnight.css` | Low-glare navy darkroom, sober borders, no blur |
| Studio | `src/styles/studio.css` | Bright industrial studio, crisp precision borders and canvas grid |

Use the **gear button** in the titlebar to customize keyboard shortcuts. Toolbar visibility, inspector width, theme, and shortcuts are saved locally.

### Export and image quality

`.spectrum` stores editable effect stacks, text and line control geometry. PNG/JPEG/WebP exports run the Canvas2D effects pipeline, with images decoded before export. **SVG export currently preserves vector geometry, not Spectrum FX effects**. Use PNG or WebP for FX-heavy thumbnails. Effects require extra CPU/memory, so cache is used for unchanged vector layers and large FX intermediates are limited to a 16-megapixel working canvas for preview/compositing. This is not a GPU tile renderer yet.

### Tests and honesty about the build

This package passed **44 Node tests** and **40 real Chromium assertions**, including clipboard image insertion. It also passed an application-level typecheck using temporary external-library declarations with implicit-`any` checking disabled; **that is not equivalent to a real strict TypeScript build**. The actual npm dependency-based build, native Tauri compilation, and interactive React E2E test remain unverified here because npm registry DNS and Rust are unavailable. Read [`CHECKS.md`](CHECKS.md) before treating it as release-ready.

The CI configuration includes real frontend, Playwright React UI and Windows Rust checks, and the new `tests/ui-e2e.py` can be run locally after installing dependencies. The project has no lockfile until `npm install` succeeds. **No premium editions, telemetry, logins, payments, or subscriptions** are included.
