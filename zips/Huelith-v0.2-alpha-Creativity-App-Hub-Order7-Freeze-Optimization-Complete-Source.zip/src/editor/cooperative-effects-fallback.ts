import { applyEffect } from './effect-ops';
import { EXPANSION_LOOKUP, createExpansion120Job, type Expansion120Job } from './expansion-120';
import { setAsyncEffectsProcessor, type AsyncEffectsProcessor } from './fx';
import type { Effect } from './types';

/** CPU-only fallback for WebView configurations without OffscreenCanvas workers.
 * Unlike the old synchronous fallback, large Order 7 effects yield after
 * individual scanlines. Their output is bit-for-bit the normal full-res path.
 * Existing non-Order7 processors are still computed in complete stages. */
export function installCooperativeEffectsFallback(): () => void {
  const generations=new Map<string,number>();
  let alive=true;
  const processor:AsyncEffectsProcessor=(source,effects,layer,done)=>{
    if(!alive)return false;
    const generation=(generations.get(layer)??0)+1;
    generations.set(layer,generation);
    let stage=0,current=source;
    let expansion:Expansion120Job|null=null;
    const stillCurrent=()=>alive && generations.get(layer)===generation;
    const schedule=()=>{if(stillCurrent())window.setTimeout(run,0);};
    const run=()=>{
      if(!stillCurrent())return;
      try {
        // Aim to release the event loop within ~6ms even with a huge layer.
        const started=performance.now();
        while(stillCurrent() && performance.now()-started < 6){
          const effect=effects[stage];
          if(!effect){done(current);return;}
          if(!effect.enabled || ((effect.kind==='outline'||effect.kind==='cutout')&&effect.amount===0)
            || !Number.isFinite(effect.amount)){stage++;continue;}
          if(EXPANSION_LOOKUP.has(effect.kind)){
            expansion??=createExpansion120Job(current,effect);
            if(expansion.runRows(1)){
              current=expansion.output();expansion=null;stage++;
            }
          }else{
            // Keep the existing authoritative renderer for legacy effects.
            // Only new Order 7 kernels are divided into scanline chunks here.
            current=applyEffect(current,effect);stage++;
          }
        }
        schedule();
      }catch(error){
        console.warn('Huelith CPU preview processing failed',error);
        // Never block tool switching after an unsupported processor.
        generations.set(layer,generation+1);
      }
    };
    schedule();
    return true;
  };
  setAsyncEffectsProcessor(processor);
  return ()=>{alive=false;generations.clear();setAsyncEffectsProcessor(null);};
}
