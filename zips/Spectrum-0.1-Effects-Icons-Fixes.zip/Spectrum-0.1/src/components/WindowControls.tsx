import { useEffect, useState } from 'react';
import { Close, CropSquare, FilterNone, Remove } from '@mui/icons-material';
import { useEditor } from '../editor/store';

/** Every close path (titlebar, Alt+F4, taskbar) is handled by the same native hook. */
export default function WindowControls() {
  const desktop = '__TAURI_INTERNALS__' in window;
  const [maximized, setMaximized] = useState(false);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!desktop) return;
    let disposed = false;
    let unlistenResize: (() => void) | undefined;
    let unlistenClose: (() => void) | undefined;
    void import('@tauri-apps/api/window').then(async ({ getCurrentWindow }) => {
      const current = getCurrentWindow();
      const refresh = async () => {
        try {
          const value = await current.isMaximized();
          if (!disposed) setMaximized(value);
        } catch (cause) {
          if (!disposed) setError(String(cause));
        }
      };
      await refresh();
      unlistenResize = await current.onResized(refresh);
      unlistenClose = await current.onCloseRequested(event => {
        const { textDraft, tabs } = useEditor.getState();
        if (!textDraft && !tabs.some(tab => tab.dirty)) return;
        // IMPORTANT: Prevent synchronously, before awaiting a native dialog.
        event.preventDefault();
        try {
          const { ask } = await import('@tauri-apps/plugin-dialog');
          const discard = await ask('Discard your unsaved changes and close Spectrum?', {
            title: 'Unsaved Spectrum documents',
            kind: 'warning',
            okLabel: 'Discard and close',
            cancelLabel: 'Keep editing',
          });
          if (discard) {
            // destroy() bypasses the close request callback, preventing recursive dialogs.
            await current.destroy();
          }
        } catch (cause) {
          console.error('Spectrum could not complete the close request', cause);
          if (!disposed) setError(`Close failed: ${String(cause)}`);
        }
      });
      if (!disposed) setReady(true);
    }).catch(cause => {
      console.error('Cannot initialize native Spectrum controls', cause);
      if (!disposed) setError(`Window controls unavailable: ${String(cause)}`);
    });
    return () => {
      disposed = true;
      unlistenResize?.();
      unlistenClose?.();
    };
  }, [desktop]);

  async function act(action: 'minimize' | 'toggleMaximize' | 'close'): Promise<void> {
    if (!desktop || !ready) return;
    try {
      const { getCurrentWindow } = await import('@tauri-apps/api/window');
      await getCurrentWindow()[action]();
    } catch (cause) {
      console.error(`Failed to ${action} Spectrum`, cause);
      setError(`Window action failed: ${String(cause)}`);
    }
  }

  return (
    <div className="spectrum-window-controls" role="group" aria-label="Window controls">
      {error && <span role="alert" className="window-error" title={error}>Window error</span>}
      <button type="button" aria-label="Minimize window" title="Minimize"
        disabled={!ready} onClick={() => void act('minimize')}><Remove /></button>
      <button type="button" aria-label={maximized ? 'Restore window' : 'Maximize window'}
        title={maximized ? 'Restore' : 'Maximize'} disabled={!ready}
        onClick={() => void act('toggleMaximize')}>{maximized ? <FilterNone /> : <CropSquare />}</button>
      <button type="button" className="window-close" aria-label="Close window" title="Close Spectrum"
        disabled={!ready} onClick={() => void act('close')}><Close /></button>
    </div>
  );
}
