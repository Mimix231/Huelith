import { setAsyncEffectsProcessor, type AsyncEffectsProcessor } from './fx';
import type { Effect } from './types';
import { isInteractiveEffectPreview } from './preview-quality';

interface Job {
  id: number;
  layer: string;
  source: HTMLCanvasElement;
  sourceId: number;
  queuedAt: number;
  effects: Effect[];
  complete: (image: ImageBitmap) => void;
}

/**
 * One running job, at most one pending job per layer, and a worker-side copy
 * of unchanged source pixels. Dragging a slider sends only its parameters
 * after the first source transfer; it never queues dozens of megapixel copies.
 */
export function installEffectsWorker(): () => void {
  if (typeof Worker === 'undefined' || typeof OffscreenCanvas === 'undefined' ||
    typeof createImageBitmap === 'undefined') return () => {};

  let worker: Worker;
  try {
    worker = new Worker(new URL('./effects-worker.ts', import.meta.url), { type: 'module' });
  } catch {
    return () => {};
  }

  let nextId = 1;
  let nextSourceId = 1;
  let running: Job | null = null;
  const latest = new Map<string, Job>();
  const sourceIds = new WeakMap<HTMLCanvasElement, number>();
  const residentSources = new Set<number>();
  let disposed = false;

  function fail(): void {
    if (disposed) return;
    disposed = true;
    latest.clear();
    running = null;
    residentSources.clear();
    worker.terminate();
    setAsyncEffectsProcessor(null);
    if (typeof window !== 'undefined') window.dispatchEvent(new Event('spectrum-worker-fallback'));
  }

  async function dispatch(): Promise<void> {
    if (disposed || running || latest.size === 0) return;
    // When another layer's heavy thumbnail/FX is queued, do not make the
    // actively dragged layer wait behind it. One CPU worker already serializes
    // jobs; prioritize the user-visible Studio selection.
    const job = [...latest.values()].find(candidate => isInteractiveEffectPreview(candidate.layer))
      ?? latest.values().next().value as Job;
    latest.delete(job.layer);
    running = job;
    try {
      if (residentSources.has(job.sourceId)) {
        worker.postMessage({ id: job.id, sourceId: job.sourceId, effects: job.effects });
        return;
      }

      const bitmap = await createImageBitmap(job.source);
      if (disposed || latest.has(job.layer)) {
        bitmap.close();
        running = null;
        void dispatch();
        return;
      }
      worker.postMessage({ id: job.id, sourceId: job.sourceId, bitmap, effects: job.effects }, [bitmap]);
      residentSources.add(job.sourceId);
    } catch {
      fail();
    }
  }

  worker.onmessage = (event: MessageEvent<{
    id: number;
    result?: ImageBitmap;
    error?: string;
    aborted?: boolean;
    processingMs?: number;
    evicted?: number[];
  }>) => {
    for (const sourceId of event.data.evicted ?? []) residentSources.delete(sourceId);
    const finished = running;
    running = null;
    if (disposed || !finished || event.data.id !== finished.id) {
      event.data.result?.close();
      if (!disposed) void dispatch();
      return;
    }
    if (event.data.aborted) {
      if (typeof window !== 'undefined')
        window.dispatchEvent(new CustomEvent('spectrum-aurora-render-metric', { detail: {
          aborted: true, latencyMs: performance.now() - finished.queuedAt,
          processingMs: event.data.processingMs ?? 0,
        } }));
      void dispatch();
      return;
    }
    if (event.data.error) {
      event.data.result?.close();
      fail();
      return;
    }
    if (event.data.result) {
      // During a drag each completed frame is still a *correct* render of a
      // previous slider value. Publish it in submission order instead of
      // starving the canvas indefinitely because a newer value is pending.
      // Once the drag ends, never publish superseded frames.
      if (!latest.has(finished.layer) || isInteractiveEffectPreview(finished.layer)) {
        finished.complete(event.data.result);
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('spectrum-exact-fx-frame'));
          window.dispatchEvent(new CustomEvent('spectrum-aurora-render-metric', { detail: {
            aborted: false, latencyMs: performance.now() - finished.queuedAt,
            processingMs: event.data.processingMs ?? 0,
          } }));
        }
      } else event.data.result.close();
    }
    void dispatch();
  };
  worker.onerror = fail;

  const process: AsyncEffectsProcessor = (source, effects, layer, complete) => {
    if (disposed) return false;
    let sourceId = sourceIds.get(source);
    if (sourceId === undefined) {
      sourceId = nextSourceId++;
      sourceIds.set(source, sourceId);
    }
    const revision = nextId++;
    latest.set(layer, {
      id: revision, layer, source, sourceId,
      queuedAt: performance.now(),
      // Studio creates immutable snapshots. postMessage already performs the
      // required structured clone at dispatch; cloning once more for every
      // pointer frame was avoidable main-thread work (particularly for
      // gradients/curves and older multi-step FX recipes).
      effects: [...effects], complete,
    });
    // Keep the bounded queue responsive if multiple layers have effects.
    if (latest.size > 12) latest.delete(latest.keys().next().value as string);
    // Notify an in-flight job without transferring any image pixels. The
    // worker checks supersession between expensive processing stages.
    if (running && (running.sourceId !== sourceId || running.layer !== layer) &&
        (running.layer === layer || isInteractiveEffectPreview(layer))) {
      // When moving within a single slider/source, finish the ongoing exact
      // frame and display it even if a newer setting is already queued: that
      // is the only way to show progressive feedback rather than starving
      // every frame during a fast drag. Supersede only work for ANOTHER
      // animation cel/source or a background layer blocking this interaction.
      worker.postMessage({ kind: 'supersede', id: revision, sourceId: running.sourceId });
    }
    void dispatch();
    return true;
  };

  setAsyncEffectsProcessor(process);
  return () => {
    disposed = true;
    latest.clear();
    residentSources.clear();
    worker.terminate();
    setAsyncEffectsProcessor(null);
  };
}
