# Spectrum changelog

## 0.1.0 — Compact Creative Studio source update (2026-10-17)

- Reworked workspace density and layering of inspector, contextbar, titlebar and document tabs.
- Added eight individual fruit/floral/shadow theme CSS files, giving thirteen themes with independent light and dark palettes and unique controls.
- Moved FX to a dedicated launcher below the layer list, opening a searchable three-tab overlay (Filters / Customize / FX).
- Extended editable per-layer FX with invert, pixelate, posterize and vignette and added four new preset combinations.
- Added temporarily bypassed FX for before/after preview without dirtying the document.
- Added drag/keyboard document tab reordering, renaming and tab context actions.
- Expanded multiline text inspector, font editing, letter spacing and stroke endpoint handling.
- Expanded automated checks to 49 Node tests and 56 Chromium assertions.
- Maintained native `.spectrum` document version; no breaking format migration intended.

**Build note:** Full dependency-aware TypeScript/Vite checks, full React E2E and Windows Tauri build were not possible in the packaging environment. Source remains experimental until these gates pass.

## Spectrum 0.1 — Typography & native window update (2026-10-19)

The editor version remains **0.1.0**. This is not a new major release.

- Replaced the fixed 11-font datalist with `FontPicker`, a searchable dropdown listing OS-discovered font families in Tauri via Rust `fontdb` (with an explicitly labeled common-font preview fallback in browsers).
- Added font previews, refresh/search, keyboard selection, font family, size, regular/bold and italic controls directly in the compact text tool context bar.
- Introduced a shared, transient text draft in the editor store. Canvas typing now uses a native auto-focused textarea with a visible caret, multiline editing, Escape cancel and Ctrl+Enter commit. Text edit state survives changes to the font settings without premature blur commits.
- Click with the Text tool to create a text box or edit an existing one; double-click existing text in Move mode. Changed font properties stay editable in the `.spectrum` document and SVG/Canvas exports.
- Text commits are captured as a single history operation and flushed before save/export/document-switch, keeping document revision tracking correct.
- Replaced OS window decorations with a compact custom draggable titlebar and real Tauri minimize/maximize/restore/close controls; added explicit Tauri permissions and unsaved-change close warnings.
- Reduced the height of titlebar, document strip, context toolbar and tool rail. New shared `src/styles/typography.css` uses theme tokens so all existing appearance CSS files remain independent.
- Added regression tests for typography drafts, font family normalization, SVG export and window configuration, plus new UI E2E scenarios for caret focus and font selection.

**Verification limitation:** npm registry resolution and the Rust toolchain are unavailable in this container; the full React/MUI build and native Tauri launch still require a real Windows verification pass.
