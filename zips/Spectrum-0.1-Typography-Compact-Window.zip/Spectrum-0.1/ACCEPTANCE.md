# Spectrum 0.1 — Desktop Acceptance Checklist

These tasks require a machine with `npm install`, `npm run verify`, `npm run desktop:dev`, and a functioning Tauri OS toolchain. This checklist is a **test plan**, not a record of passing UI tests.

## Build and startup

- [ ] `npm install` creates a usable dependency tree and lockfile.
- [ ] `npm run check` completes without TypeScript errors using **real** dependency typings.
- [ ] `npm test` passes all behavior/source tests.
- [ ] `npm run build` creates a working `dist/` frontend bundle.
- [ ] `npm run desktop:dev` launches Spectrum in a native window.
- [ ] No errors appear in the browser/WebView console or Tauri native logs.

## Phase 1 — Stabilization

- [ ] Create a new 1280 × 800 document, reopen a saved project, close tabs with warnings.
- [ ] Import PNG/JPEG/WebP/GIF/BMP and verify pixel dimensions.
- [ ] Export PNG/JPEG/WebP/SVG; open each file externally and inspect its content.
- [ ] Make an edit, save, edit again, undo to saved state; verify dirty indicator changes correctly.
- [ ] Kill app with unsaved changes, relaunch, and verify recovery prompt without data corruption.

## Phases 2–3 — Workspace and contextual controls

- [ ] Palette icon opens theme menu; switching Glass/Material/Classic changes the *shape* and structure of components.
- [ ] Theme survives restarting the application.
- [ ] Brush selects size, hardness, opacity and smoothing; shape tools show fill and stroke.
- [ ] Tooltips and disabled actions display correctly; toolbar remains usable at 960 px width.
- [ ] Reduced-motion OS setting prevents unnecessary UI animation.

## Phases 4–5 — Selection, transforms and curves

- [ ] Select a vector rectangle and drag to move, resize from corners, rotate at top handle.
- [ ] Select a raster layer and transform; save/reopen; geometry is preserved.
- [ ] Draw a freehand vector path; press A; adjust an anchor and both handles.
- [ ] Observe live canvas preview while moving nodes or objects; undo each change.
- [ ] Select/edit multiline text in the inline canvas input; export SVG preserving line breaks.
- [ ] Export cubic Bézier paths as actual SVG C commands, not rasterized pixels.

## Phases 6–7 — Painting, masks and compositing

- [ ] Brush and erase existing artwork; mouse pressure remains consistent.
- [ ] If available, test stylus low vs high pressure, and soft vs hard brush edges.
- [ ] Create rectangular marquee; paint/erase; confirm edits do not escape selection.
- [ ] Apply selection mask to layer and verify visibility is clipped non-destructively.
- [ ] Remove mask and confirm unmasked artwork is restored.
- [ ] Test Normal, Multiply, Screen, Overlay, Darken and Lighten, then export PNG/SVG.
- [ ] Confirm trying to paint a transformed raster layer gives a clear error instead of corrupting pixels.

## Phase 8 — Workspaces

- [ ] Collapse and expand tool rail and inspector.
- [ ] Resize inspector, restart app and confirm width is retained.
- [ ] Click Focus Mode and exit via visible on-canvas Exit focus control.
- [ ] Focus canvas, press Tab and restore with Tab.

## Phase 9 — Performance

- [ ] Draw 5-minute strokes on a 4K canvas without visible UI stalls.
- [ ] Move a complex vector path and pan/zoom smoothly.
- [ ] Import an image with many megapixels; document opens without memory errors.
- [ ] Test history memory behavior with several raster edits and multiple tabs.
- [ ] Run on lower-end hardware where feasible.

## Phase 10 — Regression

- [ ] Run the Node regression suite and optional Chromium Canvas2D tests.
- [ ] Fix any regression and add a reproducing test for it.
- [ ] Confirm no console errors, missing assets, missing icons or broken theme menus remain.
- [ ] Repeat all checks on a packaged desktop release, not only development mode.

**Release gate:** Not ready until all relevant build/runtime acceptance checks pass. Do not label it stable based only on isolated source or Canvas2D tests.

## Creative tools, clipboard and Spectrum FX acceptance (2026-10-17)

- [ ] Copy a screenshot from Windows/your browser, focus Spectrum and press Ctrl+V; image lands on a centered separate raster layer.
- [ ] Save, close, reopen; pasted image survives with correct dimensions and transparency.
- [ ] Ctrl+Z removes a pasted image and Ctrl+Y restores it.
- [ ] Copy/cut a selected vector object, switch documents and paste; editable shape geometry remains intact.
- [ ] Create line; immediately see four draggable controls. Each changes the expected line section independently; undo reverts only the latest change.
- [ ] Create rectangle/ellipse, drag four corners and rotate without rasterizing; press Enter/Escape as applicable.
- [ ] Precision Pen click/drag creates a Bézier tangent, Enter commits, Backspace removes a pending node, Escape cancels an active path.
- [ ] Freehand path with smoothing zero follows raw mouse positions more faithfully than smoothed mode.
- [ ] Type multiline text with Enter, commit with Ctrl+Enter, double-click to edit, change family/weight/size/alignment and save/reopen.
- [ ] Apply Glow and Outline together in FX; change the order, disable an effect, undo a change, export PNG and compare with canvas.
- [ ] Apply each thumbnail FX preset and verify that it creates editable stack entries.
- [ ] Check all five palette themes in dark/light environments and confirm they have different control shapes and finishes.
- [ ] Customize a keyboard shortcut in the gear menu; restart Spectrum and confirm it persists.
- [ ] Test 1280×720 thumbnail and a large layered project for stalls, memory growth, lost brush strokes and crashed previews.
- [ ] Run `npm run verify`, `npm run test:browser`, `python tests/ui-e2e.py`, and `npm run desktop:build` without errors before public release.

## Compact Creative Studio acceptance — October 17

- [ ] Open theme palette and verify all **13 names** render correctly in the menu. Switch each theme through Light and Dark; controls, active tabs, backgrounds and popup menus change consistently without shifting document pixels.
- [ ] Restart app; chosen theme and brightness mode persist.
- [ ] At 1280×720 window dimensions, the compact titlebar, tab strip, context toolbar, toolrail and inspector remain usable without overlapping the artboard.
- [ ] Ensure the **Spectrum FX** button is **directly below the layer list, above the layer-management icons**; it must not be in the inspector tab row.
- [ ] Click FX button, observe a floating searchable panel with exactly **Filters / Customize / FX** tabs. Close via Escape, X, and click-outside.
- [ ] In Filters, search and apply brightness, invert, pixelate, posterize and vignette on an image layer. Verify exported PNG matches preview within renderer precision.
- [ ] In Customize, select a vector rectangle and adjust fill/stroke/width; select a raster layer and adjust blend mode and opacity. Disabled controls must make sense when a layer is locked.
- [ ] In FX, apply Neon Pulse and Golden Hour; toggle/reorder/adjust an effect; hold Compare and confirm original image is temporarily shown but document history is unchanged.
- [ ] Save and reopen `.spectrum`; effect orders, kinds, intensity, enablement and colors remain editable.
- [ ] Rename document by double click, reorder tabs by dragging, reorder with Alt+arrows, duplicate with right-click menu; close other tabs with appropriate unsaved-work warning.
- [ ] Edit multiline text using the canvas overlay and the inspector content field. Ctrl+Enter commits inspector text; Ctrl+Z undoes the change once.
- [ ] Draw with zero smoothing and with increased smoothing; both strokes finish precisely under pointer-up position. If available, test with a stylus and coalesced pointer events.
- [ ] Test native Windows image paste with transparent PNG and a screenshot; ensure editable separate layer, correct pixels and dimensions, undo/redo and save/reopen.
- [ ] Resize/rotate rectangle and ellipse via handles, edit all four line control points, edit Bézier nodes, undo, save and reopen, and verify all geometry stays editable.
- [ ] Test various window resolutions and Windows display scaling (100%, 125%, 150%), keyboard focus visibility and OS reduced-motion behavior.
- [ ] Run `npm run check`, `npm test`, `npm run test:browser`, `npm run test:ui`, `npm run build`, and both Tauri dev/build with no errors; record any defects and write regression coverage for each.

**Not yet satisfied by synthetic tests:** genuine Windows desktop installation, sophisticated selection and mask workflows, high-load performance, complex typography, vector boolean operations, color management and GPU rendering. These need dedicated engineering and acceptance before Spectrum can be called professional-grade.

## Typography & custom window bar — 2026-10-19 (not executed on Windows)

- [ ] Start Spectrum in **Tauri** (not just the browser preview) and confirm there is no double/native Windows caption bar; move the window by dragging the Spectrum header.
- [ ] Verify Minimize, Maximize, Restore and Close buttons; press Alt+F4 with unsaved work and confirm the cancel option prevents closing.
- [ ] Activate **Text (T)**: the top context bar must already show the installed-font picker, size, bold, italic and color.
- [ ] Open font picker, search several fonts installed on this Windows account (including recently installed fonts), refresh, select one and verify it is used on canvas.
- [ ] With Text (T), click a blank canvas. The textarea must immediately receive keyboard focus and show an active, blinking typing caret. Type three lines, navigate with arrows, select characters, copy and paste text.
- [ ] While still typing, change font family and size via the context bar. The text must remain uncommitted, the caret must be restored after selection, and typing must continue in the same editor.
- [ ] Ctrl+Enter must commit *one* document history entry; Ctrl+Z undoes all text from that session; Ctrl+Y restores it.
- [ ] With Text (T), single-click existing text to edit; with Move (V), double-click existing text to edit; Esc cancels without altering the existing object.
- [ ] Change color, weight, italic and letter spacing; save `.spectrum`, reopen, and verify all properties remain editable; export PNG/SVG and inspect output.
- [ ] Switch document tabs mid-typing; text must commit to the original document, not the next tab. Save or export while typing should include the latest text.
- [ ] Inspect layout at Windows display scaling 100%, 125% and 150%, including all Strawberry, Shadow and Glass themes and narrow window sizes.

**Release gate:** These are manual Windows acceptance tests, **not passed tests**. Record failures and add a regression test for each bug.
