import { uid, type Effect, type EffectKind, type Layer } from './types';

export const FILTERS: { kind: EffectKind; label: string; initial: number }[] = [
  { kind: 'brightness', label: 'Brightness', initial: 115 },
  { kind: 'contrast', label: 'Contrast', initial: 120 },
  { kind: 'saturate', label: 'Saturation', initial: 140 },
  { kind: 'hue', label: 'Hue rotation', initial: 30 },
  { kind: 'grayscale', label: 'Grayscale', initial: 100 },
  { kind: 'sepia', label: 'Sepia', initial: 80 },
  { kind: 'blur', label: 'Gaussian blur', initial: 5 },
  { kind: 'shadow', label: 'Drop shadow', initial: 12 },
  { kind: 'glow', label: 'Spectrum glow', initial: 16 },
  { kind: 'outline', label: 'Hyper outline', initial: 6 },
  { kind: 'chromatic', label: 'Chromatic split', initial: 6 },
  { kind: 'invert', label: 'Invert colors', initial: 100 },
  { kind: 'pixelate', label: 'Pixelate', initial: 10 },
  { kind: 'posterize', label: 'Posterize', initial: 6 },
  { kind: 'vignette', label: 'Vignette', initial: 75 },
];

export const FX_PRESETS: Record<string, { kind: EffectKind; amount: number; color?: string }[]> = {
  'Neon Pulse': [
    { kind: 'outline', amount: 5, color: '#4de3ff' },
    { kind: 'glow', amount: 22, color: '#8e55ff' },
    { kind: 'contrast', amount: 120 },
  ],
  'Shadow Forge': [
    { kind: 'shadow', amount: 22, color: '#171327' },
    { kind: 'contrast', amount: 112 },
  ],
  'Hyper Outline': [
    { kind: 'outline', amount: 10, color: '#f7f8ff' },
    { kind: 'shadow', amount: 10, color: '#050816' },
  ],
  'Glitch Matrix': [
    { kind: 'chromatic', amount: 7 },
    { kind: 'contrast', amount: 145 },
    { kind: 'saturate', amount: 160 },
  ],
  'Dream Bloom': [
    { kind: 'glow', amount: 14, color: '#c8a5ff' },
    { kind: 'saturate', amount: 118 },
  ],
  'Prism Split': [
    { kind: 'chromatic', amount: 8 },
    { kind: 'glow', amount: 10, color: '#6a8dff' },
  ],
  'Golden Hour': [
    { kind: 'sepia', amount: 30 },
    { kind: 'saturate', amount: 128 },
    { kind: 'contrast', amount: 108 },
  ],
  'Frostbite': [
    { kind: 'outline', amount: 5, color: '#9ae5ff' },
    { kind: 'glow', amount: 14, color: '#58a9ff' },
  ],
  'Ember Glow': [
    { kind: 'outline', amount: 5, color: '#ffac56' },
    { kind: 'glow', amount: 17, color: '#ff5529' },
  ],
  'Comic Pop': [
    { kind: 'contrast', amount: 160 },
    { kind: 'saturate', amount: 160 },
    { kind: 'outline', amount: 3, color: '#181526' },
  ],
};

export function newEffect(kind: EffectKind, amount?: number, color?: string): Effect {
  const definition = FILTERS.find(item => item.kind === kind);
  return {
    id: uid(),
    kind,
    enabled: true,
    amount: Math.max(0, Math.min(200, amount ?? definition?.initial ?? 100)),
    color,
  };
}

export function effectFilter(effect: Effect): string {
  const amount = Math.max(0, Math.min(200, effect.amount));
  switch (effect.kind) {
    case 'brightness': return `brightness(${amount}%)`;
    case 'contrast': return `contrast(${amount}%)`;
    case 'saturate': return `saturate(${amount}%)`;
    case 'hue': return `hue-rotate(${amount}deg)`;
    case 'grayscale': return `grayscale(${Math.min(amount, 100)}%)`;
    case 'sepia': return `sepia(${Math.min(amount, 100)}%)`;
    case 'blur': return `blur(${Math.min(amount, 70)}px)`;
    case 'invert': return `invert(${Math.min(amount, 100)}%)`;
    default: return 'none';
  }
}

/** Apply effects to an offscreen image in sequence without modifying the layer's source pixels. */
export function processEffects(
  source: HTMLCanvasElement,
  effects: readonly Effect[],
): HTMLCanvasElement {
  const visible = effects.filter(effect => effect.enabled && effect.amount > 0);
  let current = source;
  for (const effect of visible) {
    const target = document.createElement('canvas');
    target.width = source.width;
    target.height = source.height;
    const ctx = target.getContext('2d');
    if (!ctx) return current;
    if (['brightness', 'contrast', 'saturate', 'hue', 'grayscale', 'sepia', 'blur', 'invert'].includes(effect.kind)) {
      ctx.filter = effectFilter(effect);
      ctx.drawImage(current, 0, 0);
    } else if (effect.kind === 'pixelate') {
      const cellSize = Math.max(2, Math.round(effect.amount));
      const pixelWidth = Math.max(1, Math.ceil(current.width / cellSize));
      const pixelHeight = Math.max(1, Math.ceil(current.height / cellSize));
      const small = document.createElement('canvas');
      small.width = pixelWidth;
      small.height = pixelHeight;
      const smallCtx = small.getContext('2d');
      if (!smallCtx) return current;
      smallCtx.imageSmoothingEnabled = false;
      smallCtx.drawImage(current, 0, 0, pixelWidth, pixelHeight);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(small, 0, 0, source.width, source.height);
    } else if (effect.kind === 'posterize') {
      ctx.drawImage(current, 0, 0);
      // ImageData processing preserves transparency and changes color channels only.
      // Clamp the lowest value to two buckets to prevent division by zero.
      const levels = Math.max(2, Math.min(32, Math.round(effect.amount)));
      const image = ctx.getImageData(0, 0, source.width, source.height);
      const step = 255 / (levels - 1);
      for (let index = 0; index < image.data.length; index += 4) {
        for (let channel = 0; channel < 3; channel++) {
          image.data[index + channel] = Math.round(image.data[index + channel] / step) * step;
        }
      }
      ctx.putImageData(image, 0, 0);
    } else if (effect.kind === 'vignette') {
      ctx.drawImage(current, 0, 0);
      const radius = Math.hypot(source.width, source.height) * 0.52;
      const gradient = ctx.createRadialGradient(
        source.width / 2, source.height / 2, radius * 0.12,
        source.width / 2, source.height / 2, radius,
      );
      gradient.addColorStop(0, '#00000000');
      gradient.addColorStop(1, `rgba(0,0,0,${Math.min(0.9, effect.amount / 200)})`);
      ctx.fillStyle = gradient;
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillRect(0, 0, source.width, source.height);
      ctx.globalCompositeOperation = 'source-over';
    } else if (effect.kind === 'shadow' || effect.kind === 'glow') {
      const spread = Math.min(80, effect.amount);
      ctx.shadowColor = effect.color ?? (effect.kind === 'glow' ? '#a278ff' : '#000000');
      ctx.shadowBlur = spread;
      ctx.shadowOffsetX = effect.kind === 'shadow' ? spread * 0.5 : 0;
      ctx.shadowOffsetY = effect.kind === 'shadow' ? spread * 0.5 : 0;
      ctx.drawImage(current, 0, 0);
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
    } else if (effect.kind === 'outline') {
      const radius = Math.max(1, Math.min(36, Math.round(effect.amount)));
      const silhouette = document.createElement('canvas');
      silhouette.width = source.width;
      silhouette.height = source.height;
      const silhouetteCtx = silhouette.getContext('2d');
      if (!silhouetteCtx) return current;
      for (let index = 0; index < 32; index++) {
        const angle = Math.PI * 2 * index / 32;
        silhouetteCtx.drawImage(current, Math.cos(angle) * radius, Math.sin(angle) * radius);
      }
      silhouetteCtx.globalCompositeOperation = 'source-in';
      silhouetteCtx.fillStyle = effect.color ?? '#ffffff';
      silhouetteCtx.fillRect(0, 0, source.width, source.height);
      ctx.drawImage(silhouette, 0, 0);
      ctx.drawImage(current, 0, 0);
    } else if (effect.kind === 'chromatic') {
      const offset = Math.round(Math.min(28, effect.amount));
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      for (const [shift, tint] of [[-offset, '#ff365d'], [0, '#54eaff'], [offset, '#384fff']] as const) {
        const channel = document.createElement('canvas');
        channel.width = source.width;
        channel.height = source.height;
        const channelCtx = channel.getContext('2d');
        if (!channelCtx) continue;
        channelCtx.drawImage(current, 0, 0);
        channelCtx.globalCompositeOperation = 'source-in';
        channelCtx.fillStyle = tint;
        channelCtx.fillRect(0, 0, channel.width, channel.height);
        ctx.drawImage(channel, shift, 0);
      }
      ctx.restore();
    }
    current = target;
  }
  return current;
}

/** Render a layer to document-sized, transparent surface. Prefer direct rendering when no FX. */
const vectorEffectCache = new WeakMap<Layer, { width: number; height: number; image: HTMLCanvasElement }>();

export function renderWithEffects(
  ctx: CanvasRenderingContext2D,
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
): void {
  const effects = layer.effects ?? [];
  if (!effects.some(effect => effect.enabled && effect.amount > 0)) {
    paint(ctx, layer);
    return;
  }
  const cached = layer.type === 'vector' ? vectorEffectCache.get(layer) : undefined;
  if (cached && cached.width === width && cached.height === height) {
    ctx.drawImage(cached.image, 0, 0, width, height);
    return;
  }
  const source = document.createElement('canvas');
  const scale = Math.min(1, Math.sqrt(16_000_000 / Math.max(1, width * height)));
  source.width = Math.max(1, Math.floor(width * scale));
  source.height = Math.max(1, Math.floor(height * scale));
  const temporary = source.getContext('2d');
  if (!temporary) return;
  temporary.scale(scale, scale);
  paint(temporary, layer);
  const processed = processEffects(source, effects);
  if (layer.type === 'vector') vectorEffectCache.set(layer, { width, height, image: processed });
  ctx.drawImage(processed, 0, 0, width, height);
}
