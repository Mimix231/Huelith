import { useEffect, useRef, useState } from 'react';
import { Button, Slider } from '@mui/material';
import { AutoAwesome, Close, Search, Tune, Palette } from '@mui/icons-material';
import { FILTERS, FX_PRESETS, newEffect } from '../editor/fx';
import type { EditorStore } from '../editor/store';
import type { BlendMode, Effect, EffectKind, Layer, VectorShape } from '../editor/types';

type StudioTab = 'filters' | 'customization' | 'fx';

interface FxStudioProps {
  state: EditorStore;
  active?: Layer;
  activeShape?: VectorShape;
  onClose: () => void;
}

const groups: { label: string; kinds: EffectKind[] }[] = [
  { label: 'Color & light', kinds: ['brightness', 'contrast', 'saturate', 'hue', 'grayscale', 'sepia', 'invert'] },
  { label: 'Detail & texture', kinds: ['blur', 'pixelate', 'posterize', 'vignette'] },
  { label: 'Stylize', kinds: ['chromatic', 'outline', 'glow', 'shadow'] },
];

const blends: { id: BlendMode; label: string }[] = [
  { id: 'source-over', label: 'Normal' },
  { id: 'multiply', label: 'Multiply' },
  { id: 'screen', label: 'Screen' },
  { id: 'overlay', label: 'Overlay' },
  { id: 'darken', label: 'Darken' },
  { id: 'lighten', label: 'Lighten' },
];

function EffectAmount({ effect, onChange }: { effect: Effect; onChange: (amount: number) => void }) {
  const [draft, setDraft] = useState(effect.amount);

  useEffect(() => setDraft(effect.amount), [effect.amount]);

  return (
    <label className="fx-level">
      <span>Intensity <output>{Math.round(draft)}</output></span>
      <Slider
        aria-label={`${effect.kind} intensity`}
        value={draft}
        size="small"
        min={0}
        max={200}
        onChange={(_, value) => setDraft(value as number)}
        onChangeCommitted={(_, value) => onChange(value as number)}
      />
    </label>
  );
}

export default function FxStudio({ state, active, activeShape, onClose }: FxStudioProps) {
  const [tab, setTab] = useState<StudioTab>('filters');
  const [query, setQuery] = useState('');
  const panelRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const permitted = Boolean(active && !active.locked);
  const normalizedQuery = query.trim().toLowerCase();

  useEffect(() => {
    const dismiss = (event: PointerEvent): void => {
      if (event.target instanceof Element
        && !event.target.closest('.fx-overlay, .fx-launcher, .MuiPopover-root')) closeRef.current();
    };
    const escape = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        closeRef.current();
      }
    };
    document.addEventListener('pointerdown', dismiss);
    document.addEventListener('keydown', escape, true);
    panelRef.current?.focus();
    return () => {
      document.removeEventListener('pointerdown', dismiss);
      document.removeEventListener('keydown', escape, true);
      state.setFxBypassLayer(null);
    };
  }, []);

  const effects = active?.effects ?? [];
  const matches = (label: string): boolean => label.toLowerCase().includes(normalizedQuery);

  return (
    <div className="fx-overlay" id="spectrum-fx-studio" role="dialog"
      aria-modal="false" aria-labelledby="fx-title" tabIndex={-1} ref={panelRef}>
      <div className="fx-overlay-header">
        <div className="fx-overlay-title">
          <span className="fx-overlay-symbol"><AutoAwesome fontSize="small" /></span>
          <div><strong id="fx-title">Spectrum Studio</strong><small>Creative effects · non-destructive layers</small></div>
        </div>
        <button type="button" aria-label="Close FX studio" className="fx-close" onClick={onClose}><Close fontSize="small" /></button>
      </div>
      <div className="fx-studio-tabs" role="tablist" aria-label="Effect library">
        {(['filters', 'customization', 'fx'] as const).map(option => (
          <button type="button" role="tab" aria-selected={tab === option}
            className={tab === option ? 'active' : ''} key={option}
            onClick={() => { setTab(option); setQuery(''); }}>
            {option === 'filters' ? <Tune fontSize="small" /> : option === 'customization' ? <Palette fontSize="small" /> : <AutoAwesome fontSize="small" />}
            <span>{option === 'fx' ? 'FX' : option === 'customization' ? 'Customize' : 'Filters'}</span>
          </button>
        ))}
      </div>
      {tab !== 'customization' && (
        <label className="fx-search">
          <Search fontSize="small" />
          <input type="search" placeholder={tab === 'fx' ? 'Find a creative preset…' : 'Find a filter…'}
            aria-label="Search FX library" value={query} onChange={event => setQuery(event.target.value)} />
        </label>
      )}
      <div className="fx-overlay-body">
        {!active && <div className="fx-notice">Select a layer to apply effects.</div>}
        {active?.locked && <div className="fx-notice">Unlock this layer to edit its appearance.</div>}
        {tab === 'filters' && (
          <div className="fx-filter-groups">
            {groups.map(group => {
              const visible = group.kinds.map(kind => FILTERS.find(item => item.kind === kind))
                .filter((filter): filter is typeof FILTERS[number] => Boolean(filter && matches(filter.label)));
              if (!visible.length) return null;
              return (
                <section key={group.label}>
                  <h3>{group.label}</h3>
                  <div className="fx-filter-grid">
                    {visible.map(filter => (
                      <button key={filter.kind} type="button" className="fx-filter-card"
                        disabled={!permitted} title={`Add ${filter.label} to the effect stack`}
                        onClick={() => active && state.addEffect(active.id, filter.kind)}>
                        <span className={`fx-filter-mark fx-filter-${filter.kind}`} aria-hidden="true" />
                        <span>{filter.label}</span>
                        <b aria-hidden="true">＋</b>
                      </button>
                    ))}
                  </div>
                </section>
              );
            })}
            {!groups.some(group => group.kinds.some(kind => {
              const definition = FILTERS.find(item => item.kind === kind);
              return definition && matches(definition.label);
            })) && <p className="fx-empty">No matching filters.</p>}
          </div>
        )}
        {tab === 'customization' && (
          <div className="fx-customize">
            <h3>{activeShape ? 'Vector style' : 'Layer styling'}</h3>
            {activeShape && (
              <>
                <label className="fx-customize-row">
                  <span>Fill</span>
                  <input aria-label="Object fill" type="color"
                    value={activeShape.fill !== 'none' ? activeShape.fill : '#ffffff'}
                    onChange={event => state.updateShape(activeShape.id, shape => { shape.fill = event.target.value; })} />
                </label>
                <label className="fx-customize-row">
                  <span>Stroke</span>
                  <input aria-label="Object stroke" type="color"
                    value={activeShape.stroke !== 'none' ? activeShape.stroke : '#000000'}
                    onChange={event => state.updateShape(activeShape.id, shape => { shape.stroke = event.target.value; })} />
                </label>
                <label className="fx-customize-row"><span>Stroke width</span>
                  <input aria-label="Object stroke width" type="number" min={0} max={250}
                    value={activeShape.strokeWidth}
                    onChange={event => state.updateShape(activeShape.id, shape => {
                      shape.strokeWidth = Math.max(0, Math.min(250, Number(event.target.value) || 0));
                    })} />
                </label>
              </>
            )}
            {active && (
              <>
                <label className="fx-customize-row"><span>Blend mode</span>
                  <select aria-label="Layer blending" disabled={!permitted} value={active.blend}
                    onChange={event => state.setLayerBlend(active.id, event.target.value as BlendMode)}>
                    {blends.map(blend => <option key={blend.id} value={blend.id}>{blend.label}</option>)}
                  </select>
                </label>
                <label className="fx-customize-row"><span>Opacity</span>
                  <output>{Math.round(active.opacity * 100)}%</output>
                </label>
                <Slider size="small" disabled={!permitted} aria-label="Layer opacity"
                  min={0} max={100} value={Math.round(active.opacity * 100)}
                  onChangeCommitted={(_, value) => state.setLayerOpacity(active.id, (value as number) / 100)} />
                <div className="fx-quick-actions">
                  <Button size="small" disabled={!state.selection || !permitted}
                    onClick={() => state.applySelectionMask(active.id)}>Mask selection</Button>
                  <Button size="small" disabled={!active.mask || !permitted}
                    onClick={() => state.clearLayerMask(active.id)}>Clear mask</Button>
                </div>
              </>
            )}
            <p className="fx-subtle">These adjustments stay editable in your .spectrum project.</p>
          </div>
        )}
        {tab === 'fx' && (
          <div className="fx-presets">
            <h3>Signature effects</h3>
            <div className="fx-preset-grid">
              {Object.entries(FX_PRESETS).filter(([name]) => matches(name)).map(([name, preset]) => (
                <button type="button" className="fx-preset-card" disabled={!permitted} key={name}
                  onClick={() => active && state.appendEffects(active.id,
                    preset.map(effect => newEffect(effect.kind, effect.amount, effect.color)))}>
                  <span className={`fx-preset-art fx-preset-${name.toLowerCase().replaceAll(' ', '-')}`} aria-hidden="true">✦</span>
                  <strong>{name}</strong>
                  <small>{preset.length} adjustable effects</small>
                </button>
              ))}
            </div>
            {!Object.keys(FX_PRESETS).some(matches) && <p className="fx-empty">No matching FX presets.</p>}
          </div>
        )}
        <section className="fx-applied">
          <div className="fx-applied-heading"><h3>Applied effects</h3><span>{effects.length}</span></div>
          {effects.map((effect, index) => (
            <div className="fx-effect" key={effect.id}>
              <div className="fx-effect-title">
                <label>
                  <input aria-label={`Enable ${effect.kind}`} type="checkbox" checked={effect.enabled}
                    disabled={!permitted}
                    onChange={event => active && state.updateEffect(active.id, effect.id, { enabled: event.target.checked })} />
                  <strong>{FILTERS.find(item => item.kind === effect.kind)?.label ?? effect.kind}</strong>
                </label>
                <div className="fx-effect-actions">
                  <button type="button" aria-label={`Move ${effect.kind} earlier`} title="Move earlier"
                    disabled={!permitted || index === 0}
                    onClick={() => active && state.moveEffect(active.id, effect.id, -1)}>↑</button>
                  <button type="button" aria-label={`Move ${effect.kind} later`} title="Move later"
                    disabled={!permitted || index === effects.length - 1}
                    onClick={() => active && state.moveEffect(active.id, effect.id, 1)}>↓</button>
                  <button type="button" aria-label={`Remove ${effect.kind}`} title="Remove effect"
                    disabled={!permitted} onClick={() => active && state.removeEffect(active.id, effect.id)}>×</button>
                </div>
              </div>
              <EffectAmount effect={effect} onChange={amount => active && state.updateEffect(active.id, effect.id, { amount })} />
              {['glow', 'outline', 'shadow'].includes(effect.kind) && (
                <label className="fx-customize-row"><span>Color</span>
                  <input aria-label={`${effect.kind} color`} type="color"
                    value={effect.color ?? '#986dff'} disabled={!permitted}
                    onChange={event => active && state.updateEffect(active.id, effect.id, { color: event.target.value })} />
                </label>
              )}
            </div>
          ))}
          {!effects.length && <p className="fx-subtle">Choose a filter or FX preset above. Nothing is baked into the original pixels.</p>}
        </section>
      </div>
      <div className="fx-overlay-footer">
        <button className="fx-compare" type="button" disabled={!active || !effects.length}
          title="Hold to see the selected layer without FX"
          onPointerDown={() => active && state.setFxBypassLayer(active.id)}
          onPointerUp={() => state.setFxBypassLayer(null)}
          onPointerCancel={() => state.setFxBypassLayer(null)}
          onPointerLeave={() => state.setFxBypassLayer(null)}
          onKeyDown={event => {
            if (event.key === ' ' || event.key === 'Enter') state.setFxBypassLayer(active?.id ?? null);
          }}
          onKeyUp={() => state.setFxBypassLayer(null)}
          onBlur={() => state.setFxBypassLayer(null)}>
          ◉ Hold to compare
        </button>
        <button type="button" onClick={onClose}>Done</button>
      </div>
    </div>
  );
}
