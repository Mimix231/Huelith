## 2026-10-20 — Spectrum 0.1 Professional Editing Overhaul (A–J)

- Added categorised desktop-style menus and common command registry.
- Refreshed canvas workspace presentation and reduced theme-specific background distractions.
- Added hit-tested, rotation-aware resize cursors, returning to normal outside handles.
- Added seven editable parametric shapes rendered consistently in Canvas2D and SVG.
- Separated text selection/movement (single click) from editing (double click).
- Introduced per-effect parameter units and meaningful ranges; added seeded glitch density and scanline controls.
- Implemented in-flight live effect previews with one undo entry per committed slider gesture.
- Kept thirteen distinct themes with light/dark modes and fixed portalled menu theme class propagation.
- Split out menu, interaction and shape geometry utilities; removed dead welcome CSS.
- Added automated regression and browser pixel assertions; full Windows desktop build remains unverified due to missing npm registry and Rust toolchain.
- Version stays **0.1.0**.

# Spectrum changelog

## 0.1.0 — Compact Creative Studio source update (2026-10-17)

- Reworked workspace density and layering of inspector, contextbar, titlebar and document tabs.
- Added eight individual fruit/floral/shadow theme CSS files, giving thirteen themes with independent light and dark palettes and unique controls.
- Moved FX to a dedicated launcher below the layer list, opening a searchable three-tab overlay (Filters / Customize / FX).
- Extended editable per-layer FX with invert, pixelate, posterize and vignette and added four new preset combinations.
- Added temporarily bypassed FX for before/after preview without dirtying the document.
- Added drag/keyboard document tab reordering, renaming and tab context actions.
- Expanded multiline text inspector, font editing, letter spacing and stroke endpoint handling.
- Expanded automated checks to 49 Node tests and 56 Chromium assertions.
- Maintained native `.spectrum` document version; no breaking format migration intended.

**Build note:** Full dependency-aware TypeScript/Vite checks, full React E2E and Windows Tauri build were not possible in the packaging environment. Source remains experimental until these gates pass.

## Spectrum 0.1 — Typography & native window update (2026-10-19)

The editor version remains **0.1.0**. This is not a new major release.

- Replaced the fixed 11-font datalist with `FontPicker`, a searchable dropdown listing OS-discovered font families in Tauri via Rust `fontdb` (with an explicitly labeled common-font preview fallback in browsers).
- Added font previews, refresh/search, keyboard selection, font family, size, regular/bold and italic controls directly in the compact text tool context bar.
- Introduced a shared, transient text draft in the editor store. Canvas typing now uses a native auto-focused textarea with a visible caret, multiline editing, Escape cancel and Ctrl+Enter commit. Text edit state survives changes to the font settings without premature blur commits.
- Click with the Text tool to create a text box or edit an existing one; double-click existing text in Move mode. Changed font properties stay editable in the `.spectrum` document and SVG/Canvas exports.
- Text commits are captured as a single history operation and flushed before save/export/document-switch, keeping document revision tracking correct.
- Replaced OS window decorations with a compact custom draggable titlebar and real Tauri minimize/maximize/restore/close controls; added explicit Tauri permissions and unsaved-change close warnings.
- Reduced the height of titlebar, document strip, context toolbar and tool rail. New shared `src/styles/typography.css` uses theme tokens so all existing appearance CSS files remain independent.
- Added regression tests for typography drafts, font family normalization, SVG export and window configuration, plus new UI E2E scenarios for caret focus and font selection.

**Verification limitation:** npm registry resolution and the Rust toolchain are unavailable in this container; the full React/MUI build and native Tauri launch still require a real Windows verification pass.

### 2026-10-19 — Spectrum 0.1 animation workspace, FX motion and cleanup

- Added optional frame-by-frame animation projects with a draggable playhead, compact timeline thumbnails, frame insertion/duplication/deletion/reordering, per-frame durations, playback, previous/next onion skins and transparency controls.
- Added APNG, PNG sprite-sheet and zipped PNG-sequence export with safeguards for large output.
- Replaced the forced glass-blurred welcome screen with immediate editor startup and non-modal recovery of unsaved documents.
- Improved Spectrum FX with additional shadow/glow/chromatic parameters, refined non-destructive composition, and accessible opening/closing transitions.
- Added theme-specific timeline details for eight colorful themes, without changing the appearance of edited artwork.
- Added a conservative, dry-run-first obsolete-source removal script and automated animation/APNG/ZIP/timeline tests.
- Optimized playhead scrubbing with structural sharing and visible thumbnail caching; full render-worker/tiled architecture remains future engineering work.
- Version intentionally remains **0.1.0**.
