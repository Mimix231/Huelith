import { uid, type Effect, type EffectKind, type Layer } from './types';

/** One source of truth for meaningful controls, supported ranges and units. */
export const EFFECT_CONTROLS: Record<EffectKind, { label: string; min: number; max: number; step: number; unit: string }> = {
  brightness: { label: 'Brightness', min: 0, max: 300, step: 1, unit: '%' },
  contrast: { label: 'Contrast', min: 0, max: 300, step: 1, unit: '%' },
  saturate: { label: 'Saturation', min: 0, max: 300, step: 1, unit: '%' },
  hue: { label: 'Hue rotation', min: 0, max: 360, step: 1, unit: '°' },
  grayscale: { label: 'Grayscale strength', min: 0, max: 100, step: 1, unit: '%' },
  sepia: { label: 'Sepia strength', min: 0, max: 100, step: 1, unit: '%' },
  blur: { label: 'Blur radius', min: 0, max: 80, step: 0.5, unit: 'px' },
  shadow: { label: 'Shadow spread', min: 0, max: 70, step: 1, unit: 'px' },
  glow: { label: 'Glow spread', min: 0, max: 70, step: 1, unit: 'px' },
  outline: { label: 'Outline radius', min: 0, max: 48, step: 1, unit: 'px' },
  chromatic: { label: 'Channel separation', min: 0, max: 70, step: 1, unit: 'px' },
  invert: { label: 'Inversion', min: 0, max: 100, step: 1, unit: '%' },
  pixelate: { label: 'Pixel size', min: 1, max: 80, step: 1, unit: 'px' },
  posterize: { label: 'Color levels', min: 2, max: 32, step: 1, unit: '' },
  vignette: { label: 'Vignette intensity', min: 0, max: 100, step: 1, unit: '%' },
};

export function clampEffectAmount(kind: EffectKind, amount: number): number {
  const { min, max } = EFFECT_CONTROLS[kind];
  return Math.max(min, Math.min(max, Number.isFinite(amount) ? amount : min));
}

export const FILTERS: { kind: EffectKind; label: string; initial: number }[] = [
  { kind: 'brightness', label: 'Brightness', initial: 115 },
  { kind: 'contrast', label: 'Contrast', initial: 120 },
  { kind: 'saturate', label: 'Saturation', initial: 140 },
  { kind: 'hue', label: 'Hue rotation', initial: 30 },
  { kind: 'grayscale', label: 'Grayscale', initial: 100 },
  { kind: 'sepia', label: 'Sepia', initial: 80 },
  { kind: 'blur', label: 'Gaussian blur', initial: 5 },
  { kind: 'shadow', label: 'Drop shadow', initial: 12 },
  { kind: 'glow', label: 'Spectrum glow', initial: 16 },
  { kind: 'outline', label: 'Hyper outline', initial: 6 },
  { kind: 'chromatic', label: 'Chromatic split', initial: 6 },
  { kind: 'invert', label: 'Invert colors', initial: 100 },
  { kind: 'pixelate', label: 'Pixelate', initial: 10 },
  { kind: 'posterize', label: 'Posterize', initial: 6 },
  { kind: 'vignette', label: 'Vignette', initial: 75 },
];

export const FX_PRESETS: Record<string, { kind: EffectKind; amount: number; color?: string; parameters?: Effect['parameters'] }[]> = {
  'Neon Pulse': [
    { kind: 'outline', amount: 5, color: '#4de3ff' },
    { kind: 'glow', amount: 22, color: '#8e55ff' },
    { kind: 'contrast', amount: 120 },
  ],
  'Shadow Forge': [
    { kind: 'shadow', amount: 22, color: '#171327' },
    { kind: 'contrast', amount: 112 },
  ],
  'Hyper Outline': [
    { kind: 'outline', amount: 10, color: '#f7f8ff' },
    { kind: 'shadow', amount: 10, color: '#050816' },
  ],
  'Glitch Matrix': [
    { kind: 'chromatic', amount: 7, parameters: { density: 55, seed: 18, scanlines: 36, shiftY: 3 } },
    { kind: 'contrast', amount: 145 },
    { kind: 'saturate', amount: 160 },
  ],
  'Dream Bloom': [
    { kind: 'glow', amount: 14, color: '#c8a5ff' },
    { kind: 'saturate', amount: 118 },
  ],
  'Prism Split': [
    { kind: 'chromatic', amount: 8 },
    { kind: 'glow', amount: 10, color: '#6a8dff' },
  ],
  'Golden Hour': [
    { kind: 'sepia', amount: 30 },
    { kind: 'saturate', amount: 128 },
    { kind: 'contrast', amount: 108 },
  ],
  'Frostbite': [
    { kind: 'outline', amount: 5, color: '#9ae5ff' },
    { kind: 'glow', amount: 14, color: '#58a9ff' },
  ],
  'Ember Glow': [
    { kind: 'outline', amount: 5, color: '#ffac56' },
    { kind: 'glow', amount: 17, color: '#ff5529' },
  ],
  'Comic Pop': [
    { kind: 'contrast', amount: 160 },
    { kind: 'saturate', amount: 160 },
    { kind: 'outline', amount: 3, color: '#181526' },
  ],
};

export function newEffect(kind: EffectKind, amount?: number, color?: string, parameters?: Effect['parameters']): Effect {
  const definition = FILTERS.find(item => item.kind === kind);
  return {
    id: uid(),
    kind,
    enabled: true,
    amount: clampEffectAmount(kind, amount ?? definition?.initial ?? 100),
    color,
    ...(parameters ? { parameters } : {}),
  };
}

export function effectFilter(effect: Effect): string {
  const amount = clampEffectAmount(effect.kind, effect.amount);
  switch (effect.kind) {
    case 'brightness': return `brightness(${amount}%)`;
    case 'contrast': return `contrast(${amount}%)`;
    case 'saturate': return `saturate(${amount}%)`;
    case 'hue': return `hue-rotate(${amount}deg)`;
    case 'grayscale': return `grayscale(${Math.min(amount, 100)}%)`;
    case 'sepia': return `sepia(${Math.min(amount, 100)}%)`;
    case 'blur': return `blur(${amount}px)`;
    case 'invert': return `invert(${Math.min(amount, 100)}%)`;
    default: return 'none';
  }
}

/** Apply effects to an offscreen image in sequence without modifying the layer's source pixels. */
export function processEffects(
  source: HTMLCanvasElement,
  effects: readonly Effect[],
): HTMLCanvasElement {
  const visible = effects.filter(effect => effect.enabled && effect.amount > 0);
  let current = source;
  for (const effect of visible) {
    const target = document.createElement('canvas');
    target.width = source.width;
    target.height = source.height;
    const ctx = target.getContext('2d');
    if (!ctx) return current;
    if (['brightness', 'contrast', 'saturate', 'hue', 'grayscale', 'sepia', 'blur', 'invert'].includes(effect.kind)) {
      ctx.filter = effectFilter(effect);
      ctx.drawImage(current, 0, 0);
    } else if (effect.kind === 'pixelate') {
      const cellSize = Math.max(1, Math.round(effect.amount));
      const pixelWidth = Math.max(1, Math.ceil(current.width / cellSize));
      const pixelHeight = Math.max(1, Math.ceil(current.height / cellSize));
      const small = document.createElement('canvas');
      small.width = pixelWidth;
      small.height = pixelHeight;
      const smallCtx = small.getContext('2d');
      if (!smallCtx) return current;
      smallCtx.imageSmoothingEnabled = false;
      smallCtx.drawImage(current, 0, 0, pixelWidth, pixelHeight);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(small, 0, 0, source.width, source.height);
    } else if (effect.kind === 'posterize') {
      ctx.drawImage(current, 0, 0);
      // ImageData processing preserves transparency and changes color channels only.
      // Clamp the lowest value to two buckets to prevent division by zero.
      const levels = Math.max(2, Math.min(32, Math.round(effect.amount)));
      const image = ctx.getImageData(0, 0, source.width, source.height);
      const step = 255 / (levels - 1);
      for (let index = 0; index < image.data.length; index += 4) {
        for (let channel = 0; channel < 3; channel++) {
          image.data[index + channel] = Math.round(image.data[index + channel] / step) * step;
        }
      }
      ctx.putImageData(image, 0, 0);
    } else if (effect.kind === 'vignette') {
      ctx.drawImage(current, 0, 0);
      const radius = Math.hypot(source.width, source.height) * 0.52;
      const gradient = ctx.createRadialGradient(
        source.width / 2, source.height / 2, radius * 0.12,
        source.width / 2, source.height / 2, radius,
      );
      gradient.addColorStop(0, '#00000000');
      gradient.addColorStop(1, `rgba(0,0,0,${Math.min(0.95, effect.amount / 100)})`);
      ctx.fillStyle = gradient;
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillRect(0, 0, source.width, source.height);
      ctx.globalCompositeOperation = 'source-over';
    } else if (effect.kind === 'shadow' || effect.kind === 'glow') {
      const spread = clampEffectAmount(effect.kind, effect.amount);
      const params = effect.parameters;
      const shadow = document.createElement('canvas');
      shadow.width = source.width;
      shadow.height = source.height;
      const shadowCtx = shadow.getContext('2d');
      if (!shadowCtx) return current;
      shadowCtx.shadowColor = effect.color ?? (effect.kind === 'glow' ? '#a278ff' : '#000000');
      shadowCtx.shadowBlur = Math.max(0, Math.min(100, params?.blur ?? spread));
      shadowCtx.shadowOffsetX = params?.offsetX ?? (effect.kind === 'shadow' ? spread * 0.5 : 0);
      shadowCtx.shadowOffsetY = params?.offsetY ?? (effect.kind === 'shadow' ? spread * 0.5 : 0);
      shadowCtx.drawImage(current, 0, 0);
      shadowCtx.shadowBlur = 0;
      shadowCtx.shadowOffsetX = 0;
      shadowCtx.shadowOffsetY = 0;
      // Remove source geometry from the shadow pass. Draw the original only once,
      // preserving partially transparent source pixels without double-compositing.
      shadowCtx.globalCompositeOperation = 'destination-out';
      shadowCtx.drawImage(current, 0, 0);
      ctx.globalAlpha = Math.max(0, Math.min(1, (params?.opacity ?? 100) / 100));
      ctx.drawImage(shadow, 0, 0);
      ctx.globalAlpha = 1;
      ctx.drawImage(current, 0, 0);
    } else if (effect.kind === 'outline') {
      const radius = Math.max(1, Math.round(clampEffectAmount(effect.kind, effect.amount)));
      const silhouette = document.createElement('canvas');
      silhouette.width = source.width;
      silhouette.height = source.height;
      const silhouetteCtx = silhouette.getContext('2d');
      if (!silhouetteCtx) return current;
      for (let index = 0; index < 32; index++) {
        const angle = Math.PI * 2 * index / 32;
        silhouetteCtx.drawImage(current, Math.cos(angle) * radius, Math.sin(angle) * radius);
      }
      silhouetteCtx.globalCompositeOperation = 'source-in';
      silhouetteCtx.fillStyle = effect.color ?? '#ffffff';
      silhouetteCtx.fillRect(0, 0, source.width, source.height);
      ctx.drawImage(silhouette, 0, 0);
      ctx.drawImage(current, 0, 0);
    } else if (effect.kind === 'chromatic') {
      const offset = Math.round(clampEffectAmount(effect.kind, effect.amount));
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      for (const [shift, tint] of [[-offset, '#ff365d'], [0, '#54eaff'], [offset, '#384fff']] as const) {
        const channel = document.createElement('canvas');
        channel.width = source.width;
        channel.height = source.height;
        const channelCtx = channel.getContext('2d');
        if (!channelCtx) continue;
        channelCtx.drawImage(current, 0, 0);
        channelCtx.globalCompositeOperation = 'source-in';
        channelCtx.fillStyle = tint;
        channelCtx.fillRect(0, 0, channel.width, channel.height);
        ctx.drawImage(channel, shift, effect.parameters?.shiftY ?? 0);
      }
      const density = Math.min(100, Math.max(0, effect.parameters?.density ?? 0));
      const scanlines = Math.min(100, Math.max(0, effect.parameters?.scanlines ?? 0));
      const seed = Math.round(effect.parameters?.seed ?? 1);
      if (density > 0) {
        // Coordinate-seeded band distortion: deterministic across previews and exports.
        for (let y = 0; y < current.height; y += 6) {
          const random = Math.abs(Math.sin((y + 1) * 17.173 + seed * 78.233) * 43758.5453) % 1;
          if (random * 100 >= density) continue;
          const shift = Math.round((random - 0.5) * 2 * offset);
          ctx.globalAlpha = 0.75;
          ctx.drawImage(current, 0, y, current.width, Math.min(4, current.height - y),
            shift, y, current.width, Math.min(4, current.height - y));
        }
        ctx.globalAlpha = 1;
      }
      if (scanlines > 0) {
        ctx.globalCompositeOperation = 'source-atop';
        ctx.fillStyle = `rgba(2,4,17,${0.6 * scanlines / 100})`;
        for (let y = 1; y < source.height; y += 3) ctx.fillRect(0, y, source.width, 1);
      }
      ctx.restore();
    }
    current = target;
  }
  return current;
}

/** Render a layer to document-sized, transparent surface. Prefer direct rendering when no FX. */
const vectorEffectCache = new WeakMap<Layer, { width: number; height: number; image: HTMLCanvasElement }>();

export function renderWithEffects(
  ctx: CanvasRenderingContext2D,
  layer: Layer,
  paint: (ctx: CanvasRenderingContext2D, layer: Layer) => void,
  width: number,
  height: number,
): void {
  const effects = layer.effects ?? [];
  if (!effects.some(effect => effect.enabled && effect.amount > 0)) {
    paint(ctx, layer);
    return;
  }
  const cached = layer.type === 'vector' ? vectorEffectCache.get(layer) : undefined;
  if (cached && cached.width === width && cached.height === height) {
    ctx.drawImage(cached.image, 0, 0, width, height);
    return;
  }
  const source = document.createElement('canvas');
  const scale = Math.min(1, Math.sqrt(16_000_000 / Math.max(1, width * height)));
  source.width = Math.max(1, Math.floor(width * scale));
  source.height = Math.max(1, Math.floor(height * scale));
  const temporary = source.getContext('2d');
  if (!temporary) return;
  temporary.scale(scale, scale);
  paint(temporary, layer);
  const processed = processEffects(source, effects);
  if (layer.type === 'vector') vectorEffectCache.set(layer, { width, height, image: processed });
  ctx.drawImage(processed, 0, 0, width, height);
}
