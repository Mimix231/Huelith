import { useEffect, useRef, useState } from 'react';
import { Close, CropSquare, FilterNone, Remove } from '@mui/icons-material';
import { useEditor } from '../editor/store';

/** Native window actions, while keeping a predictable browser preview. */
export default function WindowControls() {
  const desktop = '__TAURI_INTERNALS__' in window;
  const [maximized, setMaximized] = useState(false);
  const approvedClose = useRef(false);

  useEffect(() => {
    if (!desktop) return;
    let mounted = true;
    let unlisten: (() => void) | undefined;
    let unlistenClose: (() => void) | undefined;
    void import('@tauri-apps/api/window').then(async ({ getCurrentWindow }) => {
      const current = getCurrentWindow();
      const refresh = async (): Promise<void> => {
        const value = await current.isMaximized();
        if (mounted) setMaximized(value);
      };
      await refresh();
      const stop = await current.onResized(refresh);
      if (mounted) unlisten = stop;
      else stop();
      const stopClose = await current.onCloseRequested(event => {
        if (approvedClose.current) {
          approvedClose.current = false;
          return;
        }
        if ((useEditor.getState().textDraft || useEditor.getState().tabs.some(tab => tab.dirty)) &&
          !window.confirm('You have unsaved changes. Close Spectrum anyway?')) {
          event.preventDefault();
        }
      });
      if (mounted) unlistenClose = stopClose;
      else stopClose();
    }).catch(console.warn);
    return () => { mounted = false; unlisten?.(); unlistenClose?.(); };
  }, [desktop]);

  async function act(action: 'minimize' | 'toggleMaximize' | 'close'): Promise<void> {
    if (!desktop) return;
    if (action === 'close' && (useEditor.getState().textDraft || useEditor.getState().tabs.some(tab => tab.dirty))) {
      if (!window.confirm('You have unsaved changes. Close Spectrum anyway?')) return;
      approvedClose.current = true;
    }
    try {
      const { getCurrentWindow } = await import('@tauri-apps/api/window');
      await getCurrentWindow()[action]();
    } catch (error) {
      console.error(`Unable to ${action} Spectrum window:`, error);
    }
  }

  return (
    <div className="spectrum-window-controls" role="group" aria-label="Window controls">
      <button type="button" aria-label="Minimize window" title="Minimize" disabled={!desktop}
        onClick={() => void act('minimize')}><Remove /></button>
      <button type="button" aria-label={maximized ? 'Restore window' : 'Maximize window'}
        title={maximized ? 'Restore' : 'Maximize'} disabled={!desktop}
        onClick={() => void act('toggleMaximize')}>
        {maximized ? <FilterNone /> : <CropSquare />}
      </button>
      <button type="button" className="window-close" aria-label="Close window" title="Close Spectrum"
        disabled={!desktop} onClick={() => void act('close')}><Close /></button>
    </div>
  );
}
