import { useState } from 'react';
import { Button, Slider, Tooltip } from '@mui/material';
import type { GradientMode, GradientStop, VectorShape } from '../editor/types';
import { uid } from '../editor/types';
import { GRADIENT_MODES } from '../editor/gradient';
import StudioColorPicker from './StudioColorPicker';
import './GradientControls.css';

/** An edit is committed through updateShape so it joins document undo/redo history. */
export default function GradientControls({ shape, selectedMode, setMode, update, first, second }: {
  shape?: VectorShape; selectedMode: GradientMode; setMode: (mode: GradientMode) => void;
  update: (changes: Partial<VectorShape>) => void; first: string; second: string;
}) {
  const [expanded, setExpanded] = useState(false);
  const mode = shape?.gradientMode ?? selectedMode;
  const stops: GradientStop[] = shape?.gradientStops?.length ? shape.gradientStops : [
    { id: 'a', position: 0, color: first, opacity: 1 }, { id: 'b', position: 1, color: second, opacity: 1 },
  ];
  const changeStop = (id: string, patch: Partial<GradientStop>) => update({ gradientStops: stops.map(item => item.id === id ? { ...item, ...patch } : item) });
  return <div className="huelith-gradient-controls" aria-label="Gradient editor">
    <label>Gradient <select aria-label="Gradient mode" value={mode} onChange={event => {
      const chosen = event.target.value as GradientMode;
      setMode(chosen); if (shape) update({ gradientMode: chosen,
        ...(chosen === 'mesh' && (shape.gradientPoints?.length ?? 0)<4 ? {gradientPoints:[{x:0,y:0,color:first},{x:1,y:0,color:second},{x:0,y:1,color:second},{x:1,y:1,color:first}]} : {}) });
    }}>{GRADIENT_MODES.map(item => <option key={item} value={item}>{item[0].toUpperCase() + item.slice(1)}</option>)}</select></label>
    {shape && <>
      <Tooltip title="Edit the gradient after drawing"><Button size="small" onClick={() => setExpanded(value => !value)}>{expanded ? 'Hide settings' : 'Edit gradient'}</Button></Tooltip>
      {expanded && <div className="huelith-gradient-expanded">
        {(['gradientRotation', 'gradientTwist', 'gradientRepeats', 'gradientCenterX', 'gradientCenterY'] as const).map(prop => {
          const settings = {gradientRotation: [0, 360, 0, 'Rotation'],gradientTwist: [-8, 8, 2, 'Twist'],gradientRepeats: [1, 16, 1, 'Repeats'],gradientCenterX: [0, 1, .5, 'Center X'],gradientCenterY: [0, 1, .5, 'Center Y']} as const;
          const [min, max, defaultValue, label] = settings[prop];
          return <label key={prop}>{label}<Slider size="small" min={min} max={max} step={prop === 'gradientRotation' ? 1 : .05} value={shape[prop] ?? defaultValue}
            onChange={(_, value) => update({ [prop]: value })}/></label>;
        })}
        <label>Reverse <input type="checkbox" checked={Boolean(shape.gradientReverse)} onChange={e => update({ gradientReverse: e.target.checked })}/></label>
        {mode !== 'freeform' && mode !== 'mesh' && <div className="huelith-stops">
          <strong>Color stops</strong>{stops.map(stop => <div key={stop.id} className="huelith-stop">
            <StudioColorPicker value={stop.color} label="Stop color" onChange={color => changeStop(stop.id, { color })}/>
            <input aria-label="Stop position" type="range" min="0" max="100" value={stop.position * 100} onChange={e => changeStop(stop.id, { position: Number(e.target.value) / 100 })}/>
            <button title="Remove stop" disabled={stops.length <= 2} onClick={() => update({ gradientStops: stops.filter(item => item.id !== stop.id) })}>×</button>
          </div>)}
          <Button size="small" onClick={() => update({ gradientStops: [...stops, {id: uid(), position: .5, color: first, opacity: 1}].sort((a,b)=>a.position-b.position) })} disabled={stops.length >= 32}>+ Color stop</Button>
        </div>}
        {(mode === 'freeform' || mode === 'mesh') && <p>{mode === 'mesh' ? 'Edit each corner of the four-point color mesh.' : 'Edit each movable color source.'}</p>}
        {(mode === 'freeform' || mode === 'mesh') && <div className="huelith-color-points">
          {(shape.gradientPoints?.length ? shape.gradientPoints : [{x:0,y:0,color:first},{x:1,y:1,color:second}]).map((point, i, points) =>
            <div key={i}><StudioColorPicker label={`Point ${i+1}`} value={point.color} onChange={color => update({gradientPoints: points.map((p,j)=>i===j?{...p,color}:p)})}/>
              {(['x','y'] as const).map(axis => <label key={axis}>{axis.toUpperCase()} <input aria-label={`Point ${i+1} ${axis}`} type="number" step="0.05" min="0" max="1" value={point[axis]}
                onChange={e => update({gradientPoints: points.map((p,j)=>i===j?{...p,[axis]:Math.max(0,Math.min(1,Number(e.target.value)))}:p)})}/></label>)}
              {mode === 'freeform' && <button onClick={() => update({gradientPoints: points.filter((_,j)=>j!==i)})} disabled={points.length<=2}>×</button>}
            </div>)}
          {mode === 'freeform' && <Button size="small" onClick={() => update({gradientPoints: [...(shape.gradientPoints ?? [{x:0,y:0,color:first},{x:1,y:1,color:second}]), {x:.5,y:.5,color:first}]})}>+ Color point</Button>}
        </div>}
      </div>}
    </>}
  </div>;
}
