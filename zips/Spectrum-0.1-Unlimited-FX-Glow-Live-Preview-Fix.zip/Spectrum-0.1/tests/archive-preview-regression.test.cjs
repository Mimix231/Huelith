const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
const file = file => fs.readFileSync(path.join(root, file), 'utf8');

function mixer() {
  const script = ts.transpileModule(file('src/editor/live-preview-mixer.ts'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const module = { exports: {} };
  new Function('module', 'exports', 'require', script)(module, module.exports, () => ({}));
  return module.exports;
}
const effect = (amount, color='#abcdef') => ({id:'fx', kind:'sig_3', amount, enabled:true, color, parameters:{glowRadius: 15}});

test('regression: worker queue no longer prevents frame invalidation', () => {
  const store = file('src/editor/store.ts');
  const fn = store.match(/function announceStudioPreview\([\s\S]*?\n}\n/);
  assert.ok(fn, 'Preview dispatcher must exist');
  assert.match(fn[0], /queueLayerEffectPreview\(layerId, effects\)/);
  assert.match(fn[0], /dispatchEvent\(new Event\('spectrum-studio-preview'\)\)/);
  assert.doesNotMatch(fn[0], /if\s*\([^)]*queueLayerEffectPreview[^)]*\)\s*return\s*;/,
    'Prior Stage I-J bug: successful worker request blocked the very next canvas frame');
});

test('regression: preview snapshots do not structuredClone complex FX every repaint', () => {
  const store = file('src/editor/store.ts');
  assert.match(store, /studioEffectPath\(layer, studioOverlay\.layerId, studioOverlay\.effects, false\)/);
  assert.match(store, /clone\s*\?\s*effects\.map\(effect => structuredClone\(effect\)\)/);
  const workerClient = file('src/editor/effects-worker-client.ts');
  assert.match(workerClient, /effects:\s*\[\.\.\.effects\]/);
});

test('regression: exact worker output replaces interim result, never modifies export', () => {
  const source = file('src/editor/fx.ts');
  assert.match(source, /if \(dragging\) \{/);
  assert.match(source, /paintGpuEffectDraft\(ctx, source, effects, width, height\)/);
  assert.match(source, /lastSubmitted\.get\(layerId\)/);
  assert.match(source, /const processed = processEffects\(source, effects\)/);
  assert.match(source, /generation !== activeGeneration\(layerId\)/);
  assert.match(source, /effect\.kind === 'cutout'/);
});

test('interpolated one-effect strength responds to every new slider value', () => {
  const {mixPlan} = mixer();
  assert.equal(mixPlan([effect(65)], [effect(35)]).factor, 35/65);
  assert.equal(mixPlan([effect(65)], [effect(100)]).factor, 100/65);
  assert.equal(mixPlan([effect(65)], [effect(65)]), null);
  assert.equal(mixPlan([effect(65)], [effect(20,'#ffffff')]), null);
  assert.equal(mixPlan([effect(65)], [effect(20,'#abcdef')]).kind, 'sig_3');
  assert.equal(mixPlan([effect(65),effect(65)], [effect(20),effect(20)]), null);
  assert.equal(mixPlan([{...effect(65), kind:'pixelate'}], [{...effect(20), kind:'pixelate'}]), null,
    'Pixel-size is not an opacity setting; do not show a deceptive interpolation');
});
